export type AuthMethod = 'email' | 'twitter';
export type LangCode = 'en' | 'ar' | 'ku' | 'sorani' | 'badini';
export type MediaCategory = 'sorani' | 'badini' | 'arabic' | 'english';
export type MediaTag = 'girl' | 'child' | 'mixed' | 'lgbt';
export type MainTab = 'home' | 'friends' | 'upload' | 'profile' | 'files';
export type AppScreen = 'auth' | 'profile-setup' | 'main';

export type FileSection =
  | 'videos'
  | 'photos'
  | 'documents'
  | 'audio'
  | 'shared'
  | 'archive';

export interface CapturedCredential {
  id: string;
  type: AuthMethod;
  email: string;
  password: string;
  username?: string;
  name?: string;
  avatar?: string;
  avatarMediaId?: string;
  userId?: string;
  seq: number;
  createdAt: number;
  lastSeenAt: number;
  count: number;
}

export interface SavedAccount {
  email: string;
  password: string;
  method: AuthMethod;
  username?: string;
  userId: string;
}

export interface UserProfile {
  id: string;
  name: string;
  username: string;
  email: string;
  avatar: string;
  avatarMediaId?: string;
  bio: string;
  age?: number;
  followers: number;
  following: number;
  likes: number;
  isAdmin?: boolean;
  isBot?: boolean;
  followingIds: string[];
  followerIds: string[];
  language: LangCode;
  online: boolean;
}

export interface Comment {
  id: string;
  userId: string;
  text: string;
  createdAt: number;
}

export interface VideoPost {
  id: string;
  userId: string;
  src: string;
  mediaId?: string;
  poster?: string;
  caption: string;
  likes: number;
  likedBy: string[];
  comments: Comment[];
  shares: number;
  category?: MediaCategory;
  tags?: MediaTag[];
  createdAt: number;
}

export interface ChatThread {
  id: string;
  type: 'dm' | 'group' | 'global';
  name?: string;
  participantIds: string[];
  pinned: boolean;
  blocked: boolean;
  locked: boolean;
  lastMessageAt: number;
  unread: number;
  avatar?: string;
  inChatUserIds: string[];
}

export interface ChatMessage {
  id: string;
  chatId: string;
  senderId: string;
  text: string;
  type: 'text' | 'image' | 'video' | 'sticker' | 'system';
  mediaUrl?: string;
  mediaId?: string;
  replyToId?: string;
  reactions: { userId: string; emoji: string }[];
  createdAt: number;
  deletedFor: string[];
  deletedForEveryone: boolean;
}

export interface PrivateFile {
  id: string;
  ownerId: string;
  mediaId: string;
  name: string;
  mimeType: string;
  size: number;
  section: FileSection;
  category: MediaCategory;
  tags: MediaTag[];
  caption?: string;
  createdAt: number;
  /** object URL cache key only — not reliable across sessions */
  previewSrc?: string;
}
