import { FolderOpen, Home, Plus, User, Users } from 'lucide-react';
import { motion } from 'framer-motion';
import { t } from '../lib/i18n';
import type { MainTab } from '../lib/types';
import { useAppStore } from '../store/useAppStore';

export default function BottomNav() {
  const tab = useAppStore((s) => s.tab);
  const setTab = useAppStore((s) => s.setTab);
  const chats = useAppStore((s) => s.chats);
  const lang = useAppStore((s) => s.language);
  const unread = chats.reduce((n, c) => n + c.unread, 0);

  const items: { id: MainTab; label: string; icon: typeof Home; center?: boolean }[] = [
    { id: 'home', label: t(lang, 'home'), icon: Home },
    { id: 'friends', label: t(lang, 'friends'), icon: Users },
    { id: 'upload', label: t(lang, 'upload'), icon: Plus, center: true },
    { id: 'files', label: t(lang, 'files'), icon: FolderOpen },
    { id: 'profile', label: t(lang, 'profile'), icon: User },
  ];

  return (
    <nav className="fixed bottom-0 inset-x-0 z-40 px-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-2 pointer-events-none">
      <div className="pointer-events-auto mx-auto max-w-lg glass-nav flex items-center justify-between gap-1 px-2 py-2">
        {items.map((item) => {
          const Icon = item.icon;
          const active = tab === item.id;
          if (item.center) {
            return (
              <motion.button
                key={item.id}
                whileTap={{ scale: 0.9 }}
                onClick={() => setTab(item.id)}
                className="relative -mt-6 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-cyan-400 via-fuchsia-500 to-violet-600 text-white shadow-[0_8px_30px_rgba(168,85,247,0.45)] border border-white/30"
                aria-label="Upload"
              >
                <Icon className="h-7 w-7" strokeWidth={2.5} />
              </motion.button>
            );
          }
          return (
            <button
              key={item.id}
              onClick={() => setTab(item.id)}
              className={`relative flex flex-1 flex-col items-center gap-0.5 rounded-xl py-1.5 transition-colors ${
                active ? 'text-cyan-300' : 'text-white/55'
              }`}
            >
              {active && (
                <motion.span
                  layoutId="nav-glow"
                  className="absolute inset-0 rounded-xl bg-white/8"
                  transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                />
              )}
              <span className="relative">
                <Icon className="h-5 w-5" />
                {item.id === 'friends' && unread > 0 && (
                  <span className="absolute -right-2 -top-1 h-2.5 w-2.5 rounded-full bg-rose-500 ring-2 ring-black/40" />
                )}
              </span>
              <span className="relative text-[10px] font-medium tracking-wide">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
