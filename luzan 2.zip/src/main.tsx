import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import App from './App.tsx';
import ErrorBoundary from './components/ErrorBoundary';

const rootEl = document.getElementById('root');

// Immediate paint fallback so Safari never shows pure black while JS boots
if (rootEl && !rootEl.childElementCount) {
  rootEl.innerHTML =
    '<div style="min-height:100dvh;background:#0d0e15;display:flex;align-items:center;justify-content:center;color:rgba(255,255,255,.55);font-family:system-ui,sans-serif;font-size:14px">luzan</div>';
}

try {
  createRoot(rootEl!).render(
    <StrictMode>
      <ErrorBoundary>
        <App />
      </ErrorBoundary>
    </StrictMode>
  );
} catch (err) {
  console.error('[luzan] boot failed', err);
  if (rootEl) {
    rootEl.innerHTML = `
      <div style="min-height:100dvh;background:#0d0e15;color:#fff;display:flex;align-items:center;justify-content:center;padding:24px;font-family:system-ui,sans-serif;text-align:center">
        <div>
          <div style="font-size:22px;font-weight:700;margin-bottom:8px">luzan</div>
          <p style="opacity:.7;margin-bottom:16px">Failed to start. Please reload.</p>
          <button onclick="location.reload()" style="padding:12px 20px;border:0;border-radius:12px;background:linear-gradient(135deg,#22d3ee,#d946ef);color:#fff;font-weight:600">Reload</button>
        </div>
      </div>`;
  }
}
