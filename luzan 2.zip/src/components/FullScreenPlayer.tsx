import { motion } from 'framer-motion';
import { X } from 'lucide-react';
import { useEffect, useRef } from 'react';
import { useResolvedSrc } from './MediaSrc';
import { TagRow } from './Glass';

export default function FullScreenPlayer({
  src,
  mediaId,
  title,
  tags,
  mimeType,
  onClose,
}: {
  src?: string;
  mediaId?: string;
  title?: string;
  tags?: string[];
  mimeType?: string;
  onClose: () => void;
}) {
  const url = useResolvedSrc(src, mediaId);
  const videoRef = useRef<HTMLVideoElement>(null);
  const isVideo = !mimeType || mimeType.startsWith('video');

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  useEffect(() => {
    if (isVideo && videoRef.current) {
      videoRef.current.play().catch(() => undefined);
    }
  }, [url, isVideo]);

  return (
    <motion.div
      className="fixed inset-0 z-[80] bg-black flex flex-col no-select"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <div className="absolute top-0 inset-x-0 z-20 flex items-center justify-between px-3 pt-[max(0.75rem,env(safe-area-inset-top))] pb-3 bg-gradient-to-b from-black/70 to-transparent">
        <button onClick={onClose} className="glass-icon-btn" aria-label="Close">
          <X className="h-5 w-5" />
        </button>
        <p className="flex-1 mx-3 text-sm text-white truncate text-center">{title || ''}</p>
        <div className="w-9" />
      </div>

      <div className="flex-1 flex items-center justify-center bg-black" onClick={onClose}>
        {url ? (
          isVideo ? (
            <video
              ref={videoRef}
              src={url}
              className="max-h-full max-w-full w-full h-full object-contain"
              controls
              playsInline
              autoPlay
              onClick={(e) => e.stopPropagation()}
            />
          ) : (
            <img
              src={url}
              alt=""
              className="max-h-full max-w-full object-contain"
              draggable={false}
              onClick={(e) => e.stopPropagation()}
            />
          )
        ) : (
          <p className="text-white/40 text-sm">Loading…</p>
        )}
      </div>

      {(title || (tags && tags.length > 0)) && (
        <div className="absolute bottom-0 inset-x-0 p-4 pb-[max(1rem,env(safe-area-inset-bottom))] bg-gradient-to-t from-black/80 to-transparent pointer-events-none">
          {title && <p className="text-sm text-white mb-1">{title}</p>}
          {tags && <TagRow tags={tags} />}
        </div>
      )}
    </motion.div>
  );
}
