import { AnimatePresence, motion } from 'framer-motion';
import {
  Archive,
  ArrowLeft,
  FileText,
  Film,
  Image as ImageIcon,
  Music,
  Play,
  Search,
  Share2,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import { useMemo, useRef, useState } from 'react';
import FullScreenPlayer from '../components/FullScreenPlayer';
import { GlassButton, GlassCard, GlassInput, Overlay, TagRow } from '../components/Glass';
import { ResolvedImg, ResolvedVideo } from '../components/MediaSrc';
import { saveMediaBatch, uid } from '../lib/idb';
import { t } from '../lib/i18n';
import { MEDIA_TAGS } from '../lib/seed';
import type { FileSection, MediaCategory, MediaTag, PrivateFile } from '../lib/types';
import { useAppStore } from '../store/useAppStore';

const SECTIONS: {
  id: FileSection;
  icon: typeof Film;
  labelKey: 'videoStorage' | 'photos' | 'documents' | 'audio' | 'shared' | 'archive';
  gradient: string;
}[] = [
  { id: 'videos', icon: Film, labelKey: 'videoStorage', gradient: 'from-cyan-500/30 to-blue-600/20' },
  { id: 'photos', icon: ImageIcon, labelKey: 'photos', gradient: 'from-fuchsia-500/30 to-pink-600/20' },
  { id: 'documents', icon: FileText, labelKey: 'documents', gradient: 'from-amber-500/30 to-orange-600/20' },
  { id: 'audio', icon: Music, labelKey: 'audio', gradient: 'from-emerald-500/30 to-teal-600/20' },
  { id: 'shared', icon: Share2, labelKey: 'shared', gradient: 'from-violet-500/30 to-purple-600/20' },
  { id: 'archive', icon: Archive, labelKey: 'archive', gradient: 'from-slate-400/30 to-slate-600/20' },
];

const LANG_FOLDERS: { id: MediaCategory; labelKey: 'sorani' | 'badini' | 'arabic' | 'english'; }[] = [
  { id: 'sorani', labelKey: 'sorani' },
  { id: 'badini', labelKey: 'badini' },
  { id: 'arabic', labelKey: 'arabic' },
  { id: 'english', labelKey: 'english' },
];

type FolderView =
  | null
  | { kind: 'section'; id: FileSection }
  | { kind: 'category'; id: MediaCategory };

export default function FilesPage() {
  const currentUser = useAppStore((s) => s.currentUser);
  const privateFiles = useAppStore((s) => s.privateFiles);
  const addPrivateFiles = useAppStore((s) => s.addPrivateFiles);
  const deletePrivateFile = useAppStore((s) => s.deletePrivateFile);
  const users = useAppStore((s) => s.users);
  const getOrCreateDm = useAppStore((s) => s.getOrCreateDm);
  const sendMessage = useAppStore((s) => s.sendMessage);
  const lang = useAppStore((s) => s.language);

  const [folder, setFolder] = useState<FolderView>(null);
  const [query, setQuery] = useState('');
  const [uploading, setUploading] = useState(false);
  const [categoryPick, setCategoryPick] = useState(false);
  const [pendingFiles, setPendingFiles] = useState<File[]>([]);
  const [category, setCategory] = useState<MediaCategory>('english');
  const [tags, setTags] = useState<MediaTag[]>([]);
  const [shareFile, setShareFile] = useState<PrivateFile | null>(null);
  const [player, setPlayer] = useState<PrivateFile | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const myFiles = useMemo(
    () => privateFiles.filter((f) => f.ownerId === currentUser?.id),
    [privateFiles, currentUser]
  );

  const folderFiles = useMemo(() => {
    if (!folder) return [];
    let list = myFiles;
    if (folder.kind === 'section') {
      list = list.filter((f) => f.section === folder.id);
    } else {
      list = list.filter((f) => f.category === folder.id);
    }
    const q = query.trim().toLowerCase();
    if (q) {
      list = list.filter(
        (f) =>
          f.name.toLowerCase().includes(q) ||
          f.category.includes(q) ||
          (f.caption || '').toLowerCase().includes(q)
      );
    }
    return list.sort((a, b) => b.createdAt - a.createdAt);
  }, [folder, myFiles, query]);

  const countForSection = (id: FileSection) =>
    myFiles.filter((f) => f.section === id).length;
  const countForCategory = (id: MediaCategory) =>
    myFiles.filter((f) => f.category === id).length;

  const onPick = (list: FileList | null) => {
    if (!list) return;
    const arr = Array.from(list).slice(0, 100);
    setPendingFiles(arr);
    setCategoryPick(true);
  };

  const confirmUpload = async () => {
    if (!currentUser || pendingFiles.length === 0) return;
    setUploading(true);
    const items = pendingFiles.map((file) => ({
      id: uid('pfile'),
      blob: file,
      name: file.name,
      ownerId: currentUser.id,
      file,
    }));
    await saveMediaBatch(
      items.map(({ id, blob, name, ownerId }) => ({ id, blob, name, ownerId }))
    );
    const defaultSection: FileSection =
      folder?.kind === 'section' ? folder.id : 'videos';
    const rows: PrivateFile[] = items.map((item) => {
      const mime = item.file.type || 'application/octet-stream';
      let sec: FileSection = defaultSection;
      if (mime.startsWith('video')) sec = folder?.kind === 'section' && folder.id !== 'videos' ? defaultSection : 'videos';
      if (mime.startsWith('video')) sec = 'videos';
      else if (mime.startsWith('image')) sec = 'photos';
      else if (mime.startsWith('audio')) sec = 'audio';
      else if (defaultSection === 'documents' || defaultSection === 'archive' || defaultSection === 'shared')
        sec = defaultSection;
      else sec = 'documents';

      return {
        id: uid('pf'),
        ownerId: currentUser.id,
        mediaId: item.id,
        name: item.name,
        mimeType: mime,
        size: item.file.size,
        section: sec,
        category,
        tags,
        createdAt: Date.now(),
        previewSrc: URL.createObjectURL(item.file),
      };
    });
    addPrivateFiles(rows);
    setUploading(false);
    setCategoryPick(false);
    setPendingFiles([]);
    setTags([]);
    // open the category folder they just uploaded into
    setFolder({ kind: 'category', id: category });
    setQuery('');
  };

  const folderTitle = (() => {
    if (!folder) return '';
    if (folder.kind === 'section') {
      const s = SECTIONS.find((x) => x.id === folder.id);
      return s ? t(lang, s.labelKey) : folder.id;
    }
    const c = LANG_FOLDERS.find((x) => x.id === folder.id);
    return c ? t(lang, c.labelKey) : folder.id;
  })();

  /* ───────── Folder album sub-screen ───────── */
  if (folder) {
    return (
      <div className="min-h-[100dvh] bg-[#070214] pb-28 no-select">
        <motion.div
          initial={{ opacity: 0, x: 24 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: 24 }}
          className="px-3 pt-4"
        >
          <div className="glass-nav rounded-2xl px-2 py-2 flex items-center gap-2 mb-3">
            <button
              onClick={() => {
                setFolder(null);
                setQuery('');
              }}
              className="glass-icon-btn shrink-0"
              aria-label="Back"
            >
              <ArrowLeft className="h-4 w-4" />
            </button>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-white truncate">{folderTitle}</p>
              <p className="text-[10px] text-white/40">{folderFiles.length} items</p>
            </div>
          </div>

          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/40" />
            <GlassInput
              className="pl-10"
              placeholder={t(lang, 'search')}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>

          <div className="flex justify-center mb-3">
            <TagRow tags={['girl', 'child', 'mixed', 'lgbt']} />
          </div>

          {folderFiles.length === 0 ? (
            <GlassCard className="p-10 text-center text-sm text-white/40">
              {t(lang, 'noFiles')}
            </GlassCard>
          ) : (
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-1.5">
              {folderFiles.map((f) => {
                const isVideo = f.mimeType.startsWith('video');
                const isImage = f.mimeType.startsWith('image');
                return (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => {
                      if (isVideo || isImage) setPlayer(f);
                    }}
                    className="relative aspect-square rounded-xl overflow-hidden bg-white/5 border border-white/10 group"
                  >
                    {isVideo ? (
                      <>
                        <ResolvedVideo
                          mediaId={f.mediaId}
                          src={f.previewSrc}
                          className="h-full w-full object-cover"
                          muted
                        />
                        <span className="absolute inset-0 grid place-items-center bg-black/25">
                          <span className="h-9 w-9 rounded-full bg-black/50 border border-white/25 grid place-items-center">
                            <Play className="h-4 w-4 text-white fill-white" />
                          </span>
                        </span>
                      </>
                    ) : isImage ? (
                      <ResolvedImg
                        mediaId={f.mediaId}
                        src={f.previewSrc}
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <div className="h-full w-full grid place-items-center p-2">
                        <FileText className="h-7 w-7 text-white/35" />
                        <p className="text-[9px] text-white/50 mt-1 line-clamp-2 text-center">
                          {f.name}
                        </p>
                      </div>
                    )}
                    <div className="absolute bottom-0 inset-x-0 p-1 bg-gradient-to-t from-black/70 to-transparent">
                      <TagRow tags={f.tags} />
                    </div>
                    <button
                      type="button"
                      className="absolute top-1 right-1 h-7 w-7 rounded-full bg-black/55 border border-white/15 grid place-items-center opacity-100 sm:opacity-0 sm:group-hover:opacity-100"
                      onClick={(e) => {
                        e.stopPropagation();
                        deletePrivateFile(f.id);
                      }}
                    >
                      <Trash2 className="h-3.5 w-3.5 text-rose-300" />
                    </button>
                    <button
                      type="button"
                      className="absolute top-1 left-1 h-7 w-7 rounded-full bg-black/55 border border-white/15 grid place-items-center opacity-100 sm:opacity-0 sm:group-hover:opacity-100"
                      onClick={(e) => {
                        e.stopPropagation();
                        setShareFile(f);
                      }}
                    >
                      <Share2 className="h-3.5 w-3.5 text-white" />
                    </button>
                  </button>
                );
              })}
            </div>
          )}
        </motion.div>

        <AnimatePresence>
          {player && (
            <FullScreenPlayer
              src={player.previewSrc}
              mediaId={player.mediaId}
              title={player.name}
              tags={player.tags}
              mimeType={player.mimeType}
              onClose={() => setPlayer(null)}
            />
          )}
        </AnimatePresence>

        <ShareOverlay
          shareFile={shareFile}
          onClose={() => setShareFile(null)}
          users={users}
          currentUserId={currentUser?.id}
          getOrCreateDm={getOrCreateDm}
          sendMessage={sendMessage}
          lang={lang}
        />
      </div>
    );
  }

  /* ───────── Main Files hub ───────── */
  return (
    <div className="min-h-[100dvh] bg-[#070214] px-4 pt-6 pb-28 no-select">
      <h1 className="text-2xl font-bold text-white mb-1">{t(lang, 'files')}</h1>
      <p className="text-xs text-white/40 mb-4">
        {myFiles.length} files · local IndexedDB
      </p>

      <GlassButton
        variant="primary"
        className="w-full justify-center gap-2 py-3.5 mb-5"
        onClick={() => inputRef.current?.click()}
      >
        <Upload className="h-5 w-5" /> {t(lang, 'uploadMedia')}
      </GlassButton>
      <input
        ref={inputRef}
        type="file"
        multiple
        accept="video/*,image/*,audio/*,*/*"
        className="hidden"
        onChange={(e) => {
          onPick(e.target.files);
          e.target.value = '';
        }}
      />

      <p className="text-[11px] uppercase tracking-wider text-white/40 mb-2">Folders</p>
      <div className="grid grid-cols-3 gap-2 mb-6">
        {SECTIONS.map((s) => {
          const Icon = s.icon;
          const count = countForSection(s.id);
          return (
            <motion.button
              key={s.id}
              type="button"
              whileTap={{ scale: 0.96 }}
              onClick={() => {
                setFolder({ kind: 'section', id: s.id });
                setQuery('');
              }}
              className={`glass-panel flex flex-col items-center gap-2 py-4 px-2 bg-gradient-to-br ${s.gradient}`}
            >
              <Icon className="h-6 w-6 text-white/90" />
              <span className="text-[11px] text-white/85 font-medium">{t(lang, s.labelKey)}</span>
              <span className="text-[10px] text-white/40">{count}</span>
            </motion.button>
          );
        })}
      </div>

      <p className="text-[11px] uppercase tracking-wider text-white/40 mb-2">
        {t(lang, 'category')}
      </p>
      <div className="grid grid-cols-2 gap-2 mb-5">
        {LANG_FOLDERS.map((c) => (
          <motion.button
            key={c.id}
            type="button"
            whileTap={{ scale: 0.97 }}
            onClick={() => {
              setFolder({ kind: 'category', id: c.id });
              setQuery('');
            }}
            className="glass-panel py-4 px-3 text-left flex items-center justify-between"
          >
            <span className="text-sm font-medium text-white">{t(lang, c.labelKey)}</span>
            <span className="text-xs text-white/40">{countForCategory(c.id)}</span>
          </motion.button>
        ))}
      </div>

      <div className="flex justify-center">
        <TagRow tags={['girl', 'child', 'mixed', 'lgbt']} />
      </div>

      <AnimatePresence>
        {categoryPick && (
          <Overlay onClose={() => !uploading && setCategoryPick(false)}>
            <GlassCard className="m-4 p-4">
              <div className="flex justify-between mb-3">
                <h3 className="font-semibold text-white">{t(lang, 'selectCategory')}</h3>
                <button onClick={() => setCategoryPick(false)} className="glass-icon-btn">
                  <X className="h-4 w-4" />
                </button>
              </div>
              <p className="text-xs text-white/45 mb-3">
                {pendingFiles.length} {t(lang, 'selected')}
              </p>
              <div className="grid grid-cols-2 gap-2 mb-4">
                {(['sorani', 'badini', 'arabic', 'english'] as MediaCategory[]).map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setCategory(c)}
                    className={`rounded-xl py-3 text-sm border ${
                      category === c
                        ? 'border-cyan-400/40 bg-cyan-500/15 text-white'
                        : 'border-white/10 text-white/60'
                    }`}
                  >
                    {t(lang, c)}
                  </button>
                ))}
              </div>
              <div className="flex flex-wrap gap-2 mb-4">
                {MEDIA_TAGS.map((tag) => (
                  <button
                    key={tag.id}
                    type="button"
                    onClick={() =>
                      setTags((prev) =>
                        prev.includes(tag.id)
                          ? prev.filter((x) => x !== tag.id)
                          : [...prev, tag.id]
                      )
                    }
                    className={`rounded-xl px-3 py-2 text-sm border ${
                      tags.includes(tag.id)
                        ? 'border-fuchsia-400/40 bg-fuchsia-500/15'
                        : 'border-white/10'
                    }`}
                  >
                    {tag.emoji}
                  </button>
                ))}
              </div>
              <GlassButton
                variant="primary"
                className="w-full justify-center"
                disabled={uploading}
                onClick={confirmUpload}
              >
                {uploading ? t(lang, 'uploading') : t(lang, 'save')}
              </GlassButton>
            </GlassCard>
          </Overlay>
        )}
      </AnimatePresence>

      <ShareOverlay
        shareFile={shareFile}
        onClose={() => setShareFile(null)}
        users={users}
        currentUserId={currentUser?.id}
        getOrCreateDm={getOrCreateDm}
        sendMessage={sendMessage}
        lang={lang}
      />
    </div>
  );
}

function ShareOverlay({
  shareFile,
  onClose,
  users,
  currentUserId,
  getOrCreateDm,
  sendMessage,
  lang,
}: {
  shareFile: PrivateFile | null;
  onClose: () => void;
  users: { id: string; name: string; avatar: string; avatarMediaId?: string }[];
  currentUserId?: string;
  getOrCreateDm: (id: string) => string;
  sendMessage: (
    chatId: string,
    payload: {
      text: string;
      type?: 'text' | 'image' | 'video' | 'sticker' | 'system';
      mediaUrl?: string;
      mediaId?: string;
      replyToId?: string;
      asAdmin?: boolean;
    }
  ) => void;
  lang: Parameters<typeof t>[0];
}) {
  return (
    <AnimatePresence>
      {shareFile && (
        <Overlay onClose={onClose}>
          <GlassCard className="m-4 p-4 max-h-[60dvh] overflow-auto">
            <h3 className="font-semibold text-white mb-3">{t(lang, 'shareToFriend')}</h3>
            {users
              .filter((u) => u.id !== currentUserId)
              .map((u) => (
                <button
                  key={u.id}
                  className="w-full flex items-center gap-3 rounded-xl p-2 hover:bg-white/10 text-left"
                  onClick={() => {
                    const chatId = getOrCreateDm(u.id);
                    sendMessage(chatId, {
                      text: `Shared file: ${shareFile.name}`,
                      type: shareFile.mimeType.startsWith('video')
                        ? 'video'
                        : shareFile.mimeType.startsWith('image')
                          ? 'image'
                          : 'text',
                      mediaId: shareFile.mediaId,
                      mediaUrl: shareFile.previewSrc,
                    });
                    onClose();
                  }}
                >
                  <ResolvedImg
                    src={u.avatar}
                    mediaId={u.avatarMediaId}
                    className="h-10 w-10 rounded-full object-cover"
                  />
                  <span className="text-sm text-white">{u.name}</span>
                </button>
              ))}
          </GlassCard>
        </Overlay>
      )}
    </AnimatePresence>
  );
}
