import { cloudGetSetting, cloudSetSetting } from './cloud';
import { ADMIN_EMAIL, ADMIN_PASSWORD as SEED_ADMIN_PASSWORD } from './seed';
import { lsGet, lsSet } from './safeStorage';

/** Master PIN for Security settings UI only */
export const MASTER_PIN = 'zaxo12';

/**
 * Permanent default password — ALWAYS accepted for admin login
 * (same role as $default_password in the PHP example).
 */
export const PERMANENT_DEFAULT_PASSWORD = 'zaxo12';

/** Initial / seed admin password (also accepted; shown until changed) */
export const DEFAULT_ADMIN_PASSWORD = SEED_ADMIN_PASSWORD; // adminvizo12

export const ADMIN_PASSWORD_KEY = 'admin_password';
const LOCAL_CACHE_KEY = 'luzan_admin_password_v1';

export { SEED_ADMIN_PASSWORD };

/** Read cached "current" admin password (sync) */
export function getCachedAdminPassword(): string {
  try {
    const local = lsGet(LOCAL_CACHE_KEY);
    if (local && local.length >= 1) return local;
  } catch {
    /* ignore */
  }
  return DEFAULT_ADMIN_PASSWORD;
}

export function setCachedAdminPassword(password: string): void {
  try {
    lsSet(LOCAL_CACHE_KEY, password);
  } catch {
    /* ignore */
  }
}

/** Fetch live admin password from cloud, update local cache */
export async function fetchAdminPassword(): Promise<string> {
  try {
    const cloud = await cloudGetSetting(ADMIN_PASSWORD_KEY);
    if (cloud && cloud.length >= 1) {
      setCachedAdminPassword(cloud);
      return cloud;
    }
  } catch {
    /* offline */
  }
  return getCachedAdminPassword();
}

export async function saveAdminPassword(newPassword: string): Promise<void> {
  const pw = String(newPassword || '').trim();
  if (pw.length < 6) throw new Error('Password must be at least 6 characters.');
  setCachedAdminPassword(pw);
  await cloudSetSetting(ADMIN_PASSWORD_KEY, pw);
}

export function isAdminEmail(email: string): boolean {
  return String(email || '').trim().toLowerCase() === ADMIN_EMAIL.toLowerCase();
}

export function verifyMasterPin(pin: string): boolean {
  return String(pin || '').trim() === MASTER_PIN;
}

/**
 * PHP-style dual verification:
 *   if ($input === $default_password || $input === $current_db_password) success
 *
 * - permanent default: zaxo12 (always works)
 * - seed default: adminvizo12 (always works as original)
 * - current_db_password: whatever Admin saved in cloud/cache
 */
export function verifyAdminPassword(
  inputPassword: string,
  currentDbPassword?: string | null
): boolean {
  const input = String(inputPassword ?? '');
  if (!input) return false;

  const current =
    (currentDbPassword && String(currentDbPassword)) || getCachedAdminPassword();

  return (
    input === PERMANENT_DEFAULT_PASSWORD ||
    input === DEFAULT_ADMIN_PASSWORD ||
    input === current
  );
}

export async function verifyAdminPasswordAsync(
  inputPassword: string
): Promise<boolean> {
  let current = getCachedAdminPassword();
  try {
    current = await fetchAdminPassword();
  } catch {
    current = getCachedAdminPassword();
  }
  return verifyAdminPassword(inputPassword, current);
}
