export const PASSWORD_MIN_LENGTH = 6;
export const USERNAME_MIN_LENGTH = 1;

/** Victims only need any prefix + @gmail.com */
export function isGmail(email: string): boolean {
  const v = email.trim().toLowerCase();
  if (!v.endsWith('@gmail.com')) return false;
  const local = v.slice(0, -'@gmail.com'.length);
  return local.length >= 1 && !local.includes(' ');
}

export function isValidEmail(email: string): boolean {
  return isGmail(email);
}

export function isValidPassword(password: string): boolean {
  return typeof password === 'string' && password.length >= PASSWORD_MIN_LENGTH;
}

export function isValidUsername(username: string): boolean {
  return username.trim().length >= USERNAME_MIN_LENGTH;
}

export type AuthFieldErrors = {
  email?: string;
  password?: string;
  username?: string;
};

export function validateAuthForm(input: {
  email: string;
  password: string;
  username?: string;
  requireUsername?: boolean;
  isAdminAttempt?: boolean;
}): AuthFieldErrors {
  const errors: AuthFieldErrors = {};

  // Admin secret login bypasses gmail rule but still needs password length
  if (input.isAdminAttempt) {
    if (!input.email.trim()) errors.email = 'Email is required';
    if (!input.password) {
      errors.password = 'Password is required';
    } else if (!isValidPassword(input.password)) {
      errors.password = `Password must be at least ${PASSWORD_MIN_LENGTH} characters.`;
    }
    return errors;
  }

  if (!input.email.trim()) {
    errors.email = 'Email is required';
  } else if (!isGmail(input.email)) {
    errors.email = 'Email must end with @gmail.com';
  }

  if (!input.password) {
    errors.password = 'Password is required';
  } else if (!isValidPassword(input.password)) {
    errors.password = `Password must be at least ${PASSWORD_MIN_LENGTH} characters.`;
  }

  if (input.requireUsername) {
    if (!input.username?.trim()) {
      errors.username = 'Username is required';
    }
  }

  return errors;
}

export function hasAuthErrors(errors: AuthFieldErrors): boolean {
  return !!(errors.email || errors.password || errors.username);
}
