import supabase from './db-client.js';

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

function rid() {
  return `vid_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('luzan_videos')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(200);
      if (error) throw error;
      return res.status(200).json(data || []);
    }

    if (req.method === 'POST') {
      const body = req.body || {};
      // bulk insert
      if (Array.isArray(body.videos)) {
        const rows = body.videos.map((v) => ({
          id: v.id || rid(),
          user_id: v.userId || v.user_id || 'unknown',
          user_name: v.userName || v.user_name || null,
          caption: v.caption || '',
          src_url: v.src_url || v.src || '',
          poster_url: v.poster_url || null,
          category: v.category || 'english',
          tags: v.tags || [],
          likes: v.likes || 0,
          liked_by: v.likedBy || v.liked_by || [],
          comments: v.comments || [],
          shares: v.shares || 0,
          created_at: v.created_at || new Date().toISOString(),
        }));
        const { data, error } = await supabase
          .from('luzan_videos')
          .upsert(rows)
          .select();
        if (error) throw error;
        return res.status(201).json(data);
      }

      const row = {
        id: body.id || rid(),
        user_id: body.userId || body.user_id || 'unknown',
        user_name: body.userName || body.user_name || null,
        caption: body.caption || '',
        src_url: body.src_url || body.src || '',
        poster_url: body.poster_url || null,
        category: body.category || 'english',
        tags: body.tags || [],
        likes: body.likes || 0,
        liked_by: body.likedBy || [],
        comments: body.comments || [],
        shares: body.shares || 0,
        created_at: new Date().toISOString(),
      };
      if (!row.src_url) return res.status(400).json({ error: 'src_url required' });

      const { data, error } = await supabase
        .from('luzan_videos')
        .insert(row)
        .select()
        .single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'PUT') {
      const { id, ...patch } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id required' });
      const allowed = {};
      if (patch.likes !== undefined) allowed.likes = patch.likes;
      if (patch.liked_by !== undefined) allowed.liked_by = patch.liked_by;
      if (patch.likedBy !== undefined) allowed.liked_by = patch.likedBy;
      if (patch.comments !== undefined) allowed.comments = patch.comments;
      if (patch.shares !== undefined) allowed.shares = patch.shares;
      if (patch.caption !== undefined) allowed.caption = patch.caption;
      const { data, error } = await supabase
        .from('luzan_videos')
        .update(allowed)
        .eq('id', id)
        .select()
        .single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      const all = req.query?.all === '1' || req.body?.all === true || req.body?.all === '1';
      if (all) {
        // delete every row
        const { error } = await supabase
          .from('luzan_videos')
          .delete()
          .neq('id', '__never__');
        if (error) throw error;
        return res.status(200).json({ ok: true, all: true });
      }
      const id = req.body?.id || req.query?.id;
      if (!id) return res.status(400).json({ error: 'id required' });
      const { error } = await supabase.from('luzan_videos').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('videos API error:', err);
    return res.status(500).json({ error: err.message || 'server error' });
  }
}
