import { useEffect, useMemo, useState } from 'react';
import VerticalVideoFeed from '../components/VerticalVideoFeed';
import { cloudListVideos, pollCloud, type CloudVideo } from '../lib/cloud';
import { SEED_VIDEOS } from '../lib/seed';
import type { VideoPost } from '../lib/types';
import { useAppStore } from '../store/useAppStore';

function mapCloudVideo(v: CloudVideo): VideoPost {
  return {
    id: v.id,
    userId: v.user_id || 'user_cloud',
    src: v.src_url || '',
    caption: v.caption || '',
    likes: v.likes || 0,
    likedBy: Array.isArray(v.liked_by) ? (v.liked_by as string[]) : [],
    comments: Array.isArray(v.comments)
      ? (v.comments as VideoPost['comments'])
      : [],
    shares: v.shares || 0,
    category: (v.category as VideoPost['category']) || 'english',
    tags: Array.isArray(v.tags) ? (v.tags as VideoPost['tags']) : [],
    createdAt: v.created_at ? Date.parse(v.created_at) : Date.now(),
  };
}

export default function HomeFeed() {
  const localVideos = useAppStore((s) => s.videos);
  const getOrderedFeed = useAppStore((s) => s.getOrderedFeed);
  const feedCycleIds = useAppStore((s) => s.feedCycleIds);
  const [cloudTick, setCloudTick] = useState(0);

  // Always pull global cloud feed — Admin uploads appear for every device
  useEffect(() => {
    return pollCloud(
      () => cloudListVideos(),
      (rows) => {
        const mapped = (rows || [])
          .map(mapCloudVideo)
          .filter((v) => !!v.src);
        // Replace store videos with cloud truth + seed fallbacks if empty
        useAppStore.setState(() => {
          if (!mapped.length) {
            return { videos: SEED_VIDEOS };
          }
          // Prefer cloud as source of truth so deletes propagate
          const byId = new Map(mapped.map((v) => [v.id, v]));
          return {
            videos: Array.from(byId.values()).sort(
              (a, b) => (b.createdAt || 0) - (a.createdAt || 0)
            ),
          };
        });
        setCloudTick((n) => n + 1);
      },
      2000
    );
  }, []);

  const feed = useMemo(() => {
    try {
      const ordered = getOrderedFeed();
      if (ordered.length) return ordered;
    } catch {
      /* ignore */
    }
    return localVideos.length ? localVideos : SEED_VIDEOS;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [localVideos, feedCycleIds, getOrderedFeed, cloudTick]);

  return <VerticalVideoFeed videos={feed} trackHomeCycle />;
}
