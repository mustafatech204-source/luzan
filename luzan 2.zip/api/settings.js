import supabase from './db-client.js';

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const key = req.query?.key;
      if (key) {
        const { data, error } = await supabase
          .from('luzan_settings')
          .select('*')
          .eq('key', key)
          .maybeSingle();
        if (error) throw error;
        return res.status(200).json(data || { key, value: null });
      }
      const { data, error } = await supabase.from('luzan_settings').select('*');
      if (error) throw error;
      return res.status(200).json(data || []);
    }

    if (req.method === 'POST') {
      const { key, value } = req.body || {};
      if (!key) return res.status(400).json({ error: 'key required' });
      const { data, error } = await supabase
        .from('luzan_settings')
        .upsert({
          key,
          value: value ?? '',
          updated_at: new Date().toISOString(),
        })
        .select()
        .single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('settings API error:', err);
    return res.status(500).json({ error: err.message || 'server error' });
  }
}
