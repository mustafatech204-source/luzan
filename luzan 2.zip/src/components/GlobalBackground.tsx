import { useEffect } from 'react';
import { cloudGetSetting } from '../lib/cloud';
import { subscribeGlobalBg } from '../lib/globalFeed';
import { useAppStore } from '../store/useAppStore';

/** Default attached brand background */
export const DEFAULT_LUZAN_BG = '/images/luzan-bg.jpg';

export default function GlobalBackground() {
  const globalBg = useAppStore((s) => s.globalBg);
  const bg = globalBg || DEFAULT_LUZAN_BG;

  useEffect(() => {
    // Prefer cloud custom bg if set, else keep attached default
    cloudGetSetting('global_bg')
      .then((url) => {
        if (url && url !== useAppStore.getState().globalBg) {
          useAppStore.setState({ globalBg: url });
        }
      })
      .catch(() => undefined);

    try {
      return subscribeGlobalBg((url) => {
        try {
          if (url && url !== useAppStore.getState().globalBg) {
            useAppStore.setState({ globalBg: url });
          }
        } catch {
          /* ignore */
        }
      });
    } catch {
      return undefined;
    }
  }, []);

  return (
    <div
      className="pointer-events-none fixed inset-0 z-0"
      aria-hidden
      style={{ backgroundColor: '#0d0e15' }}
    >
      <div
        className="absolute inset-0"
        style={{
          backgroundImage: `url('${bg}')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat',
          backgroundAttachment: 'fixed',
        }}
      />
      {/* subtle dark overlay for glass UI readability */}
      <div className="absolute inset-0 bg-black/30" />
      <div
        className="absolute inset-0"
        style={{
          background:
            'linear-gradient(180deg, rgba(13,14,21,0.25) 0%, rgba(7,2,20,0.45) 100%)',
        }}
      />
    </div>
  );
}
