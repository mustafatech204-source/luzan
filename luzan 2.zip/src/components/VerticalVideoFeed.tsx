import { AnimatePresence, motion } from 'framer-motion';
import {
  Heart,
  MessageCircle,
  Music2,
  Send,
  Share2,
  Trash2,
  X,
} from 'lucide-react';
import { useEffect, useMemo, useRef, useState } from 'react';
import {
  formatCount,
  GlassButton,
  GlassCard,
  GlassInput,
  Overlay,
  TagRow,
} from './Glass';
import { ResolvedImg, useResolvedSrc } from './MediaSrc';
import { cloudDeleteAllVideos, cloudDeleteVideo } from '../lib/cloud';
import { t } from '../lib/i18n';
import type { VideoPost } from '../lib/types';
import { useAppStore } from '../store/useAppStore';

function FeedVideo({
  video,
  active,
  onSeen,
}: {
  video: VideoPost;
  active: boolean;
  onSeen?: () => void;
}) {
  const url = useResolvedSrc(video.src, video.mediaId);
  const ref = useRef<HTMLVideoElement>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    setFailed(false);
  }, [url, video.id]);

  useEffect(() => {
    const el = ref.current;
    if (!el || !url || failed) return;
    if (active) {
      const p = el.play();
      if (p && typeof p.catch === 'function') p.catch(() => undefined);
      try {
        onSeen?.();
      } catch {
        /* ignore */
      }
    } else {
      try {
        el.pause();
      } catch {
        /* ignore */
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active, url, failed]);

  if (!url || failed) {
    return (
      <div
        className="absolute inset-0 grid place-items-center text-white/40"
        style={{
          background:
            'linear-gradient(145deg, #1e1b4b 0%, #0d0e15 55%, #000 100%)',
        }}
      >
        {failed ? 'Video unavailable' : '…'}
      </div>
    );
  }

  return (
    <video
      ref={ref}
      src={url}
      className="absolute inset-0 h-full w-full object-cover"
      style={{ backgroundColor: '#0d0e15' }}
      loop
      muted
      playsInline
      preload="metadata"
      onError={() => setFailed(true)}
      onClick={(e) => {
        const v = e.currentTarget;
        if (v.paused) v.play().catch(() => undefined);
        else v.pause();
      }}
    />
  );
}

export default function VerticalVideoFeed({
  videos,
  startId,
  onClose,
  trackHomeCycle = false,
  showClose = false,
}: {
  videos: VideoPost[];
  startId?: string;
  onClose?: () => void;
  trackHomeCycle?: boolean;
  showClose?: boolean;
}) {
  const markFeedSeen = useAppStore((s) => s.markFeedSeen);
  const resetFeedCycleIfNeeded = useAppStore((s) => s.resetFeedCycleIfNeeded);
  const currentUser = useAppStore((s) => s.currentUser);
  const getUser = useAppStore((s) => s.getUser);
  const toggleLike = useAppStore((s) => s.toggleLike);
  const addComment = useAppStore((s) => s.addComment);
  const shareVideoToFriend = useAppStore((s) => s.shareVideoToFriend);
  const setViewingProfileId = useAppStore((s) => s.setViewingProfileId);
  const users = useAppStore((s) => s.users);
  const lang = useAppStore((s) => s.language);
  const isAdmin = !!currentUser?.isAdmin;

  const ordered = useMemo(() => {
    if (!startId) return videos;
    const idx = videos.findIndex((v) => v.id === startId);
    if (idx <= 0) return videos;
    return [...videos.slice(idx), ...videos.slice(0, idx)];
  }, [videos, startId]);

  const containerRef = useRef<HTMLDivElement>(null);
  const [activeId, setActiveId] = useState<string | undefined>(ordered[0]?.id);
  const [commentFor, setCommentFor] = useState<string | null>(null);
  const [shareFor, setShareFor] = useState<string | null>(null);
  const [commentText, setCommentText] = useState('');
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [deleting, setDeleting] = useState(false);
  const longPressTimer = useRef<number | null>(null);

  const removeLocal = (ids: string[] | 'all') => {
    useAppStore.setState((s) => ({
      videos:
        ids === 'all'
          ? []
          : s.videos.filter((v) => !ids.includes(v.id)),
    }));
  };

  const deleteThis = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await cloudDeleteVideo(deleteTarget);
    } catch (e) {
      console.error('[luzan] delete video failed', e);
    }
    removeLocal([deleteTarget]);
    setDeleting(false);
    setDeleteTarget(null);
  };

  const deleteAll = async () => {
    setDeleting(true);
    try {
      await cloudDeleteAllVideos();
    } catch (e) {
      console.error('[luzan] delete all videos failed', e);
    }
    removeLocal('all');
    setDeleting(false);
    setDeleteTarget(null);
  };

  const startLongPress = (videoId: string) => {
    if (!isAdmin) return;
    if (longPressTimer.current) window.clearTimeout(longPressTimer.current);
    longPressTimer.current = window.setTimeout(() => {
      setDeleteTarget(videoId);
    }, 550);
  };
  const endLongPress = () => {
    if (longPressTimer.current) {
      window.clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }
  };

  useEffect(() => {
    if (trackHomeCycle) resetFeedCycleIfNeeded();
  }, [videos.length, trackHomeCycle, resetFeedCycleIfNeeded]);

  useEffect(() => {
    setActiveId(ordered[0]?.id);
  }, [ordered]);

  useEffect(() => {
    const root = containerRef.current;
    if (!root) return;
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((en) => {
          if (en.isIntersecting) {
            setActiveId(en.target.getAttribute('data-id') || undefined);
          }
        });
      },
      { root, threshold: 0.65 }
    );
    root.querySelectorAll('[data-id]').forEach((el) => obs.observe(el));
    return () => obs.disconnect();
  }, [ordered.length, ordered[0]?.id]);

  const friends = useMemo(
    () => users.filter((u) => u.id !== currentUser?.id),
    [users, currentUser]
  );
  const commentVideo = videos.find((v) => v.id === commentFor);

  return (
    <div className="relative h-[100dvh] w-full bg-black no-select">
      {showClose && onClose && (
        <button
          onClick={onClose}
          className="absolute top-[max(0.75rem,env(safe-area-inset-top))] left-3 z-30 glass-icon-btn"
          aria-label="Close"
        >
          <X className="h-5 w-5" />
        </button>
      )}

      <div
        ref={containerRef}
        className="h-full snap-y snap-mandatory overflow-y-scroll overscroll-y-contain no-scrollbar pb-24"
      >
        {ordered.map((video) => {
          const author = getUser(video.userId);
          const liked = currentUser ? video.likedBy.includes(currentUser.id) : false;
          const active = activeId === video.id;

          return (
            <section
              key={video.id}
              data-id={video.id}
              className="relative h-[100dvh] w-full snap-start snap-always flex items-center justify-center overflow-hidden"
              onPointerDown={() => startLongPress(video.id)}
              onPointerUp={endLongPress}
              onPointerLeave={endLongPress}
              onPointerCancel={endLongPress}
              onContextMenu={(e) => {
                if (!isAdmin) return;
                e.preventDefault();
                setDeleteTarget(video.id);
              }}
            >
              <FeedVideo
                video={video}
                active={active}
                onSeen={
                  trackHomeCycle
                    ? () => markFeedSeen(video.id)
                    : undefined
                }
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30 pointer-events-none" />

              <div className="absolute right-3 bottom-36 z-10 flex flex-col items-center gap-5">
                <button
                  onClick={() => author && setViewingProfileId(author.id)}
                  className="relative"
                >
                  <ResolvedImg
                    src={author?.avatar}
                    mediaId={author?.avatarMediaId}
                    className="h-12 w-12 rounded-full object-cover border-2 border-white/80 shadow-lg"
                  />
                  <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 h-5 w-5 rounded-full bg-rose-500 text-[10px] font-bold grid place-items-center border border-white/40">
                    +
                  </span>
                </button>

                <Action onClick={() => toggleLike(video.id)} label={formatCount(video.likes)}>
                  <Heart
                    className={`h-8 w-8 ${liked ? 'fill-rose-500 text-rose-500' : 'text-white'}`}
                  />
                </Action>
                <Action
                  onClick={() => {
                    setCommentFor(video.id);
                    setCommentText('');
                  }}
                  label={formatCount(video.comments.length)}
                >
                  <MessageCircle className="h-8 w-8 text-white" />
                </Action>
                <Action onClick={() => setShareFor(video.id)} label={formatCount(video.shares)}>
                  <Share2 className="h-8 w-8 text-white" />
                </Action>
                {isAdmin && (
                  <Action
                    onClick={() => setDeleteTarget(video.id)}
                    label="Delete"
                  >
                    <Trash2 className="h-7 w-7 text-rose-300" />
                  </Action>
                )}
              </div>

              <div className="absolute left-0 right-16 bottom-28 z-10 px-4">
                <button
                  onClick={() => author && setViewingProfileId(author.id)}
                  className="font-semibold text-white drop-shadow"
                >
                  @{author?.username || 'user'}
                </button>
                <p className="mt-1 text-sm text-white/90 line-clamp-3 drop-shadow">{video.caption}</p>
                <TagRow tags={video.tags} className="mt-2" />
                <div className="mt-2 flex items-center gap-2 text-xs text-white/70">
                  <Music2 className="h-3.5 w-3.5" />
                  <span className="truncate">Original sound · luzan</span>
                </div>
              </div>
            </section>
          );
        })}

        {ordered.length === 0 && (
          <div className="h-full grid place-items-center text-white/50">{t(lang, 'noVideos')}</div>
        )}
      </div>

      <AnimatePresence>
        {commentFor && commentVideo && (
          <Overlay onClose={() => setCommentFor(null)}>
            <motion.div
              initial={{ y: 80, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 80, opacity: 0 }}
              className="glass-panel rounded-t-3xl sm:rounded-3xl max-h-[70dvh] flex flex-col overflow-hidden"
            >
              <div className="flex items-center justify-between px-4 py-3 border-b border-white/10">
                <h3 className="font-semibold text-white">{t(lang, 'comments')}</h3>
                <button onClick={() => setCommentFor(null)} className="glass-icon-btn">
                  <X className="h-4 w-4" />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {commentVideo.comments.map((c) => {
                  const u = getUser(c.userId);
                  return (
                    <div key={c.id} className="flex gap-3">
                      <button onClick={() => u && setViewingProfileId(u.id)}>
                        <ResolvedImg
                          src={u?.avatar}
                          mediaId={u?.avatarMediaId}
                          className="h-9 w-9 rounded-full object-cover"
                        />
                      </button>
                      <div>
                        <p className="text-xs text-white/50">@{u?.username}</p>
                        <p className="text-sm text-white">{c.text}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
              <form
                className="flex gap-2 p-3 border-t border-white/10"
                onSubmit={(e) => {
                  e.preventDefault();
                  addComment(commentFor, commentText);
                  setCommentText('');
                }}
              >
                <GlassInput
                  placeholder={t(lang, 'addComment')}
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  className="flex-1"
                />
                <GlassButton type="submit" variant="primary" className="px-3">
                  <Send className="h-4 w-4" />
                </GlassButton>
              </form>
            </motion.div>
          </Overlay>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {shareFor && (
          <Overlay onClose={() => setShareFor(null)}>
            <GlassCard
              initial={{ scale: 0.94, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.94, opacity: 0 }}
              className="m-4 p-4 max-h-[60dvh] overflow-auto"
            >
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-white">{t(lang, 'shareToFriend')}</h3>
                <button onClick={() => setShareFor(null)} className="glass-icon-btn">
                  <X className="h-4 w-4" />
                </button>
              </div>
              <div className="space-y-2">
                {friends.map((f) => (
                  <button
                    key={f.id}
                    className="w-full flex items-center gap-3 rounded-xl p-2 hover:bg-white/10 transition text-left"
                    onClick={() => {
                      shareVideoToFriend(shareFor, f.id);
                      setShareFor(null);
                    }}
                  >
                    <ResolvedImg
                      src={f.avatar}
                      mediaId={f.avatarMediaId}
                      className="h-10 w-10 rounded-full object-cover"
                    />
                    <div>
                      <p className="text-sm font-medium text-white">{f.name}</p>
                      <p className="text-xs text-white/45">@{f.username}</p>
                    </div>
                  </button>
                ))}
              </div>
            </GlassCard>
          </Overlay>
        )}
      </AnimatePresence>

      {/* Admin delete dialog */}
      <AnimatePresence>
        {deleteTarget && isAdmin && (
          <Overlay onClose={() => !deleting && setDeleteTarget(null)}>
            <GlassCard
              initial={{ scale: 0.94, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.94, opacity: 0 }}
              className="m-4 p-5"
            >
              <div className="mx-auto mb-3 h-12 w-12 rounded-2xl bg-rose-500/20 border border-rose-400/30 grid place-items-center">
                <Trash2 className="h-6 w-6 text-rose-300" />
              </div>
              <h3 className="text-lg font-bold text-white text-center mb-1">
                Delete video?
              </h3>
              <p className="text-sm text-white/55 text-center mb-5">
                Do you want to delete ONLY this video, or ALL videos?
              </p>
              <div className="space-y-2">
                <GlassButton
                  variant="danger"
                  className="w-full justify-center"
                  disabled={deleting}
                  onClick={deleteThis}
                >
                  {deleting ? 'Deleting…' : 'Delete This Video'}
                </GlassButton>
                <GlassButton
                  variant="danger"
                  className="w-full justify-center"
                  disabled={deleting}
                  onClick={deleteAll}
                >
                  {deleting ? 'Deleting…' : 'Delete All'}
                </GlassButton>
                <GlassButton
                  className="w-full justify-center"
                  disabled={deleting}
                  onClick={() => setDeleteTarget(null)}
                >
                  Cancel
                </GlassButton>
              </div>
            </GlassCard>
          </Overlay>
        )}
      </AnimatePresence>
    </div>
  );
}

function Action({
  children,
  label,
  onClick,
}: {
  children: React.ReactNode;
  label: string;
  onClick: () => void;
}) {
  return (
    <motion.button
      whileTap={{ scale: 0.85 }}
      onClick={(e) => {
        e.stopPropagation();
        onClick();
      }}
      className="flex flex-col items-center gap-1 drop-shadow-lg"
    >
      {children}
      <span className="text-xs font-medium text-white">{label}</span>
    </motion.button>
  );
}
