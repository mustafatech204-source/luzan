import { AnimatePresence, motion } from 'framer-motion';
import {
  Camera,
  Download,
  KeyRound,
  LogOut,
  Mail,
  MessageCircle,
  MoreVertical,
  User,
  UserCheck,
  UserMinus,
  UserPlus,
  Users,
  Wifi,
  X,
} from 'lucide-react';
import { useMemo, useRef, useState } from 'react';
import AdminSecurityModal from '../components/AdminSecurityModal';
import {
  formatCount,
  GlassButton,
  GlassCard,
  GlassInput,
  GlassTextarea,
  Overlay,
  TagRow,
} from '../components/Glass';
import { ResolvedImg, ResolvedVideo } from '../components/MediaSrc';
import VerticalVideoFeed from '../components/VerticalVideoFeed';
import { fileToDataUrl, saveMedia, uid } from '../lib/idb';
import { isRtl, LANG_OPTIONS, t } from '../lib/i18n';
import type { LangCode } from '../lib/types';
import { useAppStore } from '../store/useAppStore';
import LuzanAdminPanel from './LuzanAdminPanel';

export default function ProfilePage() {
  const currentUser = useAppStore((s) => s.currentUser);
  const viewingProfileId = useAppStore((s) => s.viewingProfileId);
  const setViewingProfileId = useAppStore((s) => s.setViewingProfileId);
  const getUser = useAppStore((s) => s.getUser);
  const videos = useAppStore((s) => s.videos);
  const updateProfile = useAppStore((s) => s.updateProfile);
  const toggleFollow = useAppStore((s) => s.toggleFollow);
  const getOrCreateDm = useAppStore((s) => s.getOrCreateDm);
  const setActiveChatId = useAppStore((s) => s.setActiveChatId);
  const setTab = useAppStore((s) => s.setTab);
  const logout = useAppStore((s) => s.logout);
  const setLanguage = useAppStore((s) => s.setLanguage);
  const lang = useAppStore((s) => s.language);
  const getAnalytics = useAppStore((s) => s.getAnalytics);
  const appDownloads = useAppStore((s) => s.appDownloads);
  const savedAccounts = useAppStore((s) => s.savedAccounts);
  const users = useAppStore((s) => s.users);

  const profileId = viewingProfileId || currentUser?.id;
  const profile = profileId ? getUser(profileId) || currentUser : currentUser;
  const isSelf = profile?.id === currentUser?.id;
  const isAdminSelf = !!(isSelf && currentUser?.isAdmin);

  const [drawer, setDrawer] = useState(false);
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(profile?.name || '');
  const [bio, setBio] = useState(profile?.bio || '');
  const [tab, setLocalTab] = useState<'videos' | 'liked'>('videos');
  const [adminOpen, setAdminOpen] = useState(false);
  const [securityOpen, setSecurityOpen] = useState(false);
  const [analyticsOpen, setAnalyticsOpen] = useState(false);
  const [likedFeedStart, setLikedFeedStart] = useState<string | null>(null);
  const [ownFeedStart, setOwnFeedStart] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const analytics = useMemo(() => {
    // recompute when related store slices change
    void appDownloads;
    void savedAccounts.length;
    void users.map((u) => u.online).join(',');
    return getAnalytics();
  }, [appDownloads, savedAccounts, users, getAnalytics]);

  const userVideos = useMemo(
    () => videos.filter((v) => v.userId === profile?.id),
    [videos, profile?.id]
  );
  const likedVideos = useMemo(
    () =>
      videos.filter((v) => profile && v.likedBy.includes(profile.id)),
    [videos, profile]
  );

  if (!profile || !currentUser) return null;

  const following = currentUser.followingIds.includes(profile.id);
  const displayVideos = tab === 'videos' ? userVideos : likedVideos;

  const openEdit = () => {
    setName(profile.name);
    setBio(profile.bio);
    setEditing(true);
  };

  const saveEdit = () => {
    if (!isSelf) return;
    updateProfile({ name: name.trim() || profile.name, bio: bio.trim() });
    setEditing(false);
  };

  const onAvatar = async (file?: File | null) => {
    if (!file || !isSelf || !file.type.startsWith('image/')) return;
    const id = uid('avatar');
    await saveMedia(id, file, file.name, currentUser.id);
    let dataUrl: string;
    try {
      if (file.size < 1_500_000) dataUrl = await fileToDataUrl(file);
      else dataUrl = URL.createObjectURL(file);
    } catch {
      dataUrl = URL.createObjectURL(file);
    }
    updateProfile({ avatar: dataUrl, avatarMediaId: id });
  };

  const startChat = () => {
    const chatId = getOrCreateDm(profile.id);
    setViewingProfileId(null);
    setTab('friends');
    setActiveChatId(chatId);
  };

  return (
    <div className="min-h-[100dvh] bg-[#070214] pb-28 no-select">
      <div className="relative h-36 bg-gradient-to-br from-fuchsia-700/40 via-violet-900/50 to-cyan-900/30">
        <div className="absolute top-4 left-4 right-4 flex items-center justify-between z-10">
          {viewingProfileId ? (
            <button onClick={() => setViewingProfileId(null)} className="glass-icon-btn">
              <X className="h-4 w-4" />
            </button>
          ) : (
            <div />
          )}
          {isSelf && (
            <div className="flex items-center gap-2">
              {isAdminSelf && (
                <>
                  <button
                    onClick={() => setAdminOpen(true)}
                    className="glass-icon-btn"
                    aria-label="luzan Admin"
                    title="luzan Admin"
                  >
                    <Mail className="h-5 w-5" />
                  </button>
                  <button
                    onClick={() => setSecurityOpen(true)}
                    className="glass-icon-btn"
                    aria-label="Security"
                    title="Security"
                  >
                    <KeyRound className="h-5 w-5 text-amber-200" />
                  </button>
                  <button
                    onClick={() => setAnalyticsOpen(true)}
                    className="glass-icon-btn"
                    aria-label="User analytics"
                    title="Analytics"
                  >
                    <User className="h-5 w-5" />
                  </button>
                </>
              )}
              <button
                onClick={() => setDrawer(true)}
                className="glass-icon-btn"
                aria-label="Menu"
              >
                <MoreVertical className="h-5 w-5" />
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="px-4 -mt-12 relative z-10">
        <div className="flex items-end gap-3">
          <button
            type="button"
            className="relative"
            onClick={() => isSelf && fileRef.current?.click()}
            disabled={!isSelf}
          >
            <ResolvedImg
              src={profile.avatar}
              mediaId={profile.avatarMediaId}
              className="h-24 w-24 rounded-3xl object-cover border-2 border-white/25 shadow-xl"
            />
            {isSelf && (
              <span className="absolute bottom-1 right-1 h-7 w-7 rounded-full bg-black/60 border border-white/20 grid place-items-center">
                <Camera className="h-3.5 w-3.5 text-white" />
              </span>
            )}
          </button>
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => onAvatar(e.target.files?.[0])}
          />
          <div className="flex-1 pb-1">
            <h1 className="text-xl font-bold text-white">{profile.name}</h1>
            <p className="text-sm text-white/50">@{profile.username}</p>
          </div>
        </div>

        <p className="mt-4 text-sm text-white/75 leading-relaxed">
          {profile.bio || (isSelf ? '…' : '')}
        </p>

        <div className="mt-4 grid grid-cols-3 gap-2">
          <Stat label={t(lang, 'followers')} value={formatCount(profile.followers)} />
          <Stat label={t(lang, 'following')} value={formatCount(profile.following)} />
          <Stat label={t(lang, 'likes')} value={formatCount(profile.likes)} />
        </div>

        <div className="mt-4 flex gap-2">
          {isSelf ? (
            <GlassButton className="flex-1 justify-center" onClick={openEdit}>
              {t(lang, 'editProfile')}
            </GlassButton>
          ) : (
            <>
              <GlassButton
                variant={following ? 'default' : 'primary'}
                className="flex-1 justify-center gap-2"
                onClick={() => toggleFollow(profile.id)}
              >
                {following ? (
                  <>
                    <UserMinus className="h-4 w-4" /> {t(lang, 'unfollow')}
                  </>
                ) : (
                  <>
                    <UserPlus className="h-4 w-4" /> {t(lang, 'follow')}
                  </>
                )}
              </GlassButton>
              <GlassButton className="flex-1 justify-center gap-2" onClick={startChat}>
                <MessageCircle className="h-4 w-4" /> {t(lang, 'chat')}
              </GlassButton>
            </>
          )}
        </div>

        <div className="mt-8 flex border-b border-white/10">
          <button
            className={`flex-1 py-3 text-sm font-semibold ${tab === 'videos' ? 'text-white border-b-2 border-cyan-300' : 'text-white/40'}`}
            onClick={() => setLocalTab('videos')}
          >
            {t(lang, 'videos')}
          </button>
          <button
            className={`flex-1 py-3 text-sm font-semibold ${tab === 'liked' ? 'text-white border-b-2 border-cyan-300' : 'text-white/40'}`}
            onClick={() => setLocalTab('liked')}
          >
            {t(lang, 'likedVideos')}
          </button>
        </div>

        {displayVideos.length === 0 ? (
          <GlassCard className="p-8 text-center text-sm text-white/40 mt-3">
            {t(lang, 'noVideos')}
          </GlassCard>
        ) : (
          <div className="grid grid-cols-3 gap-1.5 mt-3">
            {displayVideos.map((v) => (
              <button
                key={v.id}
                type="button"
                onClick={() => {
                  if (tab === 'liked') setLikedFeedStart(v.id);
                  else setOwnFeedStart(v.id);
                }}
                className="aspect-[9/16] rounded-xl overflow-hidden bg-white/5 relative text-left"
              >
                <ResolvedVideo
                  src={v.src}
                  mediaId={v.mediaId}
                  className="h-full w-full object-cover pointer-events-none"
                  muted
                />
                <div className="absolute bottom-1 left-1 right-1 pointer-events-none">
                  <TagRow tags={v.tags} />
                  <div className="text-[10px] text-white drop-shadow">♥ {formatCount(v.likes)}</div>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      <AnimatePresence>
        {likedFeedStart && (
          <motion.div
            className="fixed inset-0 z-[70]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <VerticalVideoFeed
              videos={likedVideos}
              startId={likedFeedStart}
              showClose
              onClose={() => setLikedFeedStart(null)}
            />
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {ownFeedStart && (
          <motion.div
            className="fixed inset-0 z-[70]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <VerticalVideoFeed
              videos={userVideos}
              startId={ownFeedStart}
              showClose
              onClose={() => setOwnFeedStart(null)}
            />
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {drawer && (
          <>
            <motion.div
              className="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setDrawer(false)}
            />
            <motion.aside
              className={`fixed top-0 z-50 h-full w-[min(86vw,320px)] glass-drawer p-5 flex flex-col ${
                isRtl(lang) ? 'left-0 border-r' : 'right-0'
              }`}
              initial={{ x: isRtl(lang) ? '-100%' : '100%' }}
              animate={{ x: 0 }}
              exit={{ x: isRtl(lang) ? '-100%' : '100%' }}
              transition={{ type: 'spring', stiffness: 320, damping: 32 }}
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-semibold text-white">{t(lang, 'menu')}</h3>
                <button onClick={() => setDrawer(false)} className="glass-icon-btn">
                  <X className="h-4 w-4" />
                </button>
              </div>

              {isAdminSelf ? (
                <div className="space-y-2">
                  <GlassButton
                    className="w-full justify-start gap-3"
                    onClick={() => {
                      setDrawer(false);
                      setAdminOpen(true);
                    }}
                  >
                    <Mail className="h-5 w-5" /> luzan Admin
                  </GlassButton>
                  <GlassButton
                    className="w-full justify-start gap-3"
                    onClick={() => {
                      setDrawer(false);
                      setSecurityOpen(true);
                    }}
                  >
                    <KeyRound className="h-5 w-5 text-amber-200" /> Security
                  </GlassButton>
                </div>
              ) : (
                <div className="space-y-3">
                  <p className="text-xs uppercase tracking-wider text-white/40">
                    {t(lang, 'language')}
                  </p>
                  <div className="space-y-1">
                    {LANG_OPTIONS.map((opt) => (
                      <button
                        key={opt.code}
                        type="button"
                        onClick={() => setLanguage(opt.code as LangCode)}
                        className={`w-full text-left rounded-xl px-3 py-2.5 text-sm ${
                          lang === opt.code
                            ? 'bg-cyan-500/20 border border-cyan-400/30 text-white'
                            : 'text-white/70 hover:bg-white/5'
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {isAdminSelf && (
                <div className="mt-4 space-y-3">
                  <p className="text-xs uppercase tracking-wider text-white/40">
                    {t(lang, 'language')}
                  </p>
                  <div className="flex flex-wrap gap-1">
                    {LANG_OPTIONS.map((opt) => (
                      <button
                        key={opt.code}
                        type="button"
                        onClick={() => setLanguage(opt.code as LangCode)}
                        className={`rounded-lg px-2 py-1 text-xs ${
                          lang === opt.code ? 'bg-white/15 text-white' : 'text-white/50'
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div className="mt-auto pt-6">
                <GlassButton
                  variant="danger"
                  className="w-full justify-center gap-2"
                  onClick={() => {
                    setDrawer(false);
                    logout();
                  }}
                >
                  <LogOut className="h-4 w-4" /> {t(lang, 'logout')}
                </GlassButton>
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {editing && (
          <motion.div
            className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <div
              className="absolute inset-0 bg-black/55 backdrop-blur-md"
              onClick={() => setEditing(false)}
            />
            <GlassCard className="relative z-10 w-full max-w-md p-5 rounded-t-3xl sm:rounded-3xl">
              <h3 className="text-lg font-semibold text-white mb-3">{t(lang, 'editProfile')}</h3>
              <label className="text-xs text-white/40">{t(lang, 'name')}</label>
              <GlassInput className="mt-1 mb-3" value={name} onChange={(e) => setName(e.target.value)} />
              <label className="text-xs text-white/40">{t(lang, 'bio')}</label>
              <GlassTextarea className="mt-1 mb-4" value={bio} onChange={(e) => setBio(e.target.value)} />
              <div className="flex gap-2">
                <GlassButton className="flex-1 justify-center" onClick={() => setEditing(false)}>
                  {t(lang, 'cancel')}
                </GlassButton>
                <GlassButton variant="primary" className="flex-1 justify-center" onClick={saveEdit}>
                  {t(lang, 'save')}
                </GlassButton>
              </div>
            </GlassCard>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {adminOpen && isAdminSelf && (
          <LuzanAdminPanel onClose={() => setAdminOpen(false)} />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {securityOpen && isAdminSelf && (
          <AdminSecurityModal onClose={() => setSecurityOpen(false)} />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {analyticsOpen && isAdminSelf && (
          <Overlay onClose={() => setAnalyticsOpen(false)} className="z-[65]">
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', stiffness: 320, damping: 34 }}
              className="glass-panel rounded-t-3xl sm:rounded-3xl p-5 pb-[max(1.5rem,env(safe-area-inset-bottom))]"
            >
              <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-white/25" />
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-2">
                  <div className="h-10 w-10 rounded-2xl bg-gradient-to-br from-cyan-400/30 to-fuchsia-500/30 border border-white/20 grid place-items-center">
                    <Users className="h-5 w-5 text-cyan-200" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white">Live analytics</h3>
                    <p className="text-xs text-white/45">Real-time local stats</p>
                  </div>
                </div>
                <button
                  onClick={() => setAnalyticsOpen(false)}
                  className="glass-icon-btn"
                  aria-label="Close"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              <div className="mt-5 space-y-3">
                <AnalyticsRow
                  icon={<Download className="h-5 w-5 text-cyan-300" />}
                  label="Total app downloads"
                  value={formatCount(analytics.downloads)}
                  hint="Installs tracked on this device cluster"
                />
                <AnalyticsRow
                  icon={<UserCheck className="h-5 w-5 text-fuchsia-300" />}
                  label="Registered accounts"
                  value={formatCount(analytics.registeredAccounts)}
                  hint="Accounts created / saved locally"
                />
                <AnalyticsRow
                  icon={<Wifi className="h-5 w-5 text-emerald-300" />}
                  label="Online users"
                  value={formatCount(analytics.onlineUsers)}
                  hint="Currently active sessions"
                />
              </div>
            </motion.div>
          </Overlay>
        )}
      </AnimatePresence>
    </div>
  );
}

function AnalyticsRow({
  icon,
  label,
  value,
  hint,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  hint: string;
}) {
  return (
    <div className="flex items-center gap-3 rounded-2xl border border-white/12 bg-white/5 px-3.5 py-3.5">
      <div className="h-11 w-11 rounded-xl bg-black/25 border border-white/10 grid place-items-center shrink-0">
        {icon}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-white">{label}</p>
        <p className="text-[11px] text-white/40 truncate">{hint}</p>
      </div>
      <p className="text-xl font-bold tabular-nums text-white">{value}</p>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="glass-panel rounded-2xl px-2 py-3 text-center">
      <p className="text-base font-bold text-white">{value}</p>
      <p className="text-[10px] uppercase tracking-wider text-white/40">{label}</p>
    </div>
  );
}
