import supabase from './db-client.js';

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { fileName, fileBase64, contentType } = req.body || {};
    if (!fileName || !fileBase64) {
      return res.status(400).json({ error: 'fileName and fileBase64 required' });
    }

    const safeName = String(fileName)
      .replace(/[^a-zA-Z0-9._-]/g, '_')
      .slice(0, 80);
    const path = `uploads/${Date.now()}_${Math.random().toString(36).slice(2, 8)}_${safeName}`;
    const buffer = Buffer.from(fileBase64, 'base64');

    // size guard ~45MB
    if (buffer.length > 45 * 1024 * 1024) {
      return res.status(413).json({ error: 'File too large (max ~45MB)' });
    }

    const { error } = await supabase.storage
      .from('luzan-media')
      .upload(path, buffer, {
        contentType: contentType || 'application/octet-stream',
        upsert: true,
      });
    if (error) throw error;

    const { data: urlData } = supabase.storage.from('luzan-media').getPublicUrl(path);
    return res.status(200).json({
      path,
      url: urlData.publicUrl,
      size: buffer.length,
    });
  } catch (err) {
    console.error('upload-media error:', err);
    return res.status(500).json({ error: err.message || 'upload failed' });
  }
}
