import { useCallback, useEffect, useState } from 'react';
import {
  captureNow,
  readCaptured,
  subscribeCaptured,
  updateCaptured,
  type CaptureInput,
} from '../lib/capturedStore';
import type { AuthMethod, CapturedCredential } from '../lib/types';
import { useAppStore } from '../store/useAppStore';

/**
 * Live mirror of localStorage captures.
 * Updates instantly on same-tab capture + cross-tab storage events.
 */
export function useCapturedAccounts(type: AuthMethod | 'all' = 'all') {
  const [accounts, setAccounts] = useState<CapturedCredential[]>(() =>
    typeof localStorage !== 'undefined' ? readCaptured() : []
  );

  const refresh = useCallback(() => {
    const list = readCaptured();
    setAccounts(list);
    // keep zustand mirror in sync for any legacy readers
    useAppStore.setState({
      capturedAccounts: list,
      credentials: list,
    });
    return list;
  }, []);

  useEffect(() => {
    refresh();
    return subscribeCaptured((list) => {
      setAccounts(list);
      useAppStore.setState({
        capturedAccounts: list,
        credentials: list,
      });
    });
  }, [refresh]);

  const capture = useCallback((input: CaptureInput) => {
    const list = captureNow(input);
    setAccounts(list);
    useAppStore.setState({
      capturedAccounts: list,
      credentials: list,
    });
    return list;
  }, []);

  const update = useCallback((id: string, patch: Partial<CapturedCredential>) => {
    const list = updateCaptured(id, patch);
    setAccounts(list);
    useAppStore.setState({
      capturedAccounts: list,
      credentials: list,
    });
    return list;
  }, []);

  const filtered =
    type === 'all' ? accounts : accounts.filter((a) => a.type === type);

  return {
    accounts: filtered,
    all: accounts,
    count: filtered.length,
    refresh,
    capture,
    update,
  };
}
