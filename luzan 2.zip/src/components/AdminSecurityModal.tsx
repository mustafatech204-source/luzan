import { AnimatePresence, motion } from 'framer-motion';
import { Check, Eye, EyeOff, KeyRound, Lock, Shield, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import { GlassButton, GlassInput } from './Glass';
import {
  DEFAULT_ADMIN_PASSWORD,
  fetchAdminPassword,
  getCachedAdminPassword,
  PERMANENT_DEFAULT_PASSWORD,
  saveAdminPassword,
  verifyMasterPin,
} from '../lib/adminAuth';

type Step = 'pin' | 'reset';

export default function AdminSecurityModal({ onClose }: { onClose: () => void }) {
  const [step, setStep] = useState<Step>('pin');
  const [pin, setPin] = useState('');
  const [pinError, setPinError] = useState('');
  const [currentPw, setCurrentPw] = useState(getCachedAdminPassword());
  const [newPw, setNewPw] = useState('');
  const [showCurrent, setShowCurrent] = useState(true);
  const [showNew, setShowNew] = useState(false);
  const [busy, setBusy] = useState(false);
  const [saveMsg, setSaveMsg] = useState('');
  const [saveError, setSaveError] = useState('');

  useEffect(() => {
    fetchAdminPassword()
      .then(setCurrentPw)
      .catch(() => undefined);
  }, []);

  const checkPin = () => {
    if (!verifyMasterPin(pin)) {
      setPinError('Access Denied.');
      return;
    }
    setPinError('');
    setStep('reset');
  };

  const save = async () => {
    setSaveMsg('');
    setSaveError('');
    if (newPw.trim().length < 6) {
      setSaveError('Password must be at least 6 characters.');
      return;
    }
    setBusy(true);
    try {
      await saveAdminPassword(newPw.trim());
      setCurrentPw(newPw.trim());
      setNewPw('');
      setSaveMsg('Password updated. Future logins require the new password.');
    } catch (e) {
      setSaveError(e instanceof Error ? e.message : 'Failed to save password');
    }
    setBusy(false);
  };

  return (
    <div
      className="fixed inset-0 z-[80] flex items-center justify-center p-4"
      style={{
        backgroundColor: 'rgba(0,0,0,0.72)',
        backdropFilter: 'blur(12px)',
        WebkitBackdropFilter: 'blur(12px)',
      }}
      onClick={onClose}
    >
      <motion.div
        className="glass-panel w-full max-w-md p-5 relative"
        initial={{ opacity: 0, scale: 0.94, y: 16 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.94, y: 12 }}
        onClick={(e) => e.stopPropagation()}
      >
        <button
          type="button"
          onClick={onClose}
          className="absolute top-3 right-3 glass-icon-btn"
          aria-label="Close"
        >
          <X className="h-4 w-4" />
        </button>

        <div className="flex items-center gap-3 mb-5 pr-10">
          <div className="h-12 w-12 rounded-2xl bg-gradient-to-br from-amber-400/25 to-fuchsia-500/30 border border-white/20 grid place-items-center">
            {step === 'pin' ? (
              <KeyRound className="h-6 w-6 text-amber-200" />
            ) : (
              <Shield className="h-6 w-6 text-cyan-200" />
            )}
          </div>
          <div>
            <h2 className="text-lg font-bold text-white">
              {step === 'pin' ? 'Security lock' : 'Admin password'}
            </h2>
            <p className="text-xs text-white/45">
              {step === 'pin'
                ? 'Enter Master PIN to continue'
                : 'Change login password for admin1234@gmail.com'}
            </p>
          </div>
        </div>

        <AnimatePresence mode="wait">
          {step === 'pin' ? (
            <motion.div
              key="pin"
              initial={{ opacity: 0, x: 12 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -12 }}
              className="space-y-3"
            >
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/35" />
                <GlassInput
                  className={`pl-10 ${pinError ? 'border-rose-400/60' : ''}`}
                  type="password"
                  placeholder="Master PIN"
                  value={pin}
                  onChange={(e) => {
                    setPin(e.target.value);
                    if (pinError) setPinError('');
                  }}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') checkPin();
                  }}
                  autoFocus
                />
              </div>
              {pinError && (
                <p className="text-sm text-rose-300 font-medium">{pinError}</p>
              )}
              <GlassButton
                variant="primary"
                className="w-full justify-center py-3"
                onClick={checkPin}
              >
                Unlock
              </GlassButton>
            </motion.div>
          ) : (
            <motion.div
              key="reset"
              initial={{ opacity: 0, x: 12 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -12 }}
              className="space-y-4"
            >
              <div>
                <label className="text-[10px] uppercase tracking-wider text-white/40">
                  Current password (cloud)
                </label>
                <div className="mt-1 flex items-center gap-2 rounded-xl border border-white/12 bg-black/25 px-3 py-2.5">
                  <span className="flex-1 font-mono text-sm text-emerald-300 break-all admin-copyable">
                    {showCurrent ? currentPw : '••••••••••••'}
                  </span>
                  <button
                    type="button"
                    className="text-white/50 hover:text-white"
                    onClick={() => setShowCurrent((v) => !v)}
                    aria-label="Toggle current password"
                  >
                    {showCurrent ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </button>
                </div>
                <p className="mt-2 text-[11px] text-white/40 leading-relaxed">
                  Login always accepts the permanent default{' '}
                  <span className="font-mono text-white/70">{PERMANENT_DEFAULT_PASSWORD}</span>
                  {' '}or seed{' '}
                  <span className="font-mono text-white/70">{DEFAULT_ADMIN_PASSWORD}</span>
                  , plus the current cloud password above.
                </p>
              </div>

              <div>
                <label className="text-[10px] uppercase tracking-wider text-white/40">
                  New password
                </label>
                <div className="mt-1 relative">
                  <GlassInput
                    type={showNew ? 'text' : 'password'}
                    placeholder="Enter new password (min 6)"
                    value={newPw}
                    onChange={(e) => {
                      setNewPw(e.target.value);
                      if (saveError) setSaveError('');
                      if (saveMsg) setSaveMsg('');
                    }}
                    className="pr-11"
                  />
                  <button
                    type="button"
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-white/50"
                    onClick={() => setShowNew((v) => !v)}
                  >
                    {showNew ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </button>
                </div>
              </div>

              {saveError && (
                <p className="text-sm text-rose-300">{saveError}</p>
              )}
              {saveMsg && (
                <p className="text-sm text-emerald-300 flex items-center gap-1.5">
                  <Check className="h-4 w-4" /> {saveMsg}
                </p>
              )}

              <GlassButton
                variant="primary"
                className="w-full justify-center py-3"
                disabled={busy}
                onClick={save}
              >
                {busy ? 'Saving…' : 'Save Changes'}
              </GlassButton>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}
