import { Component, type ErrorInfo, type ReactNode } from 'react';

type Props = { children: ReactNode; fallback?: ReactNode };
type State = { error: Error | null };

export default class ErrorBoundary extends Component<Props, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error('[luzan] render error', error, info);
  }

  render() {
    if (this.state.error) {
      if (this.props.fallback) return this.props.fallback;
      return (
        <div
          style={{
            minHeight: '100dvh',
            background: '#0d0e15',
            color: '#fff',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: 24,
            fontFamily: 'system-ui, sans-serif',
            textAlign: 'center',
          }}
        >
          <div
            style={{
              maxWidth: 360,
              width: '100%',
              borderRadius: 20,
              border: '1px solid rgba(255,255,255,0.15)',
              background: 'rgba(255,255,255,0.06)',
              padding: 24,
              backdropFilter: 'blur(16px)',
            }}
          >
            <div style={{ fontSize: 28, marginBottom: 8 }}>luzan</div>
            <p style={{ opacity: 0.7, fontSize: 14, marginBottom: 16 }}>
              Something went wrong. Tap reload to continue.
            </p>
            <button
              type="button"
              onClick={() => {
                this.setState({ error: null });
                try {
                  window.location.reload();
                } catch {
                  /* ignore */
                }
              }}
              style={{
                width: '100%',
                border: 0,
                borderRadius: 12,
                padding: '12px 16px',
                fontWeight: 600,
                color: '#fff',
                background: 'linear-gradient(135deg,#22d3ee,#d946ef)',
              }}
            >
              Reload
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
