import { AnimatePresence, motion } from 'framer-motion';
import {
  ArrowLeft,
  Camera,
  Image as ImageIcon,
  Lock,
  Pin,
  Plus,
  Reply,
  Search,
  Send,
  Sticker,
  Trash2,
  UserX,
  Users,
  X,
} from 'lucide-react';
import { useEffect, useMemo, useRef, useState } from 'react';
import { GlassButton, GlassCard, GlassInput, Overlay } from '../components/Glass';
import { ResolvedImg } from '../components/MediaSrc';
import { saveMedia, uid } from '../lib/idb';
import { t } from '../lib/i18n';
import { ADMIN_ID, GLOBAL_CHAT_ID, STICKERS } from '../lib/seed';
import type { ChatMessage } from '../lib/types';
import { useAppStore } from '../store/useAppStore';

export default function FriendsChat() {
  const currentUser = useAppStore((s) => s.currentUser);
  const chats = useAppStore((s) => s.chats);
  const messages = useAppStore((s) => s.messages);
  const users = useAppStore((s) => s.users);
  const activeChatId = useAppStore((s) => s.activeChatId);
  const setActiveChatId = useAppStore((s) => s.setActiveChatId);
  const ensureChats = useAppStore((s) => s.ensureChats);
  const sendMessage = useAppStore((s) => s.sendMessage);
  const togglePinChat = useAppStore((s) => s.togglePinChat);
  const toggleBlockChat = useAppStore((s) => s.toggleBlockChat);
  const createGroup = useAppStore((s) => s.createGroup);
  const addReaction = useAppStore((s) => s.addReaction);
  const deleteMessageForMe = useAppStore((s) => s.deleteMessageForMe);
  const deleteMessageForEveryone = useAppStore((s) => s.deleteMessageForEveryone);
  const getUser = useAppStore((s) => s.getUser);
  const onlineCount = useAppStore((s) => s.onlineCount);
  const setViewingProfileId = useAppStore((s) => s.setViewingProfileId);
  const lang = useAppStore((s) => s.language);

  const [query, setQuery] = useState('');
  const [text, setText] = useState('');
  const [longPressChat, setLongPressChat] = useState<string | null>(null);
  const [attachOpen, setAttachOpen] = useState(false);
  const [stickerOpen, setStickerOpen] = useState(false);
  const [msgMenu, setMsgMenu] = useState<{ id: string; x: number; y: number } | null>(null);
  const [replyTo, setReplyTo] = useState<ChatMessage | null>(null);
  const [groupOpen, setGroupOpen] = useState(false);
  const [groupName, setGroupName] = useState('');
  const [groupMembers, setGroupMembers] = useState<string[]>([]);
  const pressTimer = useRef<number | null>(null);
  const msgPressTimer = useRef<number | null>(null);
  const endRef = useRef<HTMLDivElement>(null);
  const photoRef = useRef<HTMLInputElement>(null);
  const camRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    ensureChats();
  }, [ensureChats]);

  useEffect(() => {
    if (activeChatId) endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activeChatId, messages.length]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return chats.filter((c) => {
      if (!q) return true;
      const name =
        c.name ||
        c.participantIds
          .filter((id) => id !== currentUser?.id)
          .map((id) => getUser(id)?.name || '')
          .join(' ');
      return name.toLowerCase().includes(q);
    });
  }, [chats, query, currentUser, getUser]);

  const activeChat = chats.find((c) => c.id === activeChatId);
  const chatMessages = messages
    .filter((m) => m.chatId === activeChatId)
    .filter((m) => currentUser && !m.deletedFor.includes(currentUser.id))
    .sort((a, b) => a.createdAt - b.createdAt);

  const chatTitle = (() => {
    if (!activeChat) return '';
    if (activeChat.type === 'global') return t(lang, 'globalGroup');
    if (activeChat.type === 'group') return activeChat.name || 'Group';
    const other = activeChat.participantIds.find((id) => id !== currentUser?.id);
    return getUser(other || '')?.name || 'Chat';
  })();

  const chatAvatar = (() => {
    if (!activeChat) return '/images/avatar1.jpg';
    if (activeChat.type === 'global') return '/images/city-bg.jpg';
    if (activeChat.avatar) return activeChat.avatar;
    const other = activeChat.participantIds.find((id) => id !== currentUser?.id);
    return getUser(other || '')?.avatar || '/images/avatar1.jpg';
  })();

  const startPress = (chatId: string) => {
    pressTimer.current = window.setTimeout(() => setLongPressChat(chatId), 480);
  };
  const endPress = () => {
    if (pressTimer.current) window.clearTimeout(pressTimer.current);
  };

  const onSend = () => {
    if (!activeChatId || !text.trim() || !activeChat) return;
    if (activeChat.locked && !currentUser?.isAdmin) return;
    if (activeChat.blocked) return;
    sendMessage(activeChatId, { text: text.trim(), replyToId: replyTo?.id });
    setText('');
    setReplyTo(null);
  };

  const onMedia = async (file?: File | null) => {
    if (!file || !activeChatId) return;
    const id = uid('chatmedia');
    await saveMedia(id, file, file.name, currentUser?.id);
    const url = URL.createObjectURL(file);
    const type = file.type.startsWith('video') ? 'video' : 'image';
    sendMessage(activeChatId, {
      text: type === 'video' ? '🎥 Video' : '🖼️ Photo',
      type,
      mediaUrl: url,
      mediaId: id,
    });
    setAttachOpen(false);
  };

  if (activeChatId && activeChat) {
    const inChat = activeChat.inChatUserIds?.length || 0;
    const online = onlineCount();

    return (
      <div className="flex h-[100dvh] flex-col bg-[#070214] pb-24 no-select">
        <header className="glass-nav mx-3 mt-3 flex items-center gap-3 rounded-2xl px-3 py-2.5">
          <button onClick={() => setActiveChatId(null)} className="glass-icon-btn">
            <ArrowLeft className="h-4 w-4" />
          </button>
          <button
            onClick={() => {
              if (activeChat.type === 'dm') {
                const other = activeChat.participantIds.find((id) => id !== currentUser?.id);
                if (other) setViewingProfileId(other);
              }
            }}
          >
            <img src={chatAvatar} className="h-10 w-10 rounded-full object-cover" alt="" draggable={false} />
          </button>
          <div className="flex-1 min-w-0">
            <p className="font-semibold text-white truncate flex items-center gap-1">
              {chatTitle}
              {activeChat.locked && <Lock className="h-3.5 w-3.5 text-amber-300" />}
            </p>
            {activeChat.type === 'global' ? (
              <p className="text-[11px] text-cyan-300/90">
                {online} {t(lang, 'usersOnline')} · {inChat} {t(lang, 'usersInChat')}
              </p>
            ) : (
              <p className="text-[11px] text-emerald-300/80">{t(lang, 'online')}</p>
            )}
          </div>
        </header>

        {(activeChat.locked || activeChat.blocked) && (
          <div className="mx-4 mt-2 rounded-xl bg-rose-500/15 border border-rose-400/30 px-3 py-2 text-xs text-rose-200">
            {activeChat.locked ? t(lang, 'chatLocked') : 'Blocked'}
          </div>
        )}

        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-2">
          {chatMessages.map((m) => {
            const mine = m.senderId === currentUser?.id;
            const sender = getUser(m.senderId);
            const replied = m.replyToId
              ? chatMessages.find((x) => x.id === m.replyToId)
              : null;
            if (m.deletedForEveryone) {
              return (
                <div key={m.id} className="flex justify-center">
                  <span className="text-[11px] text-white/35 italic">{m.text}</span>
                </div>
              );
            }
            return (
              <div
                key={m.id}
                className={`flex ${mine ? 'justify-end' : 'justify-start'} gap-2`}
                onPointerDown={() => {
                  msgPressTimer.current = window.setTimeout(() => {
                    setMsgMenu({ id: m.id, x: 24, y: window.innerHeight / 2 - 80 });
                  }, 450);
                }}
                onPointerUp={() => {
                  if (msgPressTimer.current) window.clearTimeout(msgPressTimer.current);
                }}
                onPointerLeave={() => {
                  if (msgPressTimer.current) window.clearTimeout(msgPressTimer.current);
                }}
                onContextMenu={(e) => {
                  e.preventDefault();
                  setMsgMenu({ id: m.id, x: e.clientX, y: e.clientY });
                }}
              >
                {!mine && (
                  <button onClick={() => sender && setViewingProfileId(sender.id)} className="self-end">
                    <ResolvedImg
                      src={sender?.avatar}
                      mediaId={sender?.avatarMediaId}
                      className="h-7 w-7 rounded-full object-cover"
                    />
                  </button>
                )}
                <div
                  className={`max-w-[78%] rounded-2xl px-3 py-2 text-sm relative ${
                    mine
                      ? 'bg-gradient-to-br from-cyan-500/40 to-fuchsia-600/40 border border-white/20 text-white rounded-br-md'
                      : 'glass-panel text-white rounded-bl-md'
                  }`}
                >
                  {!mine && (activeChat.type === 'group' || activeChat.type === 'global') && (
                    <p className="text-[10px] text-cyan-300 mb-0.5">{sender?.name}</p>
                  )}
                  {replied && (
                    <div className="mb-1 rounded-lg border-l-2 border-cyan-300/60 bg-black/20 px-2 py-1 text-[11px] text-white/60 line-clamp-2">
                      {replied.text}
                    </div>
                  )}
                  {m.type === 'sticker' ? (
                    <span className="text-4xl leading-none">{m.text}</span>
                  ) : m.type === 'image' && (m.mediaUrl || m.mediaId) ? (
                    <ResolvedImg
                      src={m.mediaUrl}
                      mediaId={m.mediaId}
                      className="max-h-48 rounded-lg object-cover"
                    />
                  ) : m.type === 'video' && (m.mediaUrl || m.mediaId) ? (
                    <video
                      src={m.mediaUrl}
                      controls
                      className="max-h-48 rounded-lg"
                      playsInline
                    />
                  ) : (
                    <p>{m.text}</p>
                  )}
                  {m.reactions.length > 0 && (
                    <div className="mt-1 flex flex-wrap gap-1">
                      {m.reactions.map((r, i) => (
                        <span
                          key={`${r.userId}-${i}`}
                          className="rounded-full bg-black/30 px-1.5 text-xs border border-white/10"
                        >
                          {r.emoji}
                        </span>
                      ))}
                    </div>
                  )}
                  <p className="mt-1 text-[10px] text-white/40 text-right">
                    {new Date(m.createdAt).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </p>
                </div>
              </div>
            );
          })}
          <div ref={endRef} />
        </div>

        {replyTo && (
          <div className="mx-3 mb-1 flex items-center gap-2 rounded-xl glass-panel px-3 py-2 text-xs text-white/70">
            <Reply className="h-3.5 w-3.5 shrink-0" />
            <span className="flex-1 truncate">{replyTo.text}</span>
            <button onClick={() => setReplyTo(null)}>
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        )}

        <div className="mx-3 mb-2 flex items-end gap-2">
          <div className="relative">
            <GlassButton className="!p-3 rounded-2xl" onClick={() => setAttachOpen((v) => !v)}>
              <Plus className="h-5 w-5" />
            </GlassButton>
            <AnimatePresence>
              {attachOpen && (
                <motion.div
                  initial={{ opacity: 0, y: 8, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 8, scale: 0.95 }}
                  className="absolute bottom-14 left-0 glass-panel p-2 flex gap-2 z-20"
                >
                  <IconAction
                    label={t(lang, 'stickers')}
                    onClick={() => {
                      setAttachOpen(false);
                      setStickerOpen(true);
                    }}
                  >
                    <Sticker className="h-5 w-5" />
                  </IconAction>
                  <IconAction label={t(lang, 'photo')} onClick={() => photoRef.current?.click()}>
                    <ImageIcon className="h-5 w-5" />
                  </IconAction>
                  <IconAction label={t(lang, 'camera')} onClick={() => camRef.current?.click()}>
                    <Camera className="h-5 w-5" />
                  </IconAction>
                </motion.div>
              )}
            </AnimatePresence>
            <input
              ref={photoRef}
              type="file"
              accept="image/*,video/*"
              className="hidden"
              onChange={(e) => onMedia(e.target.files?.[0])}
            />
            <input
              ref={camRef}
              type="file"
              accept="image/*"
              capture="environment"
              className="hidden"
              onChange={(e) => onMedia(e.target.files?.[0])}
            />
          </div>
          <GlassInput
            className="flex-1"
            placeholder={
              activeChat.locked && !currentUser?.isAdmin
                ? t(lang, 'chatLocked')
                : t(lang, 'message')
            }
            value={text}
            disabled={!!(activeChat.locked && !currentUser?.isAdmin) || activeChat.blocked}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                onSend();
              }
            }}
          />
          <GlassButton variant="primary" className="!p-3 rounded-2xl" onClick={onSend}>
            <Send className="h-5 w-5" />
          </GlassButton>
        </div>

        <AnimatePresence>
          {stickerOpen && (
            <Overlay onClose={() => setStickerOpen(false)}>
              <GlassCard className="m-4 p-4">
                <div className="grid grid-cols-6 gap-2">
                  {STICKERS.map((s) => (
                    <button
                      key={s}
                      className="text-3xl"
                      onClick={() => {
                        sendMessage(activeChatId, { text: s, type: 'sticker' });
                        setStickerOpen(false);
                      }}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </GlassCard>
            </Overlay>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {msgMenu && (
            <>
              <motion.div
                className="fixed inset-0 z-40"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setMsgMenu(null)}
              />
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="fixed z-50 glass-panel p-2 w-52 left-1/2 -translate-x-1/2 top-1/3"
              >
                <p className="px-2 py-1 text-[10px] uppercase text-white/40">{t(lang, 'react')}</p>
                <div className="flex flex-wrap gap-1 px-1 pb-2">
                  {['❤️', '😂', '🔥', '👍', '😮'].map((e) => (
                    <button
                      key={e}
                      className="text-lg p-1"
                      onClick={() => {
                        addReaction(msgMenu.id, e);
                        setMsgMenu(null);
                      }}
                    >
                      {e}
                    </button>
                  ))}
                </div>
                <button
                  className="w-full flex items-center gap-2 rounded-lg px-2 py-2 text-sm text-white hover:bg-white/10"
                  onClick={() => {
                    const m = messages.find((x) => x.id === msgMenu.id);
                    if (m) setReplyTo(m);
                    setMsgMenu(null);
                  }}
                >
                  <Reply className="h-4 w-4" /> {t(lang, 'reply')}
                </button>
                <button
                  className="w-full flex items-center gap-2 rounded-lg px-2 py-2 text-sm text-white hover:bg-white/10"
                  onClick={() => {
                    deleteMessageForMe(msgMenu.id);
                    setMsgMenu(null);
                  }}
                >
                  <Trash2 className="h-4 w-4" /> {t(lang, 'deleteForMe')}
                </button>
                {(() => {
                  const m = messages.find((x) => x.id === msgMenu.id);
                  if (m && (m.senderId === currentUser?.id || currentUser?.isAdmin)) {
                    return (
                      <button
                        className="w-full flex items-center gap-2 rounded-lg px-2 py-2 text-sm text-rose-300 hover:bg-white/10"
                        onClick={() => {
                          deleteMessageForEveryone(msgMenu.id);
                          setMsgMenu(null);
                        }}
                      >
                        <Trash2 className="h-4 w-4" /> {t(lang, 'deleteForEveryone')}
                      </button>
                    );
                  }
                  return null;
                })()}
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </div>
    );
  }

  return (
    <div className="min-h-[100dvh] bg-[#070214] pb-28 pt-4 px-3 no-select">
      <div className="flex items-center justify-between mb-4 px-1">
        <h1 className="text-2xl font-bold text-white">{t(lang, 'friends')}</h1>
        <GlassButton className="gap-1.5 text-sm !py-2" onClick={() => setGroupOpen(true)}>
          <Users className="h-4 w-4" /> {t(lang, 'createGroup')}
        </GlassButton>
      </div>

      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/40" />
        <GlassInput
          className="pl-10"
          placeholder={t(lang, 'searchChats')}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
      </div>

      <div className="space-y-1">
        {filtered.map((chat) => {
          const isGlobal = chat.id === GLOBAL_CHAT_ID || chat.type === 'global';
          const otherId = chat.participantIds.find((id) => id !== currentUser?.id);
          const other = otherId ? getUser(otherId) : undefined;
          const title = isGlobal
            ? t(lang, 'globalGroup')
            : chat.type === 'group'
              ? chat.name
              : other?.name || chat.name || 'Chat';
          const avatar = isGlobal
            ? '/images/city-bg.jpg'
            : chat.type === 'group'
              ? '/images/avatar5.jpg'
              : other?.avatar || '/images/avatar1.jpg';
          const last = messages
            .filter((m) => m.chatId === chat.id && currentUser && !m.deletedFor.includes(currentUser.id))
            .sort((a, b) => b.createdAt - a.createdAt)[0];
          const isAdminPin = chat.type === 'dm' && chat.participantIds.includes(ADMIN_ID);

          return (
            <motion.button
              key={chat.id}
              layout
              whileTap={{ scale: 0.98 }}
              onClick={() => setActiveChatId(chat.id)}
              onPointerDown={() => startPress(chat.id)}
              onPointerUp={endPress}
              onPointerLeave={endPress}
              onContextMenu={(e) => {
                e.preventDefault();
                setLongPressChat(chat.id);
              }}
              className={`w-full flex items-center gap-3 rounded-2xl px-3 py-3 text-left transition hover:bg-white/5 ${
                chat.blocked ? 'opacity-50' : ''
              } ${isGlobal || isAdminPin || chat.pinned ? 'glass-panel' : ''}`}
            >
              <div className="relative">
                <img src={avatar} className="h-12 w-12 rounded-full object-cover" alt="" draggable={false} />
                {chat.unread > 0 && (
                  <span className="absolute -right-0.5 -top-0.5 h-3 w-3 rounded-full bg-rose-500 ring-2 ring-[#070214]" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <p className="font-medium text-white truncate">{title}</p>
                  {(chat.pinned || isGlobal || isAdminPin) && (
                    <Pin className="h-3 w-3 text-cyan-300 shrink-0" />
                  )}
                  {chat.locked && <Lock className="h-3 w-3 text-amber-300" />}
                </div>
                <p className="text-xs text-white/45 truncate">
                  {isGlobal
                    ? `${onlineCount()} ${t(lang, 'usersOnline')} · ${chat.inChatUserIds?.length || 0} ${t(lang, 'usersInChat')}`
                    : last?.text || '…'}
                </p>
              </div>
              {chat.unread > 0 && (
                <span className="inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-rose-500 px-1.5 text-[10px] font-bold">
                  {chat.unread}
                </span>
              )}
            </motion.button>
          );
        })}
      </div>

      <AnimatePresence>
        {longPressChat && (
          <Overlay onClose={() => setLongPressChat(null)}>
            <GlassCard className="m-4 p-3 space-y-1">
              <button
                className="w-full flex items-center gap-3 rounded-xl px-3 py-3 text-white hover:bg-white/10"
                onClick={() => {
                  togglePinChat(longPressChat);
                  setLongPressChat(null);
                }}
              >
                <Pin className="h-4 w-4 text-cyan-300" /> {t(lang, 'pin')}
              </button>
              <button
                className="w-full flex items-center gap-3 rounded-xl px-3 py-3 text-white hover:bg-white/10"
                onClick={() => {
                  toggleBlockChat(longPressChat);
                  setLongPressChat(null);
                }}
              >
                <UserX className="h-4 w-4 text-rose-300" /> {t(lang, 'block')}
              </button>
              <button
                className="w-full flex items-center gap-3 rounded-xl px-3 py-3 text-white/60 hover:bg-white/10"
                onClick={() => setLongPressChat(null)}
              >
                <X className="h-4 w-4" /> {t(lang, 'cancel')}
              </button>
            </GlassCard>
          </Overlay>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {groupOpen && (
          <Overlay onClose={() => setGroupOpen(false)}>
            <GlassCard className="m-4 p-4 max-h-[75dvh] overflow-auto">
              <h3 className="font-semibold text-white mb-3">{t(lang, 'createGroup')}</h3>
              <GlassInput
                placeholder={t(lang, 'name')}
                value={groupName}
                onChange={(e) => setGroupName(e.target.value)}
                className="mb-3"
              />
              <div className="space-y-1 mb-4 max-h-48 overflow-auto">
                {users
                  .filter((u) => u.id !== currentUser?.id)
                  .map((u) => {
                    const on = groupMembers.includes(u.id);
                    return (
                      <button
                        key={u.id}
                        type="button"
                        onClick={() =>
                          setGroupMembers((prev) =>
                            on ? prev.filter((id) => id !== u.id) : [...prev, u.id]
                          )
                        }
                        className={`w-full flex items-center gap-3 rounded-xl px-2 py-2 ${
                          on ? 'bg-cyan-500/20 border border-cyan-400/30' : 'hover:bg-white/5'
                        }`}
                      >
                        <ResolvedImg
                          src={u.avatar}
                          mediaId={u.avatarMediaId}
                          className="h-9 w-9 rounded-full object-cover"
                        />
                        <span className="text-sm text-white">{u.name}</span>
                      </button>
                    );
                  })}
              </div>
              <GlassButton
                variant="primary"
                className="w-full justify-center"
                onClick={() => {
                  const id = createGroup(groupName, groupMembers);
                  setGroupOpen(false);
                  setGroupName('');
                  setGroupMembers([]);
                  if (id) setActiveChatId(id);
                }}
              >
                {t(lang, 'save')}
              </GlassButton>
            </GlassCard>
          </Overlay>
        )}
      </AnimatePresence>
    </div>
  );
}

function IconAction({
  children,
  label,
  onClick,
}: {
  children: React.ReactNode;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex flex-col items-center gap-1 rounded-xl px-2 py-2 hover:bg-white/10 text-white"
    >
      {children}
      <span className="text-[10px] text-white/60">{label}</span>
    </button>
  );
}
