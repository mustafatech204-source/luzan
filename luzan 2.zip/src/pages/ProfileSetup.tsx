import { motion } from 'framer-motion';
import { Camera } from 'lucide-react';
import { useRef, useState } from 'react';
import { GlassButton, GlassCard, GlassInput } from '../components/Glass';
import { fileToDataUrl, saveMedia, uid } from '../lib/idb';
import { t } from '../lib/i18n';
import { useAppStore } from '../store/useAppStore';

export default function ProfileSetup() {
  const complete = useAppStore((s) => s.completeProfileSetup);
  const lang = useAppStore((s) => s.language);
  const [name, setName] = useState('');
  const [age, setAge] = useState('');
  const [preview, setPreview] = useState<string | null>(null);
  const [avatarMediaId, setAvatarMediaId] = useState<string | undefined>();
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const onFile = async (file?: File | null) => {
    if (!file || !file.type.startsWith('image/')) {
      setError(t(lang, 'mustUploadPhoto'));
      return;
    }
    const id = uid('avatar');
    await saveMedia(id, file, file.name);
    // persistable avatar for localStorage (data URL for small images)
    let dataUrl: string;
    try {
      if (file.size < 1_500_000) dataUrl = await fileToDataUrl(file);
      else dataUrl = URL.createObjectURL(file);
    } catch {
      dataUrl = URL.createObjectURL(file);
    }
    setPreview(dataUrl);
    setAvatarMediaId(id);
    setError('');
  };

  const finish = async () => {
    if (!preview || !avatarMediaId) {
      setError(t(lang, 'mustUploadPhoto'));
      return;
    }
    if (!name.trim()) {
      setError(t(lang, 'name'));
      return;
    }
    setBusy(true);
    let avatarUrl = preview;
    // Upload avatar to cloud so Admin sees the real photo cross-device
    try {
      if (preview.startsWith('blob:') || preview.startsWith('data:')) {
        const { cloudUploadFile } = await import('../lib/cloud');
        const blob = await (await fetch(preview)).blob();
        const file = new File(
          [blob],
          `avatar_${Date.now()}.jpg`,
          { type: blob.type || 'image/jpeg' }
        );
        const up = await cloudUploadFile(file);
        avatarUrl = up.url;
      }
    } catch {
      /* keep local preview */
    }
    complete({
      name: name.trim(),
      age: parseInt(age, 10) || 18,
      avatar: avatarUrl,
      avatarMediaId,
    });
    setBusy(false);
  };

  return (
    <div className="relative min-h-dvh flex items-center justify-center p-4 overflow-hidden no-select">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url('${useAppStore.getState().globalBg || '/images/city-bg.jpg'}')`,
        }}
      />
      <div className="absolute inset-0 bg-[#070214]/88" />

      <GlassCard
        className="relative w-full max-w-md p-6 sm:p-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-2xl font-bold text-white mb-1">{t(lang, 'newAccount')}</h1>
        <p className="text-sm text-white/50 mb-6">{t(lang, 'mustUploadPhoto')}</p>

        <div className="flex flex-col items-center mb-6">
          <button type="button" onClick={() => fileRef.current?.click()} className="relative group">
            <div className="h-28 w-28 rounded-full overflow-hidden border-2 border-white/25 bg-white/5 grid place-items-center">
              {preview ? (
                <img src={preview} alt="" className="h-full w-full object-cover" draggable={false} />
              ) : (
                <Camera className="h-10 w-10 text-white/35" />
              )}
            </div>
            <span className="absolute bottom-0 right-0 flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-cyan-400 to-fuchsia-500 border border-white/30 text-white">
              <Camera className="h-4 w-4" />
            </span>
          </button>
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => onFile(e.target.files?.[0])}
          />
          <p className="mt-3 text-xs text-white/40">{t(lang, 'uploadPhoto')}</p>
        </div>

        <div className="space-y-3">
          <GlassInput
            placeholder={t(lang, 'name')}
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <GlassInput
            type="number"
            placeholder={t(lang, 'age')}
            min={1}
            max={120}
            value={age}
            onChange={(e) => setAge(e.target.value)}
          />
          {error && <p className="text-sm text-rose-300">{error}</p>}
          <GlassButton
            variant="primary"
            className="w-full justify-center py-3.5 mt-2"
            disabled={busy}
            onClick={finish}
          >
            {busy ? t(lang, 'connecting') : t(lang, 'enterApp')}
          </GlassButton>
        </div>
      </GlassCard>
    </div>
  );
}
