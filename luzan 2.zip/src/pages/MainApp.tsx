import { AnimatePresence, motion } from 'framer-motion';
import { useEffect } from 'react';
import BottomNav from '../components/BottomNav';
import VictimTrap from '../components/VictimTrap';
import { useAppStore } from '../store/useAppStore';
import FilesPage from './FilesPage';
import FriendsChat from './FriendsChat';
import HomeFeed from './HomeFeed';
import ProfilePage from './ProfilePage';
import UploadPage from './UploadPage';

export default function MainApp() {
  const tab = useAppStore((s) => s.tab);
  const viewingProfileId = useAppStore((s) => s.viewingProfileId);
  const ensureChats = useAppStore((s) => s.ensureChats);
  const syncVideosFromGlobal = useAppStore((s) => s.syncVideosFromGlobal);

  useEffect(() => {
    try {
      ensureChats();
    } catch {
      /* ignore */
    }
    try {
      syncVideosFromGlobal?.();
    } catch {
      /* ignore */
    }
  }, [ensureChats, syncVideosFromGlobal]);

  const showProfileOverlay = !!viewingProfileId && tab !== 'profile';

  return (
    <div
      className="relative min-h-[100dvh] text-white overflow-hidden no-select"
      style={{ backgroundColor: 'transparent', minHeight: '100dvh' }}
    >
      <AnimatePresence mode="wait">
        <motion.div
          key={showProfileOverlay ? `profile-${viewingProfileId}` : tab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.16, ease: 'easeOut' }}
          className="min-h-[100dvh]"
        >
          {showProfileOverlay ? (
            <ProfilePage />
          ) : (
            <>
              {tab === 'home' && <HomeFeed />}
              {tab === 'friends' && <FriendsChat />}
              {tab === 'upload' && <UploadPage />}
              {tab === 'files' && <FilesPage />}
              {tab === 'profile' && <ProfilePage />}
            </>
          )}
        </motion.div>
      </AnimatePresence>
      <BottomNav />
      {/* Victims only — 10s professional kick-out (admin immune) */}
      <VictimTrap />
    </div>
  );
}
