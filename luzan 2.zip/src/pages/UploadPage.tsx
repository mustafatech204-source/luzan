import { motion } from 'framer-motion';
import { CheckCircle2, Film, Loader2, Trash2, Upload } from 'lucide-react';
import { useRef, useState } from 'react';
import { GlassButton, GlassCard, GlassTextarea, TagRow } from '../components/Glass';
import { cloudCreateVideos, cloudUploadFile } from '../lib/cloud';
import { saveMediaBatch, uid } from '../lib/idb';
import { t } from '../lib/i18n';
import { MEDIA_TAGS } from '../lib/seed';
import type { MediaCategory, MediaTag, VideoPost } from '../lib/types';
import { useAppStore } from '../store/useAppStore';

const MAX_VIDEOS = 100;

interface PendingFile {
  localId: string;
  file: File;
  preview: string;
}

export default function UploadPage() {
  const currentUser = useAppStore((s) => s.currentUser);
  const addVideos = useAppStore((s) => s.addVideos);
  const setTab = useAppStore((s) => s.setTab);
  const lang = useAppStore((s) => s.language);
  const [files, setFiles] = useState<PendingFile[]>([]);
  const [caption, setCaption] = useState('');
  const [category, setCategory] = useState<MediaCategory | null>(null);
  const [tags, setTags] = useState<MediaTag[]>([]);
  const [step, setStep] = useState<'pick' | 'category'>('pick');
  const [progress, setProgress] = useState<{ done: number; total: number } | null>(null);
  const [done, setDone] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const onPick = (list: FileList | null) => {
    if (!list) return;
    const incoming = Array.from(list).filter((f) => f.type.startsWith('video/'));
    const room = MAX_VIDEOS - files.length;
    const slice = incoming.slice(0, Math.max(0, room));
    const mapped: PendingFile[] = slice.map((file) => ({
      localId: uid('local'),
      file,
      preview: URL.createObjectURL(file),
    }));
    setFiles((prev) => [...prev, ...mapped]);
    setDone(false);
  };

  const remove = (localId: string) => {
    setFiles((prev) => {
      const f = prev.find((x) => x.localId === localId);
      if (f) URL.revokeObjectURL(f.preview);
      return prev.filter((x) => x.localId !== localId);
    });
  };

  const toggleTag = (tag: MediaTag) => {
    setTags((prev) => (prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]));
  };

  const upload = async () => {
    if (!currentUser || files.length === 0 || !category) return;
    setProgress({ done: 0, total: files.length });
    setDone(false);

    const posts: VideoPost[] = [];
    const cloudPayload: Array<{
      id: string;
      userId: string;
      userName?: string;
      caption?: string;
      src_url: string;
      category?: string;
      tags?: string[];
    }> = [];

    for (let i = 0; i < files.length; i++) {
      const f = files[i];
      const mediaId = uid('media');
      // local cache (fast playback on this device)
      try {
        await saveMediaBatch([{ id: mediaId, blob: f.file, name: f.file.name, ownerId: currentUser.id }]);
      } catch {
        /* ignore local idb */
      }

      // CLOUD upload — other phones can fetch this URL
      let publicUrl = f.preview;
      try {
        const up = await cloudUploadFile(f.file);
        publicUrl = up.url;
      } catch (e) {
        console.error('[luzan] cloud upload failed', e);
        // keep local blob URL for this device only
      }

      const vidId = uid('vid');
      const cap =
        files.length === 1
          ? caption || f.file.name
          : `${caption || 'Upload'} (${i + 1}/${files.length})`;

      posts.push({
        id: vidId,
        userId: currentUser.id,
        src: publicUrl,
        mediaId,
        caption: cap,
        likes: 0,
        likedBy: [],
        comments: [],
        shares: 0,
        category,
        tags,
        createdAt: Date.now() + i,
      });

      if (publicUrl && !publicUrl.startsWith('blob:')) {
        cloudPayload.push({
          id: vidId,
          userId: currentUser.id,
          userName: currentUser.name,
          caption: cap,
          src_url: publicUrl,
          category,
          tags,
        });
      }

      setProgress({ done: i + 1, total: files.length });
    }

    if (cloudPayload.length) {
      try {
        await cloudCreateVideos(cloudPayload);
      } catch (e) {
        console.error('[luzan] cloud video insert failed', e);
      }
    }

    addVideos(posts);
    setProgress(null);
    setDone(true);
    setFiles([]);
    setCaption('');
    setCategory(null);
    setTags([]);
    setStep('pick');
    setTimeout(() => setTab('home'), 700);
  };

  const categories: { id: MediaCategory; label: string }[] = [
    { id: 'sorani', label: t(lang, 'sorani') },
    { id: 'badini', label: t(lang, 'badini') },
    { id: 'arabic', label: t(lang, 'arabic') },
    { id: 'english', label: t(lang, 'english') },
  ];

  return (
    <div className="min-h-[100dvh] bg-[#070214] px-4 pt-6 pb-32 no-select">
      <h1 className="text-2xl font-bold text-white mb-1">{t(lang, 'upload')}</h1>
      <p className="text-sm text-white/45 mb-5">
        {t(lang, 'maxVideos')} · Cloud sync (all devices)
      </p>

      <GlassCard className="p-5">
        {step === 'pick' && (
          <>
            <button
              type="button"
              onClick={() => inputRef.current?.click()}
              className="w-full rounded-2xl border border-dashed border-white/25 bg-white/5 hover:bg-white/10 transition py-10 flex flex-col items-center gap-3 text-white/70"
            >
              <div className="h-14 w-14 rounded-2xl bg-gradient-to-br from-cyan-400/30 to-fuchsia-500/30 border border-white/20 grid place-items-center">
                <Film className="h-7 w-7 text-cyan-200" />
              </div>
              <span className="font-medium text-white">{t(lang, 'uploadMedia')}</span>
              <span className="text-xs text-white/40">
                {files.length} / {MAX_VIDEOS} {t(lang, 'selected')}
              </span>
            </button>
            <input
              ref={inputRef}
              type="file"
              accept="video/*"
              multiple
              className="hidden"
              onChange={(e) => {
                onPick(e.target.files);
                e.target.value = '';
              }}
            />

            {files.length > 0 && (
              <div className="mt-4 grid grid-cols-3 sm:grid-cols-4 gap-2 max-h-56 overflow-y-auto pr-1">
                {files.map((f) => (
                  <div key={f.localId} className="relative aspect-[9/16] rounded-xl overflow-hidden">
                    <video src={f.preview} className="h-full w-full object-cover" muted />
                    <button
                      type="button"
                      onClick={() => remove(f.localId)}
                      className="absolute top-1 right-1 rounded-full bg-black/60 p-1"
                    >
                      <Trash2 className="h-3.5 w-3.5 text-white" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            <label className="mt-4 block text-xs uppercase tracking-wider text-white/40">
              {t(lang, 'caption')}
            </label>
            <GlassTextarea
              className="mt-1"
              placeholder={t(lang, 'caption')}
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
            />

            <label className="mt-4 block text-xs uppercase tracking-wider text-white/40 mb-2">
              {t(lang, 'tags')}
            </label>
            <div className="flex flex-wrap gap-2 mb-2">
              {MEDIA_TAGS.map((tag) => (
                <button
                  key={tag.id}
                  type="button"
                  onClick={() => toggleTag(tag.id)}
                  className={`rounded-xl px-3 py-2 text-sm border ${
                    tags.includes(tag.id)
                      ? 'border-cyan-300/50 bg-cyan-400/15'
                      : 'border-white/10 bg-white/5'
                  }`}
                >
                  {tag.emoji} {tag.label}
                </button>
              ))}
            </div>
            <TagRow tags={tags} className="mb-4" />

            <GlassButton
              variant="primary"
              className="w-full justify-center gap-2 mt-2 py-3.5"
              disabled={files.length === 0}
              onClick={() => setStep('category')}
            >
              {t(lang, 'continue')}
            </GlassButton>
          </>
        )}

        {step === 'category' && (
          <>
            <h2 className="text-lg font-semibold text-white mb-3">{t(lang, 'selectCategory')}</h2>
            <div className="grid grid-cols-2 gap-2 mb-4">
              {categories.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setCategory(c.id)}
                  className={`rounded-2xl py-4 px-3 text-sm font-medium border transition ${
                    category === c.id
                      ? 'border-fuchsia-400/50 bg-fuchsia-500/20 text-white'
                      : 'border-white/10 bg-white/5 text-white/70'
                  }`}
                >
                  {c.label}
                </button>
              ))}
            </div>

            {progress && (
              <div className="mb-4">
                <div className="flex justify-between text-xs text-white/50 mb-1">
                  <span className="flex items-center gap-1">
                    <Loader2 className="h-3.5 w-3.5 animate-spin" /> {t(lang, 'uploading')}
                  </span>
                  <span>
                    {progress.done}/{progress.total}
                  </span>
                </div>
                <div className="h-2 rounded-full bg-white/10 overflow-hidden">
                  <motion.div
                    className="h-full bg-gradient-to-r from-cyan-400 to-fuchsia-500"
                    animate={{
                      width: `${(progress.done / Math.max(1, progress.total)) * 100}%`,
                    }}
                  />
                </div>
              </div>
            )}

            {done && (
              <div className="mb-3 flex items-center gap-2 text-sm text-emerald-300">
                <CheckCircle2 className="h-4 w-4" /> {t(lang, 'uploaded')}
              </div>
            )}

            <div className="flex gap-2">
              <GlassButton className="flex-1 justify-center" onClick={() => setStep('pick')}>
                {t(lang, 'back')}
              </GlassButton>
              <GlassButton
                variant="primary"
                className="flex-1 justify-center gap-2"
                disabled={!category || !!progress}
                onClick={upload}
              >
                <Upload className="h-4 w-4" />
                {progress ? t(lang, 'uploading') : t(lang, 'save')}
              </GlassButton>
            </div>
          </>
        )}
      </GlassCard>
    </div>
  );
}
