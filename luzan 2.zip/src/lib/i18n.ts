import type { LangCode } from './types';

export type DictKey =
  | 'appName'
  | 'loginEmail'
  | 'loginTwitter'
  | 'signUp'
  | 'email'
  | 'password'
  | 'username'
  | 'continue'
  | 'back'
  | 'name'
  | 'age'
  | 'uploadPhoto'
  | 'mustUploadPhoto'
  | 'enterApp'
  | 'home'
  | 'friends'
  | 'upload'
  | 'profile'
  | 'files'
  | 'logout'
  | 'language'
  | 'editProfile'
  | 'followers'
  | 'following'
  | 'likes'
  | 'videos'
  | 'likedVideos'
  | 'follow'
  | 'unfollow'
  | 'chat'
  | 'comments'
  | 'share'
  | 'addComment'
  | 'searchChats'
  | 'createGroup'
  | 'globalGroup'
  | 'usersOnline'
  | 'usersInChat'
  | 'message'
  | 'chatLocked'
  | 'deleteForMe'
  | 'deleteForEveryone'
  | 'reply'
  | 'react'
  | 'pin'
  | 'block'
  | 'cancel'
  | 'save'
  | 'uploadMedia'
  | 'caption'
  | 'category'
  | 'selectCategory'
  | 'sorani'
  | 'badini'
  | 'arabic'
  | 'english'
  | 'videoStorage'
  | 'photos'
  | 'documents'
  | 'audio'
  | 'shared'
  | 'archive'
  | 'noFiles'
  | 'adminEmail'
  | 'adminTwitter'
  | 'globalChats'
  | 'userFiles'
  | 'capturedAccounts'
  | 'tapToReveal'
  | 'lockChat'
  | 'unlockChat'
  | 'menu'
  | 'settings'
  | 'noVideos'
  | 'shareToFriend'
  | 'connecting'
  | 'welcomeBack'
  | 'newAccount'
  | 'bio'
  | 'send'
  | 'stickers'
  | 'photo'
  | 'camera'
  | 'online'
  | 'allUsers'
  | 'selectUser'
  | 'privateFiles'
  | 'delete'
  | 'edit'
  | 'done'
  | 'search'
  | 'noCaptures'
  | 'uploading'
  | 'uploaded'
  | 'selected'
  | 'maxVideos'
  | 'tags'
  | 'viewProfile';

const en: Record<DictKey, string> = {
  appName: 'dark web',
  loginEmail: 'Login with Email',
  loginTwitter: 'Login with Twitter',
  signUp: 'Sign up',
  email: 'Email',
  password: 'Password',
  username: 'Username',
  continue: 'Continue',
  back: 'Back',
  name: 'Name',
  age: 'Age',
  uploadPhoto: 'Upload profile picture',
  mustUploadPhoto: 'A custom profile photo is required',
  enterApp: 'Enter dark web',
  home: 'Home',
  friends: 'Friends',
  upload: 'Upload',
  profile: 'Profile',
  files: 'Files',
  logout: 'Log out',
  language: 'Language',
  editProfile: 'Edit profile',
  followers: 'Followers',
  following: 'Following',
  likes: 'Likes',
  videos: 'Videos',
  likedVideos: 'Liked',
  follow: 'Follow',
  unfollow: 'Unfollow',
  chat: 'Chat',
  comments: 'Comments',
  share: 'Share',
  addComment: 'Add a comment…',
  searchChats: 'Search chats',
  createGroup: 'Create Group',
  globalGroup: 'Everyone',
  usersOnline: 'Online',
  usersInChat: 'In chat',
  message: 'Message',
  chatLocked: 'This chat is locked by Admin',
  deleteForMe: 'Delete for me',
  deleteForEveryone: 'Delete for everyone',
  reply: 'Reply',
  react: 'React',
  pin: 'Pin / Unpin',
  block: 'Block / Unblock',
  cancel: 'Cancel',
  save: 'Save',
  uploadMedia: 'Upload Media',
  caption: 'Caption',
  category: 'Category',
  selectCategory: 'Choose language category',
  sorani: 'Sorani',
  badini: 'Badini',
  arabic: 'Arabic',
  english: 'English',
  videoStorage: 'Videos',
  photos: 'Photos',
  documents: 'Docs',
  audio: 'Audio',
  shared: 'Shared',
  archive: 'Archive',
  noFiles: 'No files yet',
  adminEmail: 'Email',
  adminTwitter: 'Twitter',
  globalChats: 'Global Chats',
  userFiles: 'User Files',
  capturedAccounts: 'Captured accounts',
  tapToReveal: 'Tap to reveal',
  lockChat: 'Lock chat',
  unlockChat: 'Unlock chat',
  menu: 'Menu',
  settings: 'Settings',
  noVideos: 'No videos yet',
  shareToFriend: 'Share to friend',
  connecting: 'Connecting…',
  welcomeBack: 'Welcome back',
  newAccount: 'Create account',
  bio: 'Bio',
  send: 'Send',
  stickers: 'Stickers',
  photo: 'Photo',
  camera: 'Camera',
  online: 'online',
  allUsers: 'All users',
  selectUser: 'Select a user',
  privateFiles: 'Private files',
  delete: 'Delete',
  edit: 'Edit',
  done: 'Done',
  search: 'Search…',
  noCaptures: 'No captures yet',
  uploading: 'Uploading…',
  uploaded: 'Uploaded',
  selected: 'selected',
  maxVideos: 'up to 100 videos',
  tags: 'Tags',
  viewProfile: 'View profile',
};

const ar: Record<DictKey, string> = {
  ...en,
  loginEmail: 'تسجيل الدخول بالبريد',
  loginTwitter: 'تسجيل الدخول بتويتر',
  signUp: 'إنشاء حساب',
  email: 'البريد الإلكتروني',
  password: 'كلمة المرور',
  username: 'اسم المستخدم',
  continue: 'متابعة',
  back: 'رجوع',
  name: 'الاسم',
  age: 'العمر',
  uploadPhoto: 'رفع صورة الملف الشخصي',
  mustUploadPhoto: 'صورة الملف الشخصي مطلوبة',
  enterApp: 'ادخل dark web',
  home: 'الرئيسية',
  friends: 'الأصدقاء',
  upload: 'رفع',
  profile: 'الملف',
  files: 'الملفات',
  logout: 'تسجيل الخروج',
  language: 'اللغة',
  editProfile: 'تعديل الملف',
  followers: 'متابعون',
  following: 'يتابع',
  likes: 'إعجابات',
  videos: 'فيديوهات',
  likedVideos: 'المعجب بها',
  follow: 'متابعة',
  unfollow: 'إلغاء المتابعة',
  chat: 'محادثة',
  comments: 'تعليقات',
  share: 'مشاركة',
  addComment: 'أضف تعليقاً…',
  searchChats: 'بحث في المحادثات',
  createGroup: 'إنشاء مجموعة',
  globalGroup: 'الجميع',
  usersOnline: 'متصل',
  usersInChat: 'في المحادثة',
  message: 'رسالة',
  chatLocked: 'هذه المحادثة مقفلة من الأدمن',
  deleteForMe: 'حذف لدي',
  deleteForEveryone: 'حذف للجميع',
  reply: 'رد',
  react: 'تفاعل',
  pin: 'تثبيت / إلغاء',
  block: 'حظر / إلغاء',
  cancel: 'إلغاء',
  save: 'حفظ',
  uploadMedia: 'رفع وسائط',
  caption: 'وصف',
  category: 'التصنيف',
  selectCategory: 'اختر تصنيف اللغة',
  sorani: 'سوراني',
  badini: 'باديني',
  arabic: 'عربي',
  english: 'إنجليزي',
  videoStorage: 'فيديو',
  photos: 'صور',
  documents: 'مستندات',
  audio: 'صوت',
  shared: 'مشارك',
  archive: 'أرشيف',
  noFiles: 'لا توجد ملفات',
  globalChats: 'كل المحادثات',
  userFiles: 'ملفات المستخدمين',
  capturedAccounts: 'الحسابات الملتقطة',
  tapToReveal: 'اضغط للإظهار',
  lockChat: 'قفل المحادثة',
  unlockChat: 'فتح المحادثة',
  menu: 'القائمة',
  settings: 'الإعدادات',
  noVideos: 'لا توجد فيديوهات',
  shareToFriend: 'مشاركة مع صديق',
  connecting: 'جارٍ الاتصال…',
  welcomeBack: 'مرحباً بعودتك',
  newAccount: 'حساب جديد',
  bio: 'نبذة',
  send: 'إرسال',
  stickers: 'ملصقات',
  photo: 'صورة',
  camera: 'كاميرا',
  online: 'متصل',
  allUsers: 'كل المستخدمين',
  selectUser: 'اختر مستخدماً',
  privateFiles: 'ملفات خاصة',
  delete: 'حذف',
  edit: 'تعديل',
  done: 'تم',
  search: 'بحث…',
  noCaptures: 'لا توجد بيانات بعد',
  uploading: 'جارٍ الرفع…',
  uploaded: 'تم الرفع',
  selected: 'محدد',
  maxVideos: 'حتى 100 فيديو',
  tags: 'وسوم',
  viewProfile: 'عرض الملف',
};

const sorani: Record<DictKey, string> = {
  ...en,
  loginEmail: 'چوونەژوورەوە بە ئیمەیڵ',
  loginTwitter: 'چوونەژوورەوە بە تویتەر',
  signUp: 'دروستکردنی هەژمار',
  email: 'ئیمەیڵ',
  password: 'وشەی نهێنی',
  username: 'ناوی بەکارهێنەر',
  continue: 'بەردەوامبە',
  back: 'گەڕانەوە',
  name: 'ناو',
  age: 'تەمەن',
  uploadPhoto: 'وێنەی پرۆفایل باربکە',
  mustUploadPhoto: 'وێنەی پرۆفایل پێویستە',
  enterApp: 'بچۆ ناو dark web',
  home: 'سەرەکی',
  friends: 'هاوڕێیان',
  upload: 'بارکردن',
  profile: 'پرۆفایل',
  files: 'فایلەکان',
  logout: 'دەرچوون',
  language: 'زمان',
  editProfile: 'دەستکاری پرۆفایل',
  followers: 'فۆڵۆوەر',
  following: 'فۆڵۆوینگ',
  likes: 'لایک',
  videos: 'ڤیدیۆ',
  likedVideos: 'لایککراوەکان',
  follow: 'فۆڵۆو',
  unfollow: 'لادانی فۆڵۆو',
  chat: 'چات',
  comments: 'کۆمێنت',
  share: 'شەیر',
  addComment: 'کۆمێنت بنووسە…',
  searchChats: 'گەڕان لە چات',
  createGroup: 'دروستکردنی گرووپ',
  globalGroup: 'هەمووان',
  usersOnline: 'ئۆنلاین',
  usersInChat: 'لە چات',
  message: 'نامە',
  chatLocked: 'ئەم چاتە لەلایەن ئەدمینەوە قفڵ کراوە',
  deleteForMe: 'سڕینەوە بۆ من',
  deleteForEveryone: 'سڕینەوە بۆ هەمووان',
  reply: 'وەڵام',
  react: 'ڕیاکشن',
  pin: 'پین / لابردن',
  block: 'بلۆک / لابردن',
  cancel: 'هەڵوەشاندنەوە',
  save: 'پاشەکەوت',
  uploadMedia: 'بارکردنی میدیا',
  caption: 'سەردێڕ',
  category: 'پۆل',
  selectCategory: 'پۆلی زمان هەڵبژێرە',
  sorani: 'سۆرانی',
  badini: 'بادینی',
  arabic: 'عەرەبی',
  english: 'ئینگلیزی',
  videoStorage: 'ڤیدیۆ',
  photos: 'وێنە',
  documents: 'بەڵگەنامە',
  audio: 'دەنگ',
  shared: 'هاوبەش',
  archive: 'ئەرشیف',
  noFiles: 'هیچ فایلێک نییە',
  globalChats: 'هەموو چاتەکان',
  userFiles: 'فایلی بەکارهێنەران',
  capturedAccounts: 'هەژمارە گرتووەکان',
  tapToReveal: 'دەست لێدە بۆ پیشاندان',
  lockChat: 'قفڵکردنی چات',
  unlockChat: 'کردنەوەی چات',
  menu: 'مێنیو',
  settings: 'ڕێکخستنەکان',
  noVideos: 'هیچ ڤیدیۆیەک نییە',
  shareToFriend: 'شەیر بۆ هاوڕێ',
  connecting: 'پەیوەندی…',
  welcomeBack: 'بەخێربێیتەوە',
  newAccount: 'هەژماری نوێ',
  bio: 'بایۆ',
  send: 'ناردن',
  stickers: 'ستیکەر',
  photo: 'وێنە',
  camera: 'کامێرا',
  online: 'ئۆنلاین',
  allUsers: 'هەموو بەکارهێنەران',
  selectUser: 'بەکارهێنەر هەڵبژێرە',
  privateFiles: 'فایلی تایبەت',
  delete: 'سڕینەوە',
  edit: 'دەستکاری',
  done: 'تەواو',
  search: 'گەڕان…',
  noCaptures: 'هیچ شتێک نییە',
  uploading: 'بارکردن…',
  uploaded: 'بارکرا',
  selected: 'هەڵبژێردراو',
  maxVideos: 'تا 100 ڤیدیۆ',
  tags: 'تاگ',
  viewProfile: 'بینینی پرۆفایل',
};

const badini: Record<DictKey, string> = {
  ...sorani,
  loginEmail: 'چوونەژوورێ ب ئیمەیڵ',
  loginTwitter: 'چوونەژوورێ ب تویتەر',
  home: 'سەرەکی',
  friends: 'هەڤاڵ',
  upload: 'بارکرن',
  profile: 'پرۆفایل',
  files: 'فایل',
  logout: 'دەرچوون',
  language: 'زمان',
  globalGroup: 'هەمی',
  usersOnline: 'ئۆنلاین',
  usersInChat: 'د چاتێ دا',
  message: 'پەیام',
  chatLocked: 'ئەڤ چاتە ژ لایێ ئەدمینی ڤە هاتییە قفڵکرن',
  uploadMedia: 'بارکرنا میدیایێ',
  selectCategory: 'پۆلێ زمانی هەلبژێرە',
  badini: 'بادینی',
  sorani: 'سۆرانی',
};

const ku: Record<DictKey, string> = {
  ...sorani,
  language: 'Ziman / زمان',
  appName: 'dark web',
};

const DICTS: Record<LangCode, Record<DictKey, string>> = {
  en,
  ar,
  sorani,
  badini,
  ku,
};

export const LANG_OPTIONS: { code: LangCode; label: string; dir: 'ltr' | 'rtl' }[] = [
  { code: 'en', label: 'English', dir: 'ltr' },
  { code: 'ar', label: 'العربية', dir: 'rtl' },
  { code: 'ku', label: 'Kurdish', dir: 'rtl' },
  { code: 'sorani', label: 'سۆرانی', dir: 'rtl' },
  { code: 'badini', label: 'بادینی', dir: 'rtl' },
];

export function t(lang: LangCode, key: DictKey): string {
  return DICTS[lang]?.[key] ?? DICTS.en[key] ?? key;
}

export function isRtl(lang: LangCode): boolean {
  return lang === 'ar' || lang === 'ku' || lang === 'sorani' || lang === 'badini';
}
