import type { ChatMessage, ChatThread, UserProfile, VideoPost } from './types';

export const ADMIN_EMAIL = 'admin1234@gmail.com';
export const ADMIN_PASSWORD = 'adminvizo12';
export const ADMIN_ID = 'user_admin';
export const GLOBAL_CHAT_ID = 'chat_global_everyone';
export const APP_NAME = 'luzan';

export const STICKERS = ['🔥', '😂', '💀', '✨', '👻', '💜', '🚀', '👀', '🫠', '🖤', '⚡', '🌐'];

export const MEDIA_TAGS = [
  { id: 'girl' as const, emoji: '👧', label: 'Girl' },
  { id: 'child' as const, emoji: '🧒', label: 'Child' },
  { id: 'mixed' as const, emoji: '🧑‍🤝‍🧑', label: 'Mixed' },
  { id: 'lgbt' as const, emoji: '🏳️‍🌈', label: 'LGBT' },
];

export const SEED_USERS: UserProfile[] = [
  {
    id: ADMIN_ID,
    name: 'luzan',
    username: 'luzan',
    email: ADMIN_EMAIL,
    avatar: '/images/avatar4.jpg',
    bio: 'luzan admin',
    followers: 0,
    following: 0,
    likes: 0,
    isAdmin: true,
    isBot: false,
    followingIds: [],
    followerIds: [],
    language: 'en',
    online: true,
  },
  {
    id: 'user_luna',
    name: 'Luna Vale',
    username: 'lunavale',
    email: 'luna@gmail.com',
    avatar: '/images/avatar1.jpg',
    bio: 'Neon nights ✨',
    followers: 0,
    following: 0,
    likes: 0,
    isBot: true,
    followingIds: [],
    followerIds: [],
    language: 'en',
    online: true,
  },
  {
    id: 'user_kai',
    name: 'Kai Mercer',
    username: 'kaimercer',
    email: 'kai@gmail.com',
    avatar: '/images/avatar2.jpg',
    bio: 'Street clips',
    followers: 0,
    following: 0,
    likes: 0,
    isBot: true,
    followingIds: [],
    followerIds: [],
    language: 'en',
    online: true,
  },
  {
    id: 'user_nova',
    name: 'Nova Reed',
    username: 'novareed',
    email: 'nova@gmail.com',
    avatar: '/images/avatar3.jpg',
    bio: 'Coffee & chaos ☕',
    followers: 0,
    following: 0,
    likes: 0,
    isBot: true,
    followingIds: [],
    followerIds: [],
    language: 'en',
    online: false,
  },
  {
    id: 'user_mira',
    name: 'Mira Sol',
    username: 'mirasol',
    email: 'mira@gmail.com',
    avatar: '/images/avatar5.jpg',
    bio: 'Glitter era 💫',
    followers: 0,
    following: 0,
    likes: 0,
    isBot: true,
    followingIds: [],
    followerIds: [],
    language: 'en',
    online: true,
  },
];

export const SEED_VIDEOS: VideoPost[] = [
  {
    id: 'vid_1',
    userId: 'user_luna',
    src: '/videos/city.mp4',
    caption: 'City never sleeps 🌃',
    likes: 0,
    likedBy: [],
    comments: [],
    shares: 0,
    category: 'english',
    tags: ['mixed'],
    createdAt: Date.now() - 120000000,
  },
  {
    id: 'vid_2',
    userId: 'user_kai',
    src: '/videos/ocean.mp4',
    caption: 'Golden hour 🌊',
    likes: 0,
    likedBy: [],
    comments: [],
    shares: 0,
    category: 'english',
    tags: ['mixed'],
    createdAt: Date.now() - 90000000,
  },
  {
    id: 'vid_3',
    userId: 'user_mira',
    src: '/videos/dance.mp4',
    caption: 'Neon freestyle ✨',
    likes: 0,
    likedBy: [],
    comments: [],
    shares: 0,
    category: 'sorani',
    tags: ['girl'],
    createdAt: Date.now() - 60000000,
  },
  {
    id: 'vid_4',
    userId: 'user_nova',
    src: '/videos/food.mp4',
    caption: 'Late night chef 🍳',
    likes: 0,
    likedBy: [],
    comments: [],
    shares: 0,
    category: 'arabic',
    tags: ['mixed'],
    createdAt: Date.now() - 30000000,
  },
  {
    id: 'vid_5',
    userId: 'user_kai',
    src: '/videos/city.mp4',
    caption: 'Rain walk ☔',
    likes: 0,
    likedBy: [],
    comments: [],
    shares: 0,
    category: 'badini',
    tags: ['child'],
    createdAt: Date.now() - 15000000,
  },
];

export function buildGlobalChat(participantIds: string[]): ChatThread {
  return {
    id: GLOBAL_CHAT_ID,
    type: 'global',
    name: 'Everyone',
    participantIds: [...new Set(participantIds)],
    pinned: true,
    blocked: false,
    locked: false,
    lastMessageAt: Date.now(),
    unread: 0,
    avatar: '/images/city-bg.jpg',
    inChatUserIds: participantIds.filter(Boolean).slice(0, 3),
  };
}

export function buildSeedChats(
  currentUserId: string,
  allUserIds: string[]
): { chats: ChatThread[]; messages: ChatMessage[] } {
  const global = buildGlobalChat(
    allUserIds.includes(currentUserId)
      ? allUserIds
      : [...allUserIds, currentUserId]
  );
  const bots = allUserIds.filter((id) => id !== currentUserId);
  const dms: ChatThread[] = bots.map((id, i) => ({
    id: `chat_dm_${id}_${currentUserId}`,
    type: 'dm' as const,
    participantIds: [currentUserId, id],
    pinned: id === ADMIN_ID,
    blocked: false,
    locked: false,
    lastMessageAt: Date.now() - (i + 1) * 3600000,
    unread: i === 0 ? 1 : 0,
    inChatUserIds: [],
  }));

  const messages: ChatMessage[] = [
    {
      id: 'm_g1',
      chatId: GLOBAL_CHAT_ID,
      senderId: 'user_luna',
      text: 'Welcome to luzan 🌑',
      type: 'text',
      reactions: [],
      createdAt: Date.now() - 8000000,
      deletedFor: [],
      deletedForEveryone: false,
    },
    {
      id: 'm_a1',
      chatId: `chat_dm_${ADMIN_ID}_${currentUserId}`,
      senderId: ADMIN_ID,
      text: 'Hey — glad you joined.',
      type: 'text',
      reactions: [],
      createdAt: Date.now() - 5000000,
      deletedFor: [],
      deletedForEveryone: false,
    },
  ];

  return { chats: [global, ...dms], messages };
}
