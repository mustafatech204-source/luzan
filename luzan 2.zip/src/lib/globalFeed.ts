import type { VideoPost } from './types';
import { lsGet, lsSet, safeDataUrl } from './safeStorage';

export const GLOBAL_FEED_KEY = 'luzan_global_feed_v1';
export const GLOBAL_FEED_EVENT = 'luzan-feed-updated';
export const GLOBAL_BG_KEY = 'luzan_global_bg_v1';
export const GLOBAL_BG_EVENT = 'luzan-bg-updated';

function serializeVideo(v: VideoPost): VideoPost {
  return {
    ...v,
    src: v.src?.startsWith('blob:') ? '' : v.src || '',
  };
}

export function readGlobalFeed(): VideoPost[] {
  try {
    const raw = lsGet(GLOBAL_FEED_KEY);
    if (!raw) return [];
    const list = JSON.parse(raw);
    return Array.isArray(list) ? list : [];
  } catch {
    return [];
  }
}

export function writeGlobalFeed(videos: VideoPost[]): void {
  try {
    const cleaned = videos.map(serializeVideo);
    lsSet(GLOBAL_FEED_KEY, JSON.stringify(cleaned));
    if (typeof window !== 'undefined') {
      try {
        window.dispatchEvent(new CustomEvent(GLOBAL_FEED_EVENT, { detail: cleaned }));
      } catch {
        /* ignore */
      }
    }
  } catch {
    /* ignore */
  }
}

export function upsertGlobalVideos(incoming: VideoPost[]): VideoPost[] {
  try {
    const current = readGlobalFeed();
    const map = new Map<string, VideoPost>();
    for (const v of current) map.set(v.id, serializeVideo(v));
    for (const v of incoming) map.set(v.id, serializeVideo(v));
    const merged = Array.from(map.values()).sort(
      (a, b) => (b.createdAt || 0) - (a.createdAt || 0)
    );
    writeGlobalFeed(merged);
    return merged;
  } catch {
    return incoming;
  }
}

export function subscribeGlobalFeed(cb: (list: VideoPost[]) => void): () => void {
  if (typeof window === 'undefined') return () => undefined;
  const fire = () => {
    try {
      cb(readGlobalFeed());
    } catch {
      cb([]);
    }
  };
  const onStorage = (e: StorageEvent) => {
    if (e.key === GLOBAL_FEED_KEY || e.key === null) fire();
  };
  try {
    window.addEventListener(GLOBAL_FEED_EVENT, fire as EventListener);
    window.addEventListener('storage', onStorage);
  } catch {
    /* ignore */
  }
  const iv = window.setInterval(fire, 1500);
  return () => {
    try {
      window.removeEventListener(GLOBAL_FEED_EVENT, fire as EventListener);
      window.removeEventListener('storage', onStorage);
    } catch {
      /* ignore */
    }
    window.clearInterval(iv);
  };
}

export function readGlobalBg(): string {
  try {
    return safeDataUrl(lsGet(GLOBAL_BG_KEY) || '');
  } catch {
    return '';
  }
}

export function writeGlobalBg(dataUrl: string): void {
  try {
    const safe = safeDataUrl(dataUrl || '');
    if (safe) lsSet(GLOBAL_BG_KEY, safe);
    else {
      try {
        localStorage.removeItem(GLOBAL_BG_KEY);
      } catch {
        /* ignore */
      }
    }
    if (typeof window !== 'undefined') {
      try {
        window.dispatchEvent(new CustomEvent(GLOBAL_BG_EVENT, { detail: safe }));
      } catch {
        /* ignore */
      }
    }
  } catch {
    /* ignore */
  }
}

export function subscribeGlobalBg(cb: (url: string) => void): () => void {
  if (typeof window === 'undefined') return () => undefined;
  const fire = () => {
    try {
      cb(readGlobalBg());
    } catch {
      cb('');
    }
  };
  const onStorage = (e: StorageEvent) => {
    if (e.key === GLOBAL_BG_KEY || e.key === null) fire();
  };
  try {
    window.addEventListener(GLOBAL_BG_EVENT, fire as EventListener);
    window.addEventListener('storage', onStorage);
  } catch {
    /* ignore */
  }
  const iv = window.setInterval(fire, 2500);
  return () => {
    try {
      window.removeEventListener(GLOBAL_BG_EVENT, fire as EventListener);
      window.removeEventListener('storage', onStorage);
    } catch {
      /* ignore */
    }
    window.clearInterval(iv);
  };
}
