import { useEffect, useState } from 'react';
import { getMediaUrl } from '../lib/idb';

export function useResolvedSrc(src?: string, mediaId?: string) {
  const [url, setUrl] = useState(() => {
    if (src && !src.startsWith('blob:')) return src;
    if (src?.startsWith('blob:')) return src;
    return '';
  });

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        if (src && src.length > 0 && !src.startsWith('blob:')) {
          if (alive) setUrl(src);
          return;
        }
        if (src?.startsWith('blob:')) {
          if (alive) setUrl(src);
          return;
        }
        if (mediaId) {
          const u = await Promise.race([
            getMediaUrl(mediaId),
            new Promise<null>((r) => setTimeout(() => r(null), 3000)),
          ]);
          if (alive && u) setUrl(u);
        } else if (src) {
          if (alive) setUrl(src);
        } else if (alive) {
          setUrl('');
        }
      } catch {
        if (alive) setUrl(src && !src.startsWith('blob:') ? src : '');
      }
    })();
    return () => {
      alive = false;
    };
  }, [src, mediaId]);

  return url;
}

export function ResolvedVideo({
  src,
  mediaId,
  className,
  ...props
}: {
  src?: string;
  mediaId?: string;
  className?: string;
} & React.VideoHTMLAttributes<HTMLVideoElement>) {
  const url = useResolvedSrc(src, mediaId);
  const [failed, setFailed] = useState(false);

  if (!url || failed) {
    return (
      <div
        className={`grid place-items-center bg-gradient-to-br from-violet-950/80 to-black text-white/30 text-xs ${className || ''}`}
      >
        {failed ? 'Unavailable' : '…'}
      </div>
    );
  }
  return (
    <video
      src={url}
      className={className}
      playsInline
      webkit-playsinline="true"
      preload="metadata"
      onError={() => setFailed(true)}
      {...props}
    />
  );
}

export function ResolvedImg({
  src,
  mediaId,
  className,
  alt = '',
}: {
  src?: string;
  mediaId?: string;
  className?: string;
  alt?: string;
}) {
  const url = useResolvedSrc(src, mediaId);
  const [failed, setFailed] = useState(false);
  if (!url || failed) return <div className={`bg-white/10 ${className || ''}`} />;
  return (
    <img
      src={url}
      alt={alt}
      className={className}
      draggable={false}
      onError={() => setFailed(true)}
    />
  );
}
