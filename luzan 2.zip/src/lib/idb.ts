/**
 * Safe media storage with IndexedDB + in-memory fallback.
 * Never throws to the UI thread; never blocks first paint.
 */

export const MOCK_CAPACITY_GB = 10_000;

const DB_NAME = 'luzan-media-v1';
const DB_VERSION = 1;
const STORE = 'media';

type MediaRow = {
  id: string;
  blob: Blob;
  name: string;
  type: string;
  size: number;
  ownerId?: string;
  createdAt: number;
};

const memory = new Map<string, MediaRow>();
const urlCache = new Map<string, string>();
let db: IDBDatabase | null = null;
let dbFailed = false;
let opening: Promise<IDBDatabase | null> | null = null;

function openSafe(): Promise<IDBDatabase | null> {
  if (dbFailed) return Promise.resolve(null);
  if (db) return Promise.resolve(db);
  if (opening) return opening;
  if (typeof indexedDB === 'undefined') {
    dbFailed = true;
    return Promise.resolve(null);
  }

  opening = new Promise((resolve) => {
    let settled = false;
    const done = (v: IDBDatabase | null) => {
      if (settled) return;
      settled = true;
      resolve(v);
    };

    // Safari can hang forever — hard timeout
    const t = window.setTimeout(() => {
      dbFailed = true;
      opening = null;
      done(null);
    }, 2500);

    try {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        try {
          const d = req.result;
          if (!d.objectStoreNames.contains(STORE)) {
            d.createObjectStore(STORE, { keyPath: 'id' });
          }
        } catch {
          /* ignore */
        }
      };
      req.onsuccess = () => {
        window.clearTimeout(t);
        db = req.result;
        opening = null;
        db.onerror = () => {
          dbFailed = true;
          db = null;
        };
        done(db);
      };
      req.onerror = () => {
        window.clearTimeout(t);
        dbFailed = true;
        opening = null;
        done(null);
      };
      req.onblocked = () => {
        window.clearTimeout(t);
        dbFailed = true;
        opening = null;
        done(null);
      };
    } catch {
      window.clearTimeout(t);
      dbFailed = true;
      opening = null;
      done(null);
    }
  });

  return opening;
}

export function uid(prefix = 'id'): string {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 9)}`;
}

export async function saveMedia(
  id: string,
  blob: Blob,
  name = 'file',
  ownerId?: string
): Promise<string> {
  const row: MediaRow = {
    id,
    blob,
    name,
    type: blob.type || 'application/octet-stream',
    size: blob.size,
    ownerId,
    createdAt: Date.now(),
  };
  memory.set(id, row);
  const prev = urlCache.get(id);
  if (prev) {
    try {
      URL.revokeObjectURL(prev);
    } catch {
      /* ignore */
    }
  }
  try {
    urlCache.set(id, URL.createObjectURL(blob));
  } catch {
    /* ignore */
  }

  try {
    const database = await openSafe();
    if (database) {
      await new Promise<void>((resolve) => {
        try {
          const tx = database.transaction(STORE, 'readwrite');
          tx.objectStore(STORE).put(row);
          tx.oncomplete = () => resolve();
          tx.onerror = () => resolve();
          tx.onabort = () => resolve();
        } catch {
          resolve();
        }
      });
    }
  } catch {
    /* memory only */
  }
  return id;
}

export async function getMedia(id: string): Promise<Blob | null> {
  const mem = memory.get(id);
  if (mem) return mem.blob;
  try {
    const database = await openSafe();
    if (!database) return null;
    return await new Promise<Blob | null>((resolve) => {
      try {
        const tx = database.transaction(STORE, 'readonly');
        const req = tx.objectStore(STORE).get(id);
        req.onsuccess = () => {
          const row = req.result as MediaRow | undefined;
          if (row?.blob) {
            memory.set(id, row);
            resolve(row.blob);
          } else resolve(null);
        };
        req.onerror = () => resolve(null);
      } catch {
        resolve(null);
      }
    });
  } catch {
    return null;
  }
}

export async function getMediaUrl(id: string): Promise<string | null> {
  if (urlCache.has(id)) return urlCache.get(id)!;
  const blob = await getMedia(id);
  if (!blob) return null;
  try {
    const url = URL.createObjectURL(blob);
    urlCache.set(id, url);
    return url;
  } catch {
    return null;
  }
}

export async function deleteMedia(id: string): Promise<void> {
  memory.delete(id);
  const prev = urlCache.get(id);
  if (prev) {
    try {
      URL.revokeObjectURL(prev);
    } catch {
      /* ignore */
    }
    urlCache.delete(id);
  }
  try {
    const database = await openSafe();
    if (!database) return;
    await new Promise<void>((resolve) => {
      try {
        const tx = database.transaction(STORE, 'readwrite');
        tx.objectStore(STORE).delete(id);
        tx.oncomplete = () => resolve();
        tx.onerror = () => resolve();
      } catch {
        resolve();
      }
    });
  } catch {
    /* ignore */
  }
}

export async function listMedia(ownerId?: string) {
  const fromMem = Array.from(memory.values());
  let all = fromMem;
  try {
    const database = await openSafe();
    if (database) {
      const rows = await new Promise<MediaRow[]>((resolve) => {
        try {
          const tx = database.transaction(STORE, 'readonly');
          const req = tx.objectStore(STORE).getAll();
          req.onsuccess = () => resolve((req.result as MediaRow[]) || []);
          req.onerror = () => resolve([]);
        } catch {
          resolve([]);
        }
      });
      const map = new Map<string, MediaRow>();
      for (const r of rows) map.set(r.id, r);
      for (const r of fromMem) map.set(r.id, r);
      all = Array.from(map.values());
    }
  } catch {
    /* mem only */
  }
  return all
    .filter((m) => !ownerId || m.ownerId === ownerId)
    .map(({ id, name, type, size, ownerId: o, createdAt }) => ({
      id,
      name,
      type,
      size,
      ownerId: o,
      createdAt,
    }))
    .sort((a, b) => b.createdAt - a.createdAt);
}

export async function saveMediaBatch(
  items: { id: string; blob: Blob; name: string; ownerId?: string }[],
  onProgress?: (done: number, total: number) => void
): Promise<void> {
  for (let i = 0; i < items.length; i++) {
    const item = items[i];
    await saveMedia(item.id, item.blob, item.name, item.ownerId);
    onProgress?.(i + 1, items.length);
    await new Promise((r) => setTimeout(r, 0));
  }
}

export function fileToDataUrl(file: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    try {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ''));
      reader.onerror = () => reject(reader.error || new Error('read fail'));
      reader.readAsDataURL(file);
    } catch (e) {
      reject(e);
    }
  });
}
