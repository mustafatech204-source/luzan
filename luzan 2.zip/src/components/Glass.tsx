import { motion, type HTMLMotionProps } from 'framer-motion';
import type { ReactNode } from 'react';

export function GlassCard({
  children,
  className = '',
  ...props
}: { children: ReactNode; className?: string } & HTMLMotionProps<'div'>) {
  return (
    <motion.div className={`glass-panel ${className}`} {...props}>
      {children}
    </motion.div>
  );
}

export function GlassButton({
  children,
  className = '',
  variant = 'default',
  ...props
}: {
  children: ReactNode;
  className?: string;
  variant?: 'default' | 'primary' | 'danger' | 'ghost';
} & HTMLMotionProps<'button'>) {
  const variants = {
    default: 'glass-btn',
    primary: 'glass-btn glass-btn-primary',
    danger: 'glass-btn glass-btn-danger',
    ghost: 'glass-btn glass-btn-ghost',
  };
  return (
    <motion.button
      type="button"
      whileTap={{ scale: 0.96 }}
      whileHover={{ scale: 1.02 }}
      transition={{ type: 'spring', stiffness: 500, damping: 30 }}
      className={`${variants[variant]} ${className}`}
      {...props}
    >
      {children}
    </motion.button>
  );
}

export function GlassInput({
  className = '',
  ...props
}: React.InputHTMLAttributes<HTMLInputElement> & { className?: string }) {
  return <input className={`glass-input ${className}`} {...props} />;
}

export function GlassTextarea({
  className = '',
  ...props
}: React.TextareaHTMLAttributes<HTMLTextAreaElement> & { className?: string }) {
  return (
    <textarea
      className={`glass-input min-h-[88px] resize-none ${className}`}
      {...props}
    />
  );
}

export function Overlay({
  onClose,
  children,
  className = '',
}: {
  onClose?: () => void;
  children: ReactNode;
  className?: string;
}) {
  return (
    <motion.div
      className={`fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 ${className}`}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.18 }}
    >
      <div className="absolute inset-0 bg-black/55 backdrop-blur-md" onClick={onClose} />
      <div className="relative z-10 w-full max-w-lg">{children}</div>
    </motion.div>
  );
}

export function formatCount(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return String(n);
}

export function TagRow({
  tags = [],
  className = '',
}: {
  tags?: string[];
  className?: string;
}) {
  const map: Record<string, string> = {
    girl: '👧',
    child: '🧒',
    mixed: '🧑‍🤝‍🧑',
    lgbt: '🏳️‍🌈',
  };
  return (
    <div className={`flex items-center gap-1.5 ${className}`}>
      {(['girl', 'child', 'mixed', 'lgbt'] as const).map((t) => (
        <span
          key={t}
          className={`text-sm leading-none ${tags.includes(t) ? 'opacity-100 scale-110' : 'opacity-35'}`}
          title={t}
        >
          {map[t]}
        </span>
      ))}
    </div>
  );
}
